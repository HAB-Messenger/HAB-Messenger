package com.hab.activities

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.showToast
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.services.ChatService
import com.hab.utils.Utils.RADIUS_ALL_METERS
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.io.FileOutputStream

class ProfileFromSearchInRadiusActivity : AppCompatActivity() {
    //final static int PROFILE_CHAT_ACTIVITY = 561;
    private lateinit var habApp: HabApplication
    private var peerId: String = "null"
    private var peerName: String = "null"
    private lateinit var db: HabDB

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_from_search_in_radius)

        habApp = application as HabApplication

        val imageViewUserPhoto = findViewById<ImageView>(R.id.image_view_user_photo)
        val moreActions = findViewById<ImageView>(R.id.more_actions)
        val viewAnchor = findViewById<View>(R.id.view_anchor)
        val imageViewBack = findViewById<ImageView>(R.id.image_view_back)
        val buttonProfile = findViewById<Button>(R.id.button_profile)
        val buttonChat = findViewById<Button>(R.id.button_chat)
        val personalChat = findViewById<ImageView>(R.id.personal_chat)
        val imageViewProfile = findViewById<ImageView>(R.id.image_view_profile)
        val imageViewInRadius = findViewById<ImageView>(R.id.image_view_in_radius)
        val imageViewChat = findViewById<ImageView>(R.id.image_view_chat)
        val imageViewSettings = findViewById<ImageView>(R.id.image_view_settings)
        val textViewUserName = findViewById<TextView>(R.id.text_view_user_name)
        val textViewStatusText = findViewById<TextView>(R.id.text_view_status_text)
        val textViewDescriptionText = findViewById<TextView>(R.id.text_view_description_text)
        val textViewRadiusText = findViewById<TextView>(R.id.text_view_radius_text)
        val textViewCityText = findViewById<TextView>(R.id.text_view_city_text)

        imageViewProfile.setImageResource(R.drawable.ic_profile_not_selected)
        imageViewInRadius.setImageResource(R.drawable.ic_in_radius_selected)
        peerId = intent.getStringExtra("toUserId")?:"null"
        peerName = intent.getStringExtra("toUserName")?:"null"
        val adminStatus = intent.getStringExtra("toUserStatus")?:"null"
        val adminDescription = intent.getStringExtra("toUserDescription")?:"null"
        val adminRadiusDistanceInMeters = intent.getIntExtra("toUserRadiusSearchDistance", 10)
        val city = intent.getStringExtra("city")?:""

        HabApplication.ioScope.launch {
            val imageFileName = "${habApp.filesDir.absolutePath}/${peerId}"
            try {
                var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(peerId)

                downloadImageResponseFlow.onEach { downloadImageResponse ->
                    val responseCode = downloadImageResponse.responseCode
                    when (responseCode) {
                        1 -> {//keep reading file
                            val buffer = downloadImageResponse.fileChunk.toByteArray()
                            fileImageStream?.write(buffer)
                            Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                        }
                        2 -> {//End of file reached
                            fileImageStream?.flush()
                            fileImageStream?.close()
                            Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                            val imageUri = Uri.parse(imageFileName)
                            val imageDrawable = Drawable.createFromPath(imageUri.path)
                            if (imageDrawable != null) {
                                habApp.uiScope.launch {
                                    imageViewUserPhoto.setImageDrawable(imageDrawable)
                                }
                            } else {
                                habApp.uiScope.launch {
                                    val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                    imageViewUserPhoto.setImageDrawable(userPhotoStub)
                                }
                            }
                        }
                        -1 -> {//error
                            //todo: error
                            fileImageStream?.close()
                            fileImageStream = null
                            habApp.uiScope.launch {
                                val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                imageViewUserPhoto.setImageDrawable(userPhotoStub)
                            }
                        }
                    }
                }.onEmpty {
                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                }.catch { e ->

                }.collect()
            } catch (e: FileNotFoundException) {
                Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
            }
        }

        textViewUserName.setText(peerName)
        textViewStatusText.setText(adminStatus)
        textViewDescriptionText.setText(adminDescription)
        if (adminRadiusDistanceInMeters < 1000) {
            textViewRadiusText.setText("${adminRadiusDistanceInMeters} м")
        }
        if (adminRadiusDistanceInMeters == RADIUS_ALL_METERS) {
            textViewRadiusText.setText("Виден всем")
        } else if (adminRadiusDistanceInMeters >= 1000) {
            textViewRadiusText.setText("${adminRadiusDistanceInMeters/1000} км")
        }
        textViewCityText.setText(city)

        db = HabDB.getDatabase(habApp)
        val userDAO = db.userDAO()

        var popupWindowMoreActions: PopupWindow? = null
        moreActions.setOnClickListener { view: View? ->
            val inflater = this.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val customView = inflater.inflate(R.layout.popup_window_more_actions_profile_from_search, null) as ConstraintLayout
            val layoutBlockUser: ConstraintLayout = customView.findViewById(R.id.layout_block_user)
            layoutBlockUser.setOnClickListener { v: View? -> showToast(this, "Пользователь заблокирован") }
            val layoutComplain: ConstraintLayout = customView.findViewById(R.id.layout_complain)
            layoutComplain.setOnClickListener { v: View? ->
                val intentReportUserActivity = Intent(this, ReportUserActivity::class.java)
                startActivity(intentReportUserActivity)
                popupWindowMoreActions?.dismiss()
            }
            popupWindowMoreActions = PopupWindow(customView,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT)
            popupWindowMoreActions?.isOutsideTouchable = true
            //popupWindow.setTouchable(true)
            popupWindowMoreActions?.isFocusable = true
            popupWindowMoreActions?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            /*popupWindow.setTouchInterceptor((v, event) -> {
                popupWindow.dismiss()
                return true
            });*/
            popupWindowMoreActions?.showAsDropDown(viewAnchor, 0, 0)
        }
        personalChat.setOnClickListener { view: View? ->
            // check if the user is not blocked by adminId(use db info)
            HabApplication.ioScope.launch {
                val sharedPrefs = getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, MODE_PRIVATE)
                val userId = sharedPrefs.getString(Utils.SHARED_PREFS_KEY_USER_ID, "")?:""
                val userIdInDB: Int = userDAO.getUserByUserId(userId).id
                val adminIdInDB: Int = userDAO.getUserByUserId(peerId)?.id?:-1
                val blockedUserInDB = db.blockedUserInPersonalChatDAO().getBlockedUserByUserId(userIdInDB, adminIdInDB)
                var isBLocked = false
                if (blockedUserInDB != null) {
                    if (blockedUserInDB.blockedUserId == userIdInDB) {
                        if (blockedUserInDB.adminId == adminIdInDB) {
                            val currentTime = System.currentTimeMillis()
                            val blockedUntil = blockedUserInDB.blockedUntilInMillis
                            if (currentTime <= blockedUntil) {
                                isBLocked = true
                            } else {
                                db.blockedUserInPersonalChatDAO().delete(blockedUserInDB)
                            }
                        }
                    }
                }
                habApp.uiScope.launch {
                    if (isBLocked) {
                        showToast(habApp, "ВЫ заблокированы!")
                    } else {
                        val intentChatActivity = Intent(habApp, PersonalChatActivity::class.java)
                        intentChatActivity.putExtra("toUserId", peerId)
                        intentChatActivity.putExtra("toUserName", peerName)
                        startActivity(intentChatActivity)
                    }
                }
            }
        }
        imageViewBack.setOnClickListener { view: View? -> onBackPressed() }
        buttonChat.setOnClickListener { view: View? ->
            Utils.showToast(this, "В разработке")
            /*HabApplication.ioScope.launch {
                val sharedPrefs = getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, MODE_PRIVATE)
                val userId = sharedPrefs.getString(Utils.SHARED_PREFS_KEY_USER_ID, "")?:""
                val userIdInDB: Int = userDAO.getUserByUserId(userId).id
                val adminIdInDB: Int = userDAO.getUserByUserId(peerId).id
                val blockedUserInDB = db.blockedUserInCollectiveChatDAO().getBlockedUserByUserId(userIdInDB, adminIdInDB)
                var isBLocked = false
                //val isAdminOn = intent.getBooleanExtra("is_admin_on", false)
                //var isAdminOn = false
                /*habApp.chatAPIService.getAdminStatus(userId, peerId).onEach {
                    isAdminOn = it.isAdminOn
                }.onEmpty {

                }.catch { e->
                    // todo: process error
                }.collect()*/
                // check if the user is not blocked by adminId(use db info)
                if (blockedUserInDB != null) {
                    if (blockedUserInDB.blockedUserId == userIdInDB) {
                        if (blockedUserInDB.adminId == adminIdInDB) {
                            val currentTime = System.currentTimeMillis()
                            val blockedUntil = blockedUserInDB.blockedUntilInMillis
                            if (currentTime <= blockedUntil) {
                                isBLocked = true
                            } else {
                                db.blockedUserInCollectiveChatDAO().delete(blockedUserInDB)
                            }
                        }
                    }
                }
                habApp.uiScope.launch {
                    if (isBLocked) {
                        showToast(habApp, "ВЫ заблокированы!")
                    } else {
                        val intentProfileChatActivity = Intent(habApp, GroupChatActivity::class.java)
                        intentProfileChatActivity.putExtra("adminId", peerId)
                        intentProfileChatActivity.putExtra("adminName", peerName)
                        //intentProfileChatActivity.putExtra("is_admin_on", isAdminOn)
                        startActivity(intentProfileChatActivity)
                    }
                }
            }*/
        }
        imageViewProfile.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@ProfileFromSearchInRadiusActivity, ProfileActivity::class.java)
            startActivity(intentProfileActivity)
            finish()
        }
        imageViewChat.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@ProfileFromSearchInRadiusActivity, ChatPartnersListActivity::class.java)
            startActivity(intentProfileActivity)
        }
        imageViewSettings.setOnClickListener { view: View? ->
            val intentSettingsActivity = Intent(this@ProfileFromSearchInRadiusActivity, SettingsActivity::class.java)
            startActivity(intentSettingsActivity)
        }
    }
}