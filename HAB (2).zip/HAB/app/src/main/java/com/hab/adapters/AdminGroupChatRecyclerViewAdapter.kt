package com.hab.adapters

import android.content.Context.LAYOUT_INFLATER_SERVICE
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.BLOCKING_TIME_1_HOUR
import com.hab.utils.Utils.BLOCKING_TIME_3_HOURS
import com.hab.utils.Utils.BLOCKING_TIME_5_HOURS
import com.hab.utils.Utils.BLOCKING_TIME_ALWAYS
import com.hab.app.HabApplication
import com.hab.listeners.RespondToMessageCollectiveChatListener
import com.hab.pojo.Message
import com.hab.services.ChatService
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.io.FileOutputStream

class AdminGroupChatRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private var habApp: HabApplication
    private var messageList: List<Message>
    private var respondToMessageCollectiveChatListener: RespondToMessageCollectiveChatListener
    private var adminId: String

    constructor(habApp: HabApplication, messageList: List<Message>, respondToMessageCollectiveChatListener: RespondToMessageCollectiveChatListener, adminId: String) {
        this.habApp = habApp
        this.messageList = messageList
        this.respondToMessageCollectiveChatListener = respondToMessageCollectiveChatListener
        this.adminId = adminId
    }

    internal inner class CustomViewHolder : RecyclerView.ViewHolder {
        //ConstraintLayout layout_item_message;
        var imageViewPartnerPhoto: ShapeableImageView
        var imageViewMyPhoto: ShapeableImageView
        var layoutMessageFromMe: ConstraintLayout
        var layoutMessageFromPartner: ConstraintLayout
        var textViewMessageFromMe: TextView
        var textViewMessageFromPartner: TextView
        var textViewPartnerName: TextView
        var viewAnchor: View
        var viewAnchorBlockingTime: View
        var pos = 0

        constructor(itemView: View):super(itemView) {
            //layout_item_message = itemView.findViewById(R.id.layout_item_message);
            imageViewPartnerPhoto = itemView.findViewById(R.id.image_view_partner_photo)
            imageViewMyPhoto = itemView.findViewById(R.id.image_view_my_photo)
            layoutMessageFromMe = itemView.findViewById(R.id.layout_message_from_me)
            layoutMessageFromPartner = itemView.findViewById(R.id.layout_message_from_partner)
            textViewMessageFromMe = itemView.findViewById(R.id.text_view_message_from_me)
            textViewMessageFromPartner = itemView.findViewById(R.id.text_view_message_from_partner)
            textViewPartnerName = itemView.findViewById(R.id.text_view_partner_name)
            viewAnchor = itemView.findViewById(R.id.view_anchor)
            viewAnchorBlockingTime = itemView.findViewById(R.id.view_anchor_blocking_time)

            var popupWindowRespondOrBlock: PopupWindow? = null
            layoutMessageFromPartner.setOnClickListener {
                val inflater = habApp.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater

                // Inflate the custom layout/view
                val respondOrBlockView = inflater.inflate(R.layout.popup_window_profile_chat_admin_actions, null, false)
                val blockingTimeView = inflater.inflate(R.layout.popup_window_profile_chat_blocking_time, null, false)

                val layoutRespond = respondOrBlockView.findViewById<ConstraintLayout>(R.id.layout_respond)
                layoutRespond.setOnClickListener{
                    //add text like "@userId " to input message edittext
                    respondToMessageCollectiveChatListener.respond(messageList[pos].userName)
                    popupWindowRespondOrBlock?.dismiss()
                }
                val layoutBlockUser = respondOrBlockView.findViewById<ConstraintLayout>(R.id.layout_block_user)
                layoutBlockUser.setOnClickListener{
                    //todo: block user
                    var popupWindowBlockingTime: PopupWindow? = null

                    val layout_1hour = blockingTimeView.findViewById<ConstraintLayout>(R.id.layout_1hour)
                    layout_1hour.setOnClickListener {
                        Utils.showToast(habApp, "Заблокирован на 1 час")
                        // todo: block for 1 hour=3600_000milliseconds
                        HabApplication.ioScope.launch {
                            val userIdToBlock = messageList[pos].userId
                            habApp.chatAPIService.blockUserInGroupChat(userIdToBlock, BLOCKING_TIME_1_HOUR, adminId)
                                    .catch { e->
                                        //todo: process error
                                    }.collect()
                        }
                        popupWindowBlockingTime?.dismiss()
                        popupWindowRespondOrBlock?.dismiss()
                    }
                    val layout_3hours = blockingTimeView.findViewById<ConstraintLayout>(R.id.layout_3hours)
                    layout_3hours.setOnClickListener {
                        Utils.showToast(habApp, "Заблокирован на 3 часа")
                        // todo: block for 3 hours
                        HabApplication.ioScope.launch {
                            val userIdToBlock = messageList[pos].userId
                            habApp.chatAPIService.blockUserInGroupChat(userIdToBlock, BLOCKING_TIME_3_HOURS, adminId)
                                    .catch { e->
                                        //todo: process error
                                    }.collect()
                        }
                        popupWindowBlockingTime?.dismiss()
                        popupWindowRespondOrBlock?.dismiss()
                    }
                    val layout_5hours = blockingTimeView.findViewById<ConstraintLayout>(R.id.layout_5hours)
                    layout_5hours.setOnClickListener {
                        Utils.showToast(habApp, "Заблокирован на 5 часов")
                        // todo: block for 5 hous
                        HabApplication.ioScope.launch {
                            val userIdToBlock = messageList[pos].userId
                            habApp.chatAPIService.blockUserInGroupChat(userIdToBlock, BLOCKING_TIME_5_HOURS, adminId)
                                    .catch { e->
                                        //todo: process error
                                    }.collect()
                        }
                        popupWindowBlockingTime?.dismiss()
                        popupWindowRespondOrBlock?.dismiss()
                    }
                    val layout_forever = blockingTimeView.findViewById<ConstraintLayout>(R.id.layout_forever)
                    layout_forever.setOnClickListener {
                        Utils.showToast(habApp, "Заблокирован навсегда")
                        // todo: block always
                        HabApplication.ioScope.launch {
                            val userIdToBlock = messageList[pos].userId
                            habApp.chatAPIService.blockUserInGroupChat(userIdToBlock, BLOCKING_TIME_ALWAYS, adminId)
                                    .catch { e->
                                        //todo: process error
                                    }.collect()
                        }
                        popupWindowBlockingTime?.dismiss()
                        popupWindowRespondOrBlock?.dismiss()
                    }

                    popupWindowBlockingTime = PopupWindow(blockingTimeView,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT)
                    popupWindowBlockingTime.setOutsideTouchable(true)
                    popupWindowBlockingTime.setFocusable(true)
                    popupWindowBlockingTime.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    if (messageList.size > 3 && (pos == (messageList.size - 1) || pos == (messageList.size - 2))) {
                        val marginTopDp = -270.0f//-100.0f
                        val marginTopPx = (marginTopDp * habApp.resources.displayMetrics.density).toInt()// - popupWindowBlockingTime.getHeight()
                        val marginRightDp = 90.0f
                        val marginRightPx = (marginRightDp * habApp.resources.displayMetrics.density).toInt()
                        //val location = IntArray(2)
                        //view_anchor_blocking_time.getLocationOnScreen(location)
                        //popupWindowBlockingTime?.showAtLocation(view_anchor_blocking_time, Gravity.NO_GRAVITY,location[0], location[1] - marginTopPx - popupWindowBlockingTime.getHeight())
                        popupWindowBlockingTime.showAsDropDown(viewAnchorBlockingTime, 0, marginTopPx)
                    } else {
                        popupWindowBlockingTime.showAsDropDown(viewAnchorBlockingTime, 0, 0)
                    }
                }
                popupWindowRespondOrBlock = PopupWindow(respondOrBlockView,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT)
                popupWindowRespondOrBlock?.setOutsideTouchable(true)
                //popupWindow.setTouchable(true)
                popupWindowRespondOrBlock?.setFocusable(true)
                popupWindowRespondOrBlock?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                /*popupWindow.setTouchInterceptor((v, event) -> {
                    popupWindow.dismiss()
                    return true
                });*/
                popupWindowRespondOrBlock?.showAsDropDown(viewAnchor, 0, 0)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message_profile_chat, parent, false)
        return CustomViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val customViewHolder = holder as CustomViewHolder
        customViewHolder.pos = position
        val message = messageList[position]
        if (message.isFromPartner) {
            customViewHolder.layoutMessageFromPartner.visibility = View.VISIBLE
            customViewHolder.layoutMessageFromMe.visibility = View.INVISIBLE
            customViewHolder.textViewMessageFromPartner.text = message.text
            customViewHolder.textViewPartnerName.text = message.userName
            val imageFileName = "${habApp.filesDir.absolutePath}/${message.userId}"
            val imageUri = Uri.parse(imageFileName)
            val imageDrawable = Drawable.createFromPath(imageUri.path)
            if (imageDrawable != null) {
                customViewHolder.imageViewPartnerPhoto.setImageDrawable(imageDrawable)
            } else {
                HabApplication.ioScope.launch {
                    try {
                        var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                        val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(message.userId)

                        downloadImageResponseFlow.onEach { downloadImageResponse ->
                            val responseCode = downloadImageResponse.responseCode
                            when (responseCode) {
                                1 -> {//keep reading file
                                    val buffer = downloadImageResponse.fileChunk.toByteArray()
                                    fileImageStream?.write(buffer)
                                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                                }
                                2 -> {//End of file reached
                                    fileImageStream?.flush()
                                    fileImageStream?.close()
                                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                                    val imageUri = Uri.parse(imageFileName)
                                    val imageDrawable = Drawable.createFromPath(imageUri.path)
                                    if (imageDrawable != null) {
                                        habApp.uiScope.launch {
                                            customViewHolder.imageViewPartnerPhoto.setImageDrawable(imageDrawable)
                                        }
                                    } else {
                                        habApp.uiScope.launch {
                                            val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                            customViewHolder.imageViewPartnerPhoto.setImageDrawable(userPhotoStub)
                                        }
                                    }
                                }
                                -1 -> {//error
                                    //todo: error
                                    fileImageStream?.close()
                                    fileImageStream = null
                                    habApp.uiScope.launch {
                                        val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                        customViewHolder.imageViewPartnerPhoto.setImageDrawable(userPhotoStub)
                                    }
                                }
                            }
                        }.onEmpty {
                            Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                        }.catch { e ->

                        }.collect()
                    } catch (e: FileNotFoundException) {
                        Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
                    }
                }
            }

        } else {
            customViewHolder.layoutMessageFromMe.visibility = View.VISIBLE
            customViewHolder.layoutMessageFromPartner.visibility = View.INVISIBLE
            customViewHolder.textViewMessageFromMe.text = message.text
            val imageFileName = "${habApp.filesDir.absolutePath}/${message.userId}"
            val imageUri = Uri.parse(imageFileName)
            val imageDrawable = Drawable.createFromPath(imageUri.path)
            if (imageDrawable != null) {
                customViewHolder.imageViewMyPhoto.setImageDrawable(imageDrawable)
            } else {
                val sharedPreferencesUserInfo = habApp.getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, AppCompatActivity.MODE_PRIVATE)
                val userImageName = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_IMAGE, "")?: ""
                if (userImageName != "") {
                    val imageUri = Uri.parse(userImageName)
                    val imageStream = habApp.contentResolver.openInputStream(imageUri)
                    val selectedImage = BitmapFactory.decodeStream(imageStream)
                    imageStream?.close()

                    val resizedImage = Bitmap.createScaledBitmap(selectedImage, 200, 200, false)
                    //val resizedImage = Bitmap.createBitmap(selectedImage, 0,0,width, height)

                    customViewHolder.imageViewMyPhoto.setImageBitmap(resizedImage)
                }
            }

        }
    }

    override fun getItemCount(): Int {
        return messageList.size
    }
}