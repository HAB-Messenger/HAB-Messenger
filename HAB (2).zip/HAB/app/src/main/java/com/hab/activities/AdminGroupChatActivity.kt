package com.hab.activities

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupWindow
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener
import com.google.android.material.tabs.TabLayoutMediator
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils.SHARED_PREFS
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG
import com.hab.utils.Utils.SHARED_PREFS_KEY_IS_ADMIN_ON
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_DESCRIPTION
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_NAME
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_STATUS
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_STATUS_COLOR
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.adapters.ProfileTabsAdapter
import com.hab.app.HabApplication
import com.hab.fragments.AdminGroupChatOffFragment
import com.hab.fragments.AdminGroupChatOnFragment
import com.hab.services.ChatService
import com.hab.services.PushNotificationsService
import com.hab.utils.Utils
import com.hab.utils.Utils.DEFAULT_VISIBILITY_RADIUS_IN_METERS
import com.hab.utils.Utils.STATUS_COLOR_WHITE
import com.hab.utils.Utils.showToast
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AdminGroupChatActivity : AppCompatActivity {

    lateinit var habApp: HabApplication
    lateinit var sharedPreferences: SharedPreferences
    lateinit var sharedPreferencesUserInfo: SharedPreferences

    lateinit var tabLayout: TabLayout
    lateinit var viewPager: ViewPager2
    lateinit var layoutBottomNav: ConstraintLayout
    private var isAdminChatOn = false

    private lateinit var userId: String

    constructor() : super(R.layout.activity_admin_group_chat) {

    }

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Чат"

        if (Utils.isServiceRunning(this, ChatService::class.java) == false) {
            Utils.startChatServiceService(this)
        }
        if (Utils.isServiceRunning(this, PushNotificationsService::class.java) == false) {
            Utils.startPushNotificationsServiceService(this)
        }

        sharedPreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE)
        sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, Context.MODE_PRIVATE)
        isAdminChatOn = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_ADMIN_ON, false)

        userId = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""

        habApp = application as HabApplication

        val moreActions = findViewById<ImageView>(R.id.more_actions)
        val viewAnchor = findViewById<View>(R.id.view_anchor)
        val imageViewInRadius = findViewById<ImageView>(R.id.image_view_in_radius)
        val imageViewChat = findViewById<ImageView>(R.id.image_view_chat)
        val imageViewSettings = findViewById<ImageView>(R.id.image_view_settings)
        val profileTabsAdapter = ProfileTabsAdapter(supportFragmentManager, lifecycle)

        val intentAdminResponsibilityWarningActivity = Intent(this, AdminResponsibilityWarningActivity::class.java)
        startActivity(intentAdminResponsibilityWarningActivity)

        val adminCollectiveChatOnFragment = AdminGroupChatOnFragment()

        var popupWindow: PopupWindow? = null
        moreActions.setOnClickListener {
            val inflater =  this.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater

            // Inflate the custom layout/view
            val customView = inflater.inflate(R.layout.popup_window_profile_chat_more_actions,null)
            val layoutBlockUser = customView.findViewById<ConstraintLayout>(R.id.layout_clear_chat)
            layoutBlockUser.setOnClickListener{
                showToast(this, "Чат удалён")
                // clear chat: remove all messages from all chat peers, including chat admin
                adminCollectiveChatOnFragment.clearChat()
                popupWindow?.dismiss()
            }
            popupWindow = PopupWindow(customView,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT)
            popupWindow?.setOutsideTouchable(true)
            //popupWindow.setTouchable(true)
            popupWindow?.setFocusable(true)
            popupWindow?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            /*popupWindow.setTouchInterceptor((v, event) -> {
                popupWindow.dismiss()
                return true
            });*/
            popupWindow?.showAsDropDown(viewAnchor, 0, 0)
        }

        layoutBottomNav = findViewById(R.id.layout_bottom_nav)
        tabLayout = findViewById(R.id.tab_layout)
        viewPager = findViewById(R.id.view_pager)
        viewPager.setUserInputEnabled(false)


        adminCollectiveChatOnFragment.adminId = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""
        profileTabsAdapter.addFragment(adminCollectiveChatOnFragment)
        profileTabsAdapter.addFragment(AdminGroupChatOffFragment())
        viewPager.adapter = profileTabsAdapter
        TabLayoutMediator(tabLayout, viewPager) { tab: TabLayout.Tab, position: Int ->
            if (position == 0) {
                tab.text = "On"
            } else if (position == 1) {
                tab.text = "Off"
            }
        }.attach()
        //tabLayout.setScrollPosition(1, 0f, true)
        //viewPager.currentItem = 1
        imageViewInRadius.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@AdminGroupChatActivity, SearchInRadiusActivity::class.java)
            startActivity(intentProfileActivity)
            finish()
        }
        imageViewChat.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@AdminGroupChatActivity, ChatPartnersListActivity::class.java)
            startActivity(intentProfileActivity)
        }
        imageViewSettings.setOnClickListener { view: View? ->
            val intentSettingsActivity = Intent(this@AdminGroupChatActivity, SettingsActivity::class.java)
            startActivity(intentSettingsActivity)
        }

        HabApplication.ioScope.launch {
            val sharedPrefsCurrentCoords = getSharedPreferences(SHARED_PREFS_CURRENT_COORDINATES, Service.MODE_PRIVATE)
            val lat = Double.Companion.fromBits(sharedPrefsCurrentCoords.getLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT, 0))
            val lng = java.lang.Double.longBitsToDouble(sharedPrefsCurrentCoords.getLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG, 0))

            // get searchingInRadius from user settings
            val visibleInRadius = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS, DEFAULT_VISIBILITY_RADIUS_IN_METERS)
            val userStatus = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_STATUS, "")?:""
            val userStatusColorId = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
            val userName = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_NAME, "")?:""
            val userDescription = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_DESCRIPTION, "")?:""
            /*if (habApp.adminSearchingPeerResponse == null) {
                habApp.adminSearchingPeerResponse = habApp.chatAPIService.searchingPeer(userId, lat, lng, visibleInRadius, userStatus, userStatusColorId, userName, userDescription, true)
                habApp.adminSearchingPeerResponse?.onEach {

                }?.onEmpty {

                }?.catch { e ->
                    //todo: solve error
                }?.collect()
            }*/
            /*habApp.chatAPIService.searchingPeer(userId, lat, lng, visibleInRadius, userStatus, userStatusColorId, userName, userDescription, true)
                    .catch {e->
                        Utils.showToast(habApp, "Searching peer: ${e.message}")
                    }
                    .collect()*/
        }
    }

    override fun onStart() {
        super.onStart()

        if (isAdminChatOn == false) {
            tabLayout.setScrollPosition(1, 0f, true)
            viewPager.currentItem = 1
        }

        when(tabLayout.selectedTabPosition) {
            0-> {
                val colorTabGreen = ResourcesCompat.getColor(resources, R.color.colorTabGreen, null)
                tabLayout.setSelectedTabIndicatorColor(colorTabGreen)
                HabApplication.ioScope.launch {
                    habApp.chatAPIService.adminStatus(userId,true)
                }
            }
            1-> {
                val colorTabRed = ResourcesCompat.getColor(resources, R.color.colorTabRed, null)
                tabLayout.setSelectedTabIndicatorColor(colorTabRed)
                layoutBottomNav.visibility = View.VISIBLE
                HabApplication.ioScope.launch {
                    habApp.chatAPIService.adminStatus(userId,false)
                }
            }
        }
        tabLayout.addOnTabSelectedListener(object : OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> {
                        isAdminChatOn = true
                        tabLayout.setSelectedTabIndicatorColor(ResourcesCompat.getColor(resources, R.color.colorTabGreen, null))
                        layoutBottomNav.visibility = View.GONE
                        HabApplication.ioScope.launch {
                            habApp.chatAPIService.adminStatus(userId,true)
                        }
                    }
                    1 -> {
                        isAdminChatOn = false
                        tabLayout.setSelectedTabIndicatorColor(ResourcesCompat.getColor(resources, R.color.colorTabRed, null))
                        layoutBottomNav.visibility = View.VISIBLE
                        HabApplication.ioScope.launch {
                            habApp.chatAPIService.adminStatus(userId,false)
                        }
                    }
                }
                sharedPreferences.edit()
                        .putBoolean(SHARED_PREFS_KEY_IS_ADMIN_ON, isAdminChatOn)
                        .apply()
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                if (isAdminChatOn == true) {
                    HabApplication.ioScope.launch {
                        habApp.chatAPIService.groupChatClosed(userId,true)
                                .catch {e->
                                    //todo: solve error
                                }
                                .collect()
                        habApp.uiScope.launch {
                            finish()
                        }
                    }
                } else {
                    finish()
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        HabApplication.ioScope.launch {
            habApp.chatAPIService.groupChatClosed(userId,true)
                    .catch {e->
                        //todo: solve error
                    }
                    .collect()
            habApp.uiScope.launch {
                finish()
            }
        }
        super.onBackPressed()
    }
}