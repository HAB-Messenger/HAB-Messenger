package com.hab.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
class MessageDBEntity {
    @PrimaryKey(autoGenerate = true)
    var id = 0

    @ColumnInfo(name = "from_user_id")
    var fromUserId = 0

    @ColumnInfo(name = "to_user_id")
    var toUserId = 0

    var message: String = ""

    @ColumnInfo(name = "is_read")
    var isRead: Boolean = false
}