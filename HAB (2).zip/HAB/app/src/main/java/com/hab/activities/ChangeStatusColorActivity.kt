package com.hab.activities

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_STATUS_COLOR
import com.hab.utils.Utils.STATUS_COLOR_BLUE
import com.hab.utils.Utils.STATUS_COLOR_GRAY
import com.hab.utils.Utils.STATUS_COLOR_GREEN
import com.hab.utils.Utils.STATUS_COLOR_LILAC
import com.hab.utils.Utils.STATUS_COLOR_ORANGE
import com.hab.utils.Utils.STATUS_COLOR_RED
import com.hab.utils.Utils.STATUS_COLOR_WHITE
import com.hab.utils.Utils.STATUS_COLOR_YELLOW
import com.hab.viewmodels.BillingViewModel


class ChangeStatusColorActivity : AppCompatActivity() {

    private lateinit var layoutStatusColors: ConstraintLayout
    private lateinit var checkedStatusColor: ImageView
    private lateinit var billingViewModel: BillingViewModel
    private var isEnabledStatusColor = false
    private lateinit var sharedPreferencesUserInfo: SharedPreferences
    private var currentlySelectedColor = STATUS_COLOR_WHITE

    /*private val registerForStartSubscriptionActivityGreenColor = registerForActivityResult(StartActivityForResult()) {
        if (isEnabledStatusColor) {
            val constraintSet = ConstraintSet()
            constraintSet.clone(layoutStatusColors)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorGreen, ConstraintSet.RIGHT, 10)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorGreen, ConstraintSet.BOTTOM)
            constraintSet.applyTo(layoutStatusColors)
            checkedStatusColor.visibility = View.VISIBLE
            val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
            sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_GREEN)
            sharedPreferencesUserInfoEditor.apply()
        }
    }
    private val registerForStartSubscriptionActivityRedColor = registerForActivityResult(StartActivityForResult()) {
        if (isEnabledStatusColor) {
            val constraintSet = ConstraintSet()
            constraintSet.clone(layoutStatusColors)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorRed, ConstraintSet.RIGHT, 10)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorRed, ConstraintSet.BOTTOM)
            constraintSet.applyTo(layoutStatusColors)
            checkedStatusColor.visibility = View.VISIBLE
            val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
            sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_RED)
            sharedPreferencesUserInfoEditor.apply()
        }
    }
    private val registerForStartSubscriptionActivityOrangeColor = registerForActivityResult(StartActivityForResult()) {
        if (isEnabledStatusColor) {
            val constraintSet = ConstraintSet()
            constraintSet.clone(layoutStatusColors)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorOrange, ConstraintSet.RIGHT, 10)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorOrange, ConstraintSet.BOTTOM)
            constraintSet.applyTo(layoutStatusColors)
            checkedStatusColor.visibility = View.VISIBLE
            val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
            sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_ORANGE)
            sharedPreferencesUserInfoEditor.apply()
        }
    }
    private val registerForStartSubscriptionActivityLilacColor = registerForActivityResult(StartActivityForResult()) {
        if (isEnabledStatusColor) {
            val constraintSet = ConstraintSet()
            constraintSet.clone(layoutStatusColors)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorLilac, ConstraintSet.RIGHT, 10)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorLilac, ConstraintSet.BOTTOM)
            constraintSet.applyTo(layoutStatusColors)
            checkedStatusColor.visibility = View.VISIBLE
            val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
            sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_LILAC)
            sharedPreferencesUserInfoEditor.apply()
        }
    }
    private val registerForStartSubscriptionActivityBlueColor = registerForActivityResult(StartActivityForResult()) {
        if (isEnabledStatusColor) {
            val constraintSet = ConstraintSet()
            constraintSet.clone(layoutStatusColors)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorBlue, ConstraintSet.RIGHT, 10)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorBlue, ConstraintSet.BOTTOM)
            constraintSet.applyTo(layoutStatusColors)
            checkedStatusColor.visibility = View.VISIBLE
            val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
            sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_BLUE)
            sharedPreferencesUserInfoEditor.apply()
        }
    }
    private val registerForStartSubscriptionActivityYellowColor = registerForActivityResult(StartActivityForResult()) {
        if (isEnabledStatusColor) {
            val constraintSet = ConstraintSet()
            constraintSet.clone(layoutStatusColors)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorYellow, ConstraintSet.RIGHT, 10)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorYellow, ConstraintSet.BOTTOM)
            constraintSet.applyTo(layoutStatusColors)
            checkedStatusColor.visibility = View.VISIBLE
            val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
            sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_YELLOW)
            sharedPreferencesUserInfoEditor.apply()
        }
    }
    private val registerForStartSubscriptionActivityGrayColor = registerForActivityResult(StartActivityForResult()) {
        if (isEnabledStatusColor) {
            val constraintSet = ConstraintSet()
            constraintSet.clone(layoutStatusColors)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorGray, ConstraintSet.RIGHT, 10)
            constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorGray, ConstraintSet.BOTTOM)
            constraintSet.applyTo(layoutStatusColors)
            checkedStatusColor.visibility = View.VISIBLE
            val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
            sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_GRAY)
            sharedPreferencesUserInfoEditor.apply()
        }
    }*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_status_color)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Цвет статуса"

        layoutStatusColors = findViewById(R.id.layout_status_colors)
        checkedStatusColor = findViewById(R.id.checked_status_color)

        billingViewModel = ViewModelProvider(this).get(BillingViewModel::class.java)

        val buttonSave = findViewById<Button>(R.id.button_save)
        buttonSave.setOnClickListener {
            finish()
        }

        sharedPreferencesUserInfo = getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, Context.MODE_PRIVATE)
        val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()

        val colorGreen = findViewById<ShapeableImageView>(R.id.colorGreen)
        colorGreen.setOnClickListener {
            // check if subscription enabled
            currentlySelectedColor = STATUS_COLOR_GREEN
            if (isEnabledStatusColor == false) {
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                sharedPreferencesUserInfoEditor.apply()
                val intentStartSubscriptionActivity = Intent(this@ChangeStatusColorActivity, StartSubscriptionActivity::class.java)
                startActivity(intentStartSubscriptionActivity)
                //registerForStartSubscriptionActivityGreenColor.launch(intentStartSubscriptionActivity)
            } else {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorGreen, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorGreen, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorGreen, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorGreen, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_GREEN)
                sharedPreferencesUserInfoEditor.apply()
            }
        }
        val colorRed = findViewById<ShapeableImageView>(R.id.colorRed)
        colorRed.setOnClickListener {
            // check if subscription enabled
            currentlySelectedColor = STATUS_COLOR_RED
            if (isEnabledStatusColor == false) {
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                sharedPreferencesUserInfoEditor.apply()
                val intentStartSubscriptionActivity = Intent(this@ChangeStatusColorActivity, StartSubscriptionActivity::class.java)
                startActivity(intentStartSubscriptionActivity)
                //registerForStartSubscriptionActivityRedColor.launch(intentStartSubscriptionActivity)
            } else {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorRed, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorRed, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorRed, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorRed, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_RED)
                sharedPreferencesUserInfoEditor.apply()
            }
        }
        val colorOrange = findViewById<ShapeableImageView>(R.id.colorOrange)
        colorOrange.setOnClickListener {
            // check if subscription enabled
            currentlySelectedColor = STATUS_COLOR_ORANGE
            if (isEnabledStatusColor == false) {
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                sharedPreferencesUserInfoEditor.apply()
                val intentStartSubscriptionActivity = Intent(this@ChangeStatusColorActivity, StartSubscriptionActivity::class.java)
                startActivity(intentStartSubscriptionActivity)
                //registerForStartSubscriptionActivityOrangeColor.launch(intentStartSubscriptionActivity)
            } else {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorOrange, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorOrange, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorOrange, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorOrange, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_ORANGE)
                sharedPreferencesUserInfoEditor.apply()
            }
        }
        val colorLilac = findViewById<ShapeableImageView>(R.id.colorLilac)
        colorLilac.setOnClickListener {
            // check if subscription enabled
            currentlySelectedColor = STATUS_COLOR_LILAC
            if (isEnabledStatusColor == false) {
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                sharedPreferencesUserInfoEditor.apply()
                val intentStartSubscriptionActivity = Intent(this@ChangeStatusColorActivity, StartSubscriptionActivity::class.java)
                startActivity(intentStartSubscriptionActivity)
                //registerForStartSubscriptionActivityLilacColor.launch(intentStartSubscriptionActivity)
            } else {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorLilac, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorLilac, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorLilac, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorLilac, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_LILAC)
                sharedPreferencesUserInfoEditor.apply()
            }
        }
        val colorBlue = findViewById<ShapeableImageView>(R.id.colorBlue)
        colorBlue.setOnClickListener {
            // check if subscription enabled
            currentlySelectedColor = STATUS_COLOR_BLUE
            if (isEnabledStatusColor == false) {
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                sharedPreferencesUserInfoEditor.apply()
                val intentStartSubscriptionActivity = Intent(this@ChangeStatusColorActivity, StartSubscriptionActivity::class.java)
                startActivity(intentStartSubscriptionActivity)
                //registerForStartSubscriptionActivityBlueColor.launch(intentStartSubscriptionActivity)
            } else {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorBlue, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorBlue, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorBlue, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorBlue, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_BLUE)
                sharedPreferencesUserInfoEditor.apply()
            }
        }
        val colorYellow = findViewById<ShapeableImageView>(R.id.colorYellow)
        colorYellow.setOnClickListener {
            // check if subscription enabled
            currentlySelectedColor = STATUS_COLOR_YELLOW
            if (isEnabledStatusColor == false) {
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                sharedPreferencesUserInfoEditor.apply()
                val intentStartSubscriptionActivity = Intent(this@ChangeStatusColorActivity, StartSubscriptionActivity::class.java)
                startActivity(intentStartSubscriptionActivity)
                //registerForStartSubscriptionActivityYellowColor.launch(intentStartSubscriptionActivity)
            } else {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorYellow, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorYellow, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorYellow, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorYellow, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_YELLOW)
                sharedPreferencesUserInfoEditor.apply()
            }
        }
        val colorGray = findViewById<ShapeableImageView>(R.id.colorGray)
        colorGray.setOnClickListener {
            // check if subscription enabled
            currentlySelectedColor = STATUS_COLOR_GRAY
            if (isEnabledStatusColor == false) {
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                sharedPreferencesUserInfoEditor.apply()
                val intentStartSubscriptionActivity = Intent(this@ChangeStatusColorActivity, StartSubscriptionActivity::class.java)
                startActivity(intentStartSubscriptionActivity)
                //registerForStartSubscriptionActivityGrayColor.launch(intentStartSubscriptionActivity)
            } else {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorGray, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorGray, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorGray, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorGray, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
                sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_GRAY)
                sharedPreferencesUserInfoEditor.apply()
            }
        }

        billingViewModel.statusColorLiveData.observe(this, {
            it?.apply {
                isEnabledStatusColor = entitled

                if (isEnabledStatusColor == false) {
                    checkedStatusColor.visibility = View.GONE
                    val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
                    sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                    sharedPreferencesUserInfoEditor.apply()
                } else {
                    checkedStatusColor.visibility = View.VISIBLE
                }
                val selectedStatusColor = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                setStatusColor(selectedStatusColor)
                if (currentlySelectedColor != STATUS_COLOR_WHITE) {
                    setStatusColor(currentlySelectedColor)
                    val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
                    sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, currentlySelectedColor)
                    sharedPreferencesUserInfoEditor.apply()
                }
            }
        })
    }

    private fun setStatusColor(selectedStatusColor: Int){
        when(selectedStatusColor) {
            STATUS_COLOR_GREEN -> {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorGreen, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorGreen, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorGreen, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorGreen, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
            }
            STATUS_COLOR_RED -> {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorRed, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorRed, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorRed, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorRed, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
            }
            STATUS_COLOR_ORANGE -> {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorOrange, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorOrange, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorOrange, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorOrange, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
            }
            STATUS_COLOR_LILAC -> {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorLilac, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorLilac, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorLilac, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorLilac, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
            }
            STATUS_COLOR_BLUE -> {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorBlue, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorBlue, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorBlue, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorBlue, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
            }
            STATUS_COLOR_YELLOW -> {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorYellow, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorYellow, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorYellow, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorYellow, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
            }
            STATUS_COLOR_GRAY -> {
                val constraintSet = ConstraintSet()
                constraintSet.clone(layoutStatusColors)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.TOP, R.id.colorGray, ConstraintSet.TOP)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.BOTTOM, R.id.colorGray, ConstraintSet.BOTTOM)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.RIGHT, R.id.colorGray, ConstraintSet.RIGHT)
                constraintSet.connect(R.id.checked_status_color, ConstraintSet.LEFT, R.id.colorGray, ConstraintSet.LEFT)
                constraintSet.applyTo(layoutStatusColors)
                checkedStatusColor.visibility = View.VISIBLE
            }
            STATUS_COLOR_WHITE -> {
                checkedStatusColor.visibility = View.GONE
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}