package com.hab.pojo

data class ChatPartner (var id: String, var name: String, var lastMessage: String, var unreadMessagesCount: Int)