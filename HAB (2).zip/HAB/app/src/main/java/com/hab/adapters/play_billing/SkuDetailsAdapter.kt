/**
 * Copyright (C) 2018 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hab.adapters.play_billing

import android.content.res.Resources
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.hab.R
import com.hab.db.entities.play_billing.AugmentedSkuDetails

/**
 * This is an [AugmentedSkuDetails] adapter. It can be used anywhere there is a need to display a
 * list of AugmentedSkuDetails. In this app it's used to display both the list of subscriptions and
 * the list of in-app products.
 */
open class SkuDetailsAdapter : RecyclerView.Adapter<SkuDetailsAdapter.SkuDetailsViewHolder>() {

    private var skuDetailsList = emptyList<AugmentedSkuDetails>()

    override fun getItemCount() = skuDetailsList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SkuDetailsViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
                R.layout.inventory_item, parent, false
        )
        return SkuDetailsViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: SkuDetailsViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    fun getItem(position: Int) = if (skuDetailsList.isEmpty()) null else skuDetailsList[position]

    fun setSkuDetailsList(list: List<AugmentedSkuDetails>) {
        if (list != skuDetailsList) {
            skuDetailsList = list
            notifyDataSetChanged()
        }
    }

    /**
     * In the spirit of keeping simple things simple: this is a friendly way of allowing clients
     * to listen to clicks. You should consider doing this for all your other adapters.
     */
    open fun onSkuDetailsClicked(item: AugmentedSkuDetails) {
        //clients to implement for callback if needed
    }

    inner class SkuDetailsViewHolder : RecyclerView.ViewHolder {
        val skuTitle: AppCompatTextView
        val skuPrice: AppCompatTextView
        val skuImage: AppCompatImageView
        val skuDescription: AppCompatTextView

        constructor(itemView: View): super(itemView) {
            skuTitle = itemView.findViewById(R.id.sku_title)
            skuPrice = itemView.findViewById(R.id.sku_price)
            skuImage = itemView.findViewById(R.id.sku_image)
            skuDescription = itemView.findViewById(R.id.sku_description)
            itemView.setOnClickListener {
                getItem(adapterPosition)?.let { onSkuDetailsClicked(it) }
            }
        }

        fun bind(item: AugmentedSkuDetails?) {
            item?.apply {
                itemView.apply {
                    val name = title?.substring(0, title.indexOf("("))
                    skuTitle.text = name
                    skuPrice.text = price
                    skuDescription.text = description
                    //val drawableId = getSkuDrawableId(sku, this)
                    //skuImage.setImageResource(drawableId)
                    isEnabled = canPurchase
                    onDisabled(canPurchase, resources)
                }
            }
        }

        private fun onDisabled(enabled: Boolean, res: Resources) {
            if (enabled) {
                itemView.apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        setBackgroundColor(res.getColor(R.color.colorAccentLight, context.theme))
                        skuTitle.setTextColor(res.getColor(R.color.textColor, context.theme))
                        skuDescription.setTextColor(res.getColor(R.color.textColor, context.theme))
                        skuPrice.setTextColor(res.getColor(R.color.textColor, context.theme))
                    } else {
                        setBackgroundColor(ContextCompat.getColor(context, R.color.colorAccentLight))
                        skuTitle.setTextColor(res.getColor(R.color.textColor))
                        skuDescription.setTextColor(res.getColor(R.color.textColor))
                        skuPrice.setTextColor(res.getColor(R.color.textColor))
                    }
                    skuImage.setColorFilter(null)
                }
            } else {
                itemView.apply {
                    var color = ContextCompat.getColor(context, R.color.imgDisableHint)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        setBackgroundColor(res.getColor(R.color.textDisabledHint, context.theme))
                        color = res.getColor(R.color.imgDisableHint, context.theme)
                    }

                    skuImage.setColorFilter(color)
                    skuTitle.setTextColor(color)
                    skuDescription.setTextColor(color)
                    skuPrice.setTextColor(color)
                }
            }
        }

        /**
         * Keeping simple things simple, the icons are named after the SKUs. This way, there is no
         * need to create some elaborate system for matching icons to SKUs when displaying the
         * inventory to users. It is sufficient to do
         *
         * ```
         * sku_image.setImageResource(resources.getIdentifier(sku, "drawable", view.context.packageName))
         *
         * ```
         *
         * Alternatively, in the case where more than one SKU should match the same drawable,
         * you can check with a when{} block. In this sample app, for instance, both gold_monthly and
         * gold_yearly should match the same gold_subs_icon; so instead of keeping two copies of
         * the same icon, when{} is used to set imgName
         */
        /*private fun getSkuDrawableId(sku: String, view: View): Int {
            val imgName: String = when {
                sku.startsWith("gold_") -> "gold_subs_icon"
                else -> sku
            }
            val drawableId = view.resources.getIdentifier(imgName, "drawable",
                    view.context.packageName)
            return drawableId
        }*/
    }
}