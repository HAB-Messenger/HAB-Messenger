package com.hab.pojo

class RadiusAndListOfPeopleInRadius {
    var textRadius: String? = null// for e.g. textRadius = "10 метров"
    var radiusDistanceInMeters = 0
    var personInRadiusList: MutableList<PersonInRadius>? = null

    constructor() {}
    constructor(radiusDistanceInMeters: Int) {
        this.radiusDistanceInMeters = radiusDistanceInMeters
    }
}