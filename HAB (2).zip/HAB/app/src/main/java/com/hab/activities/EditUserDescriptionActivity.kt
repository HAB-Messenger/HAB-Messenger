package com.hab.activities

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_DESCRIPTION
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO

class EditUserDescriptionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_user_description)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        val editTextDescription = findViewById<EditText>(R.id.edit_text_description)
        val textViewNumberOfChars = findViewById<TextView>(R.id.text_view_number_of_chars)
        val buttonSave = findViewById<Button>(R.id.button_save)

        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)

        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Описание"
        val userPrefs = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        val previousDescription = userPrefs.getString(SHARED_PREFS_KEY_USER_DESCRIPTION, "")

        editTextDescription.setHorizontallyScrolling(false);
        editTextDescription.setMaxLines(100);
        editTextDescription.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                val len = editTextDescription.text.length
                textViewNumberOfChars.setText("${len}/150")
            }

        })
        editTextDescription.setText(previousDescription)

        buttonSave.setOnClickListener { view: View? ->
            val descriptionText = editTextDescription.getText().toString()

            val userPrefsEditor = userPrefs.edit()
            userPrefsEditor.putString(SHARED_PREFS_KEY_USER_DESCRIPTION, descriptionText)
            userPrefsEditor.apply()
            val resultIntent = Intent()
            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}