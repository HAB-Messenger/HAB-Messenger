package com.hab.listeners

interface RemovePersonalChatListener {
    fun removePersonalChat(positionIndexInChatPartnerList:Int)
}