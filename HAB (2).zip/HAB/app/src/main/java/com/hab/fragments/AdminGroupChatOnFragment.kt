package com.hab.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.hab.R
import com.hab.utils.Utils
import com.hab.adapters.AdminGroupChatRecyclerViewAdapter
import com.hab.app.HabApplication
import com.hab.grpc.chatservice.ClearCollectiveChatResponse
import com.hab.grpc.chatservice.CollectiveChatClosedResponse
import com.hab.grpc.chatservice.NewCollectiveMessageResponse
import com.hab.grpc.chatservice.TypingMessageResponse
import com.hab.listeners.RespondToMessageCollectiveChatListener
import com.hab.pojo.Message
import com.hab.services.ChatService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*

class AdminGroupChatOnFragment : Fragment() {

    private lateinit var habApp: HabApplication
    private lateinit var recyclerViewChat: RecyclerView

    private lateinit var newCollectiveMessageResponse: Flow<NewCollectiveMessageResponse>
    private lateinit var typingMessageResponse: Flow<TypingMessageResponse>
    private lateinit var collectiveChatClosedResponse: Flow<CollectiveChatClosedResponse>
    private lateinit var clearCollectiveChatResponse: Flow<ClearCollectiveChatResponse>

    private lateinit var respondToMessageCollectiveChatListener: RespondToMessageCollectiveChatListener

    private val messageList: MutableList<Message> = ArrayList()

    var adminId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        habApp = requireActivity().application as HabApplication
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val rootView = inflater.inflate(R.layout.fragment_profile_on_chat, container, false)
        //val textViewTypingMsg = rootView.findViewById<TextView>(R.id.text_view_typing_msg)
        val animationViewTypingMsg = rootView.findViewById<LottieAnimationView>(R.id.animation_view_typing_msg)
        recyclerViewChat = rootView.findViewById(R.id.recycler_view_chat)
        val editTextInput = rootView.findViewById<EditText>(R.id.edit_text_input)
        val buttonSendMsg = rootView.findViewById<ImageButton>(R.id.button_send_msg)
        /*for (i in 0..49) {
            val message = Message()
            if (i % 2 == 0) {
                message.isFromPartner = false
            } else {
                message.isFromPartner = true
            }
            message.text = "dfgfdgfdgdfgfdgfdgdfgfdgfdgdfgfdgfdg"
            messageList.add(message)
        }*/
        respondToMessageCollectiveChatListener = object: RespondToMessageCollectiveChatListener {
            override fun respond(userName: String) {
                val toUserName = "@${userName} "
                editTextInput.setText(toUserName)
                editTextInput.setSelection(toUserName.length)
                editTextInput.requestFocus()
            }
        }
        val profileChatRecyclerViewAdapter = AdminGroupChatRecyclerViewAdapter(habApp, messageList, respondToMessageCollectiveChatListener, adminId)
        recyclerViewChat.setLayoutManager(LinearLayoutManager(context))
        recyclerViewChat.setAdapter(profileChatRecyclerViewAdapter)
        editTextInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun afterTextChanged(editable: Editable) {
                if (editTextInput.text.toString() == "") {
                    buttonSendMsg.setBackgroundResource(R.drawable.shape_button_send_msg)
                } else {
                    buttonSendMsg.setBackgroundResource(R.drawable.shape_pressed_button_send_msg)
                    HabApplication.ioScope.launch {
                        habApp.chatAPIService.typingGroupMessage(userId = adminId)
                                .catch { e->
                                    //todo: solve error
                                }.collect()
                    }
                }
            }
        })
        HabApplication.ioScope.launch {
            newCollectiveMessageResponse = habApp.chatAPIService.newGroupMessage("", "", adminId = adminId, isAdmin = true)
            newCollectiveMessageResponse.onEach {
                val responseCode = it.responseCode
                when(responseCode) {
                    1 -> {
                        if (it.message != "") {
                            habApp.uiScope.launch {
                                val message = Message(it.message, true, it.userId, it.userName)
                                //message.isFromPartner = true
                                //message.text = it.message
                                //message.userName = it.userName
                                //message.userId = it.userId
                                messageList.add(message)
                                profileChatRecyclerViewAdapter.notifyDataSetChanged()
                                recyclerViewChat.smoothScrollToPosition(profileChatRecyclerViewAdapter.itemCount)
                            }
                        }
                        Log.d("ChatAPIService", "newCollectiveMessage: success!")
                    }
                }
            }.onEmpty{
                Log.d("ChatAPIService","newCollectiveMessage: nothing")
            }.catch{ e ->
                Log.d("ChatAPIService","newCollectiveMessage error: ${e.message}")
            }.collect()
        }
        HabApplication.ioScope.launch {
            typingMessageResponse = habApp.chatAPIService.typingGroupMessage(userId = adminId)
            typingMessageResponse.onEach {
                val responseCode = it.responseCode
                when(responseCode) {
                    1 -> {
                        habApp.uiScope.launch {
                            animationViewTypingMsg.visibility = View.VISIBLE
                            animationViewTypingMsg.playAnimation()
                            //textViewTypingMsg.visibility = View.VISIBLE
                            /*image_view_typing_msg.visibility = View.VISIBLE
                            val drawable = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                image_view_typing_msg.drawable as AnimatedVectorDrawable
                            } else {
                                image_view_typing_msg.drawable
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                if (drawable is AnimatedVectorDrawable) {
                                    drawable.start()
                                }
                            }*/
                            Handler(Looper.getMainLooper()).postDelayed({
                                animationViewTypingMsg.cancelAnimation()
                                animationViewTypingMsg.visibility = View.INVISIBLE
                                //textViewTypingMsg.visibility = View.INVISIBLE
                                //image_view_typing_msg.visibility = View.INVISIBLE
                            }, 2000)
                        }
                        Log.d("ChatAPIService", "typingMessage: success!")
                    }
                }

            }.onEmpty {
                Log.d("ChatAPIService","typingMessage: nothing")
            }.catch { e ->
                Log.d("ChatAPIService","typingMessage error: ${e.message}")
            }.collect()
        }
        HabApplication.ioScope.launch {
            collectiveChatClosedResponse = habApp.chatAPIService.groupChatClosed(adminId,false)
            collectiveChatClosedResponse.onEach {
                habApp.uiScope.launch {
                    Utils.showToast(habApp, "Собеседник вышел из чата")
                    //finish()
                }
            }.onEmpty {
                Log.d("ChatAPIService","collectiveChatClosed: nothing")
            }.catch { e->
                Log.d("ChatAPIService","collectiveChatClosed error: ${e.message}")
            }.collect()
        }
        HabApplication.ioScope.launch {
            clearCollectiveChatResponse = habApp.chatAPIService.clearGroupChat(adminId, userId = "")
            clearCollectiveChatResponse.onEach {

            }.onEmpty {

            }.catch { e->

            }.collect()
        }
        buttonSendMsg.setOnClickListener { view: View? ->
            val messageText = editTextInput.text.toString()
            if (messageText != "") {
                editTextInput.setText("")
                val message = Message(messageText)
                //message.isFromPartner = false
                //message.text = messageText
                messageList.add(message)
                profileChatRecyclerViewAdapter.notifyDataSetChanged()
                recyclerViewChat.smoothScrollToPosition(profileChatRecyclerViewAdapter.itemCount)
                HabApplication.ioScope.launch {
                    val userPrefs = context?.getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, AppCompatActivity.MODE_PRIVATE)
                    val userName = userPrefs?.getString(Utils.SHARED_PREFS_KEY_USER_NAME, "")?:""
                    habApp.chatAPIService.newGroupMessage("", messageText, adminId = adminId, userName = userName, isAdmin = true)
                            .catch { e->
                                //todo: process error
                            }.collect()
                }
            }
        }
        return rootView
    }

    override fun onResume() {
        super.onResume()
        val itemsNum = recyclerViewChat.adapter?.itemCount?:0
        if (itemsNum > 0) {
            recyclerViewChat.smoothScrollToPosition(itemsNum - 1)
        }
    }

    fun clearChat() {
        HabApplication.ioScope.launch {
            habApp.chatAPIService.clearGroupChat(adminId, true, "")
                    .catch { e ->
                        // todo: process error
                    }.collect()
        }
        messageList.clear()
        recyclerViewChat.adapter?.notifyDataSetChanged()
    }
}