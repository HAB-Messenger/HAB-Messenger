package com.hab.db.dao

import androidx.room.*
import com.hab.db.entities.UserDBEntity

@Dao
interface UserDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(user: UserDBEntity?)

    @Query("INSERT INTO users(user_id,user_name) SELECT :userID, :userName WHERE NOT EXISTS(SELECT user_id,user_name FROM users WHERE user_id = :userID);")
    fun insert(userID: String?, userName: String?)

    @get:Query("SELECT * FROM users")
    val users: List<UserDBEntity>

    @Query("SELECT * FROM users WHERE users.user_id LIKE :userID")
    fun getUserByUserId(userID: String): UserDBEntity

    @Update
    fun update(user: UserDBEntity?)

    @Delete
    fun delete(user: UserDBEntity?)

    @Query("DELETE FROM users")
    fun deleteAll()
}