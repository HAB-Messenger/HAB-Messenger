package com.hab.fragments

import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.GENDER_ALL
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_AGE
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_DESCRIPTION
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_GENDER
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_NAME
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_STATUS
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_STATUS_COLOR
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.adapters.AllPossibleRadiusesRecyclerViewAdapter
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.db.entities.UserDBEntity
import com.hab.grpc.chatservice.SearchingPeerResponse
import com.hab.pojo.PersonInRadius
import com.hab.pojo.RadiusAndListOfPeopleInRadius
import com.hab.services.ChatService
import com.hab.utils.Utils.DEFAULT_AGE
import com.hab.utils.Utils.DEFAULT_MAX_AGE
import com.hab.utils.Utils.DEFAULT_MIN_AGE
import com.hab.utils.Utils.DEFAULT_SEARCHING_CITY
import com.hab.utils.Utils.DEFAULT_VISIBILITY_RADIUS_IN_METERS
import com.hab.utils.Utils.RADIUS_1000_METERS
import com.hab.utils.Utils.RADIUS_100_METERS
import com.hab.utils.Utils.RADIUS_10_METERS
import com.hab.utils.Utils.RADIUS_15000_METERS
import com.hab.utils.Utils.RADIUS_250_METERS
import com.hab.utils.Utils.RADIUS_30000_METERS
import com.hab.utils.Utils.RADIUS_5000_METERS
import com.hab.utils.Utils.RADIUS_500_METERS
import com.hab.utils.Utils.RADIUS_50_METERS
import com.hab.utils.Utils.RADIUS_ALL_METERS
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_NO_PEER
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_PEER_CLOSED
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_PEER_OUT_OF_RADIUS
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_CITY_NOT_FOUND
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_OFF
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_SUCCESS
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_CITY
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_IMAGE
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY
import com.hab.utils.Utils.STATUS_COLOR_WHITE
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import kotlin.coroutines.cancellation.CancellationException

class InRadiusVisibleFragment : Fragment {

    private lateinit var habApp: HabApplication
    private var allPossibleRadiusesRecyclerViewAdapter: AllPossibleRadiusesRecyclerViewAdapter? = null

    private var userID: String=""

    private lateinit var sharedPreferencesUserInfo: SharedPreferences
    private var recyclerViewPeopleInAllPossibleRadius: RecyclerView? = null

    constructor() : super() {}

    constructor(habApp: HabApplication) : this() {
        this.habApp = habApp
        this.sharedPreferencesUserInfo = this.habApp.getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        this.userID = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "") ?: ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.habApp = requireActivity().application as HabApplication

        sharedPreferencesUserInfo = habApp.getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        userID = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "") ?: ""
        //Log.d("InRadiusVisibleFragment", "userID: ${userID}")
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val rootView = inflater.inflate(R.layout.fragment_in_radius_visible, container, false)

        recyclerViewPeopleInAllPossibleRadius = rootView.findViewById(R.id.recycler_view_all_possible_radiuses)
        val linearLayoutManager = LinearLayoutManager(habApp)
        linearLayoutManager.orientation = RecyclerView.VERTICAL
        recyclerViewPeopleInAllPossibleRadius?.layoutManager = linearLayoutManager

        return rootView
    }

    override fun onResume() {
        super.onResume()

        if (ChatService.listOfPeopleInEveryRadiusList.isEmpty()) {
            ChatService.initListOfPeopleInEveryRadiusList()
        }

        var indexOfSelfProfileInRadius = 0
        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
            val personInRadiusListNullable = radiusAndListOfPeopleInRadius.personInRadiusList
            personInRadiusListNullable?.let { personInRadiusList ->
                if (personInRadiusList.contains(ChatService.selfProfileInRadius)) {
                    indexOfSelfProfileInRadius = index
                }
            }
        }
        ChatService.listOfPeopleInEveryRadiusList[indexOfSelfProfileInRadius].personInRadiusList?.remove(ChatService.selfProfileInRadius)
        val visibleInRadius = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS, DEFAULT_VISIBILITY_RADIUS_IN_METERS)
        val userStatus = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_STATUS, "Нет статуса")?:"Нет статуса"
        val userStatusColorId = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
        val userImageName = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_IMAGE, "")
        ChatService.selfProfileInRadius.status = userStatus
        ChatService.selfProfileInRadius.imageName = userImageName
        ChatService.selfProfileInRadius.statusColorId = userStatusColorId
        when(visibleInRadius) {
            RADIUS_10_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[0].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[0].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[0].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[0].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[0].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_50_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[1].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[1].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[1].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[1].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[1].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_100_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[2].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[2].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[2].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[2].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[2].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_250_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[3].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[3].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[3].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[3].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[3].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_500_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[4].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[4].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[4].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[4].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[4].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_1000_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[5].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[5].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[5].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[5].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[5].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_5000_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[6].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[6].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[6].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[6].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[6].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_15000_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[7].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[7].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[7].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[7].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[7].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_30000_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[8].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[8].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[8].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[8].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[8].personInRadiusList?.add(tmp)
                }
            }
            RADIUS_ALL_METERS -> {
                ChatService.selfProfileInRadius.radiusDistanceInMeters = visibleInRadius
                val tmp = if (ChatService.listOfPeopleInEveryRadiusList[9].personInRadiusList?.isEmpty() == true) null
                else {
                    ChatService.listOfPeopleInEveryRadiusList[9].personInRadiusList?.get(0)
                }
                ChatService.listOfPeopleInEveryRadiusList[9].personInRadiusList?.removeFirstOrNull()
                ChatService.listOfPeopleInEveryRadiusList[9].personInRadiusList?.add(0, ChatService.selfProfileInRadius)
                if (tmp != null) {
                    ChatService.listOfPeopleInEveryRadiusList[9].personInRadiusList?.add(tmp)
                }
            }
        }

        allPossibleRadiusesRecyclerViewAdapter = AllPossibleRadiusesRecyclerViewAdapter(habApp, ChatService.listOfPeopleInEveryRadiusList)
        recyclerViewPeopleInAllPossibleRadius?.adapter = allPossibleRadiusesRecyclerViewAdapter

        val sharedPrefsCurrentCoords = habApp.getSharedPreferences(SHARED_PREFS_CURRENT_COORDINATES, MODE_PRIVATE)
        val lat: Double = java.lang.Double.longBitsToDouble(sharedPrefsCurrentCoords.getLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT, 0))
        val lng: Double = java.lang.Double.longBitsToDouble(sharedPrefsCurrentCoords.getLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG, 0))
        searchingPeer(lat, lng, true)
    }

    fun searchingPeer(lat: Double, lng: Double, isSearching: Boolean) {
        //Log.d("InRadiusVisibleFragment", "searchingPeer searchingPeer: success!")
        HabApplication.ioScope.launch {
            //set latitude longitude instead of radius distance
            // get searchingInRadius from user settings
            val visibleInRadius = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS, DEFAULT_VISIBILITY_RADIUS_IN_METERS)
            val userStatus = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_STATUS, "Нет статуса")?:"Нет статуса"
            val userStatusColorId = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
            val userName = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_NAME, "")?:""
            val userDescription = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_DESCRIPTION, "")?:"Нет описания"
            val gender = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_GENDER, GENDER_ALL)?:GENDER_ALL
            val age = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_AGE, DEFAULT_AGE)
            val city = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_CITY, "")?:""

            val sharedPreferencesSearchSettings = habApp.getSharedPreferences(SHARED_PREFS_SEARCHING_SETTINGS, MODE_PRIVATE)
            val searchingGender = sharedPreferencesSearchSettings.getString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER, GENDER_ALL)?:GENDER_ALL
            val searchingMinAge = sharedPreferencesSearchSettings.getInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE, DEFAULT_MIN_AGE)
            val searchingMaxAge = sharedPreferencesSearchSettings.getInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE, DEFAULT_MAX_AGE)
            val searchingCity = sharedPreferencesSearchSettings.getString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY, DEFAULT_SEARCHING_CITY)?:DEFAULT_SEARCHING_CITY

            try {
                ChatService.searchingPeerResponseFlow = habApp.chatAPIService.searchingPeer(userID, lat, lng,
                        visibleInRadius, userStatus, userStatusColorId, userName, userDescription, isSearching,
                        gender, age, searchingGender, searchingMinAge, searchingMaxAge, city, searchingCity)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                //Log.d("InRadiusVisibleFragment", "searchingPeer error: ${e.message}")
            }

            searchingPeerResponseFlowCollect()
        }
    }

    private suspend fun searchingPeerResponseFlowCollect() {
        ChatService.searchingPeerResponseFlow?.onEach { searchingPeerResponse->
            val responseCode = searchingPeerResponse.responseCode
            when (responseCode) {
                SEARCHING_PEER_RESPONSE_CODE_SUCCESS -> {// new searching peer found
                    //Log.d("InRadiusVisibleFragment", "1==success")
                    // download image of searching peer

                    val imageFileName = "${habApp.filesDir.absolutePath}/${searchingPeerResponse.userId}"//todo: use filename instead of searchingPeerResponse.userId
                    val imageFile = File(imageFileName)
                    if (imageFile.exists() == true) {
                        imageFile.delete()
                    }
                    try {
                        var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                        val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(searchingPeerResponse.userId)

                        downloadImageResponseFlow.onEach { downloadImageResponse ->
                            val responseCode = downloadImageResponse.responseCode
                            when (responseCode) {
                                1 -> {//keep reading file
                                    val buffer = downloadImageResponse.fileChunk.toByteArray()
                                    fileImageStream?.write(buffer)
                                    //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                                }
                                2 -> {//End of file reached
                                    fileImageStream?.flush()
                                    fileImageStream?.close()
                                    //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                                }
                                -1 -> {//error
                                    //todo: error
                                    fileImageStream?.close()
                                    fileImageStream = null
                                }
                            }
                        }.onEmpty {
                            //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                        }.catch { e ->

                        }.collect()
                    } catch (e: FileNotFoundException) {
                        //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
                    }
                    habApp.uiScope.launch {

                        //check if it.userId already exists then remove
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedUser = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedUser = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                        if (indexOfRadiusCategoryOfRemovedUser != -1) {
                            allPossibleRadiusesRecyclerViewAdapter?.notifyItemChanged(indexOfRadiusCategoryOfRemovedUser)
                        }

                        //Log.d("InRadiusVisibleFragment", "onCreateView searchingPeer: success! user_id: ${searchingPeerResponse.userId}")
                        val radiusDistanceInMeters = searchingPeerResponse.radiusDistanceInMeters
                        var listOfPeopleInRadius: RadiusAndListOfPeopleInRadius? = null

                        var indexOfRadiusCategory = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            if (radiusAndListOfPeopleInRadius.radiusDistanceInMeters == radiusDistanceInMeters) {
                                listOfPeopleInRadius = radiusAndListOfPeopleInRadius
                                indexOfRadiusCategory = index
                            }
                        }

                        /*val METERS_IN_ONE_KM = 1000
                        if (radiusDistanceInMeters == RADIUS_ALL_METERS) {
                            listOfPeopleInRadius?.textRadius = "Виден всем"
                        } else if (radiusDistanceInMeters >= METERS_IN_ONE_KM) {
                            listOfPeopleInRadius?.textRadius = "${radiusDistanceInMeters / METERS_IN_ONE_KM} Км"
                        } else {
                            listOfPeopleInRadius?.textRadius = "$radiusDistanceInMeters метров"
                        }*/
                        var existingPersonInRadiusNullable: PersonInRadius? = null
                        var isUserAlreadyExists = false

                        listOfPeopleInRadius?.personInRadiusList?.forEach { personInRadius ->
                            if (personInRadius.id == searchingPeerResponse.userId) {
                                isUserAlreadyExists = true
                                existingPersonInRadiusNullable = personInRadius
                            }
                        }

                        if (isUserAlreadyExists == true) {
                            existingPersonInRadiusNullable?.let { existingPersonInRadius ->
                                existingPersonInRadius.name = searchingPeerResponse.userName
                                existingPersonInRadius.status = searchingPeerResponse.status
                                existingPersonInRadius.description = searchingPeerResponse.description
                                existingPersonInRadius.imageName = imageFileName
                                existingPersonInRadius.radiusDistanceInMeters = radiusDistanceInMeters
                                existingPersonInRadius.statusColorId = searchingPeerResponse.statusColorId
                                existingPersonInRadius.city = searchingPeerResponse.city
                                if (indexOfRadiusCategory != -1) {
                                    allPossibleRadiusesRecyclerViewAdapter?.notifyItemChanged(indexOfRadiusCategory)
                                }
                            }
                        } else {
                            val personInRadius = PersonInRadius()
                            personInRadius.id = searchingPeerResponse.userId
                            personInRadius.name = searchingPeerResponse.userName
                            personInRadius.status = searchingPeerResponse.status
                            personInRadius.description = searchingPeerResponse.description
                            personInRadius.radiusDistanceInMeters = radiusDistanceInMeters
                            personInRadius.imageName = imageFileName
                            personInRadius.isAdminOn = searchingPeerResponse.isAdminOn
                            personInRadius.statusColorId = searchingPeerResponse.statusColorId
                            personInRadius.city = searchingPeerResponse.city
                            listOfPeopleInRadius?.personInRadiusList?.add(personInRadius)
                            if (indexOfRadiusCategory != -1) {
                                allPossibleRadiusesRecyclerViewAdapter?.notifyItemChanged(indexOfRadiusCategory)
                            }
                        }
                        //Utils.showToast(habApp, "SearchingPeer: SucCESS!")
                    }
                    val db = HabDB.getDatabase(habApp)
                    val userDao = db.userDAO()
                    HabApplication.ioScope.launch {
                        //if (userDao.getUserByUserId(it.userId) == null) {
                        val user = UserDBEntity()
                        user.userId = searchingPeerResponse.userId
                        userDao.insert(user.userId, searchingPeerResponse.userName)
                        //}
                    }
                }
                SEARCHING_PEER_RESPONSE_CODE_NO_PEER -> {
                    //habApp.uiScope.launch {
                    //Utils.showToast(habApp, "SearchingPeer no user id: ${searchingPeerResponse.userId}")
                    //}
                }
                SEARCHING_PEER_RESPONSE_CODE_PEER_CLOSED -> {
                    habApp.uiScope.launch {
                        // remove searchingPeerResponse.userId from searching list
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedItem = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedItem = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                        //Utils.showToast(habApp, "SearchingPeer PEER closed")
                        if (indexOfRadiusCategoryOfRemovedItem != -1) {
                            allPossibleRadiusesRecyclerViewAdapter?.notifyItemChanged(indexOfRadiusCategoryOfRemovedItem)
                        }
                    }
                }
                SEARCHING_PEER_RESPONSE_CODE_PEER_OUT_OF_RADIUS -> {
                    habApp.uiScope.launch {
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedItem = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedItem = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                        if (indexOfRadiusCategoryOfRemovedItem != -1) {
                            allPossibleRadiusesRecyclerViewAdapter?.notifyItemChanged(indexOfRadiusCategoryOfRemovedItem)
                        }
                    }
                }
                SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_OFF -> {
                    habApp.uiScope.launch {
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedItem = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedItem = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                        if (indexOfRadiusCategoryOfRemovedItem != -1) {
                            allPossibleRadiusesRecyclerViewAdapter?.notifyItemChanged(indexOfRadiusCategoryOfRemovedItem)
                        }
                    }
                }
                SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_CITY_NOT_FOUND -> {
                    habApp.uiScope.launch {
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedItem = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedItem = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                        if (indexOfRadiusCategoryOfRemovedItem != -1) {
                            allPossibleRadiusesRecyclerViewAdapter?.notifyItemChanged(indexOfRadiusCategoryOfRemovedItem)
                        }
                    }
                }
            }
        }?.onEmpty {
            /*habApp.uiScope.launch {
                Utils.showToast(habApp, "SearchingPeer: onEmpty!")
            }*/
        }?.catch { e ->
            /*habApp.uiScope.launch {
                Utils.showToast(habApp, "SearchingPeer: ERROR: ${e.message}")
            }*/
        }?.collect()
    }
}