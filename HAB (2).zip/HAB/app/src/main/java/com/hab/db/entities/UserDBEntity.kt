package com.hab.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
class UserDBEntity {
    @PrimaryKey(autoGenerate = true)
    var id = 0

    @ColumnInfo(name = "user_id")
    var userId: String = ""

    @ColumnInfo(name = "user_name")
    var userName: String = ""

    @ColumnInfo(name = "user_surname")
    var userSurname: String? = ""

    //todo: @NonNull
    @ColumnInfo(name = "user_gender")
    var userGender: String? = null

    //todo: @NonNull
    @ColumnInfo(name = "user_birth_date")
    var userBirthDate: String? = null

    @ColumnInfo(name = "user_birth_day")
    var userBirthDay: Int? = null

    @ColumnInfo(name = "user_birth_month")
    var userBirthMonth: Int? = null

    @ColumnInfo(name = "user_birth_year")
    var userBirthYear: Int? = null
}