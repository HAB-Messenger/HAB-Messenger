package com.hab.activities

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.hab.R
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.hab.activities.PersonalInfoActivity
import com.hab.activities.NotificationsActivity
import com.hab.activities.PrivacyActivity
import com.hab.activities.ReportProblemActivity
import com.hab.activities.ProfileActivity
import com.hab.activities.ChatPartnersListActivity
import com.hab.activities.SearchInRadiusActivity
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.services.PushNotificationsService
import com.hab.utils.Utils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var habApp: HabApplication
    private lateinit var newMessagesInBottomNav: RelativeLayout
    private lateinit var itemsCountLabelInBottomNav: TextView
    private lateinit var userId: String
    private var pushnotificationJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        habApp = application as HabApplication
        val sharedPreferencesUserInfo = getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, Context.MODE_PRIVATE)
        userId = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_ID, "")?:""
        //MaterialToolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        //ActionBar actionBar = getSupportActionBar();
        //actionBar.setDisplayHomeAsUpEnabled(true);
        //actionBar.setDisplayShowTitleEnabled(false);
        //actionBar.setHomeAsUpIndicator(R.drawable.ic_back);

        //MaterialTextView textAppName = findViewById(R.id.text_app_name);
        //textAppName.setText("Настройки");
        val buttonProfileInfo = findViewById<Button>(R.id.button_profile_info)
        val buttonNotifications = findViewById<Button>(R.id.button_notifications)
        val buttonPrivacy = findViewById<Button>(R.id.button_privacy)
        val buttonReportProblem = findViewById<Button>(R.id.button_report_problem)
        val buttonClose = findViewById<Button>(R.id.button_close)
        val imageViewProfile = findViewById<ImageView>(R.id.image_view_profile)
        val imageViewInRadius = findViewById<ImageView>(R.id.image_view_in_radius)
        val imageViewChat = findViewById<ImageView>(R.id.image_view_chat)
        val imageViewSettings = findViewById<ImageView>(R.id.image_view_settings)

        newMessagesInBottomNav = findViewById(R.id.new_messages_in_bottom_nav)
        itemsCountLabelInBottomNav = findViewById(R.id.items_count_label_in_bottom_nav)

        imageViewProfile.setImageResource(R.drawable.ic_profile_not_selected)
        imageViewSettings.setImageResource(R.drawable.ic_settings_selected)
        buttonProfileInfo.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@SettingsActivity, PersonalInfoActivity::class.java)
            startActivity(intentProfileActivity)
        }
        buttonNotifications.setOnClickListener { view: View? ->
            val intentNotificationsActivity = Intent(this@SettingsActivity, NotificationsActivity::class.java)
            startActivity(intentNotificationsActivity)
        }
        buttonPrivacy.setOnClickListener { view: View? ->
            val intentPrivacyActivity = Intent(this@SettingsActivity, PrivacyActivity::class.java)
            startActivity(intentPrivacyActivity)
        }
        buttonReportProblem.setOnClickListener { view: View? ->
            val intentReportProblemActivity = Intent(this@SettingsActivity, ReportProblemActivity::class.java)
            startActivity(intentReportProblemActivity)
        }
        buttonClose.setOnClickListener { view: View? -> finish() }
        imageViewProfile.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@SettingsActivity, ProfileActivity::class.java)
            startActivity(intentProfileActivity)
            finish()
        }
        imageViewChat.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@SettingsActivity, ChatPartnersListActivity::class.java)
            startActivity(intentProfileActivity)
        }
        imageViewInRadius.setOnClickListener { view: View? ->
            val intentSearchInRadiusActivity = Intent(this@SettingsActivity, SearchInRadiusActivity::class.java)
            startActivity(intentSearchInRadiusActivity)
            finish()
        }
    } /*@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }*/

    override fun onStart() {
        super.onStart()

        HabApplication.ioScope.launch {
            val db = HabDB.getDatabase(applicationContext)
            val usersDAO = db.userDAO()
            val messagesDAO = db.messageDAO()
            val id = usersDAO.getUserByUserId(userId).id
            val unreadMessages = messagesDAO.getUnreadMessages(id)
            val messageCount: Int = unreadMessages.size
            habApp.uiScope.launch {
                if (messageCount > 0) {
                    newMessagesInBottomNav.visibility = View.VISIBLE
                    itemsCountLabelInBottomNav.setText("$messageCount")
                } else {
                    itemsCountLabelInBottomNav.setText("0")
                    newMessagesInBottomNav.visibility = View.GONE
                }
            }
        }

        pushnotificationJob = HabApplication.defaultScope.launch {
            PushNotificationsService.pushNotificationsFlow.onEach {
                //val messageCount: Int = PushNotificationsService.messageCounter.get()
                val db = HabDB.getDatabase(applicationContext)
                val usersDAO = db.userDAO()
                val messagesDAO = db.messageDAO()
                val id = usersDAO.getUserByUserId(userId).id
                val unreadMessages = messagesDAO.getUnreadMessages(id)
                val messageCount: Int = unreadMessages.size
                habApp.uiScope.launch {
                    if (messageCount > 0) {
                        newMessagesInBottomNav.visibility = View.VISIBLE
                        itemsCountLabelInBottomNav.setText("$messageCount")
                    } else {
                        itemsCountLabelInBottomNav.setText("0")
                        newMessagesInBottomNav.visibility = View.GONE
                    }
                }
            }.onEmpty {

            }.catch { e ->

            }.collect()
        }
    }

    override fun onStop() {
        pushnotificationJob?.cancel()
        super.onStop()
    }
}