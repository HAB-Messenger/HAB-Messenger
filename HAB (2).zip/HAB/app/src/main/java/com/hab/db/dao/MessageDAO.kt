package com.hab.db.dao

import androidx.room.*
import com.hab.db.entities.MessageDBEntity

@Dao
interface MessageDAO {
    @Insert
    fun insert(msg: MessageDBEntity?)

    @Query("SELECT * FROM messages WHERE (:id = to_user_id) ORDER BY id ASC")
    fun getMessages(id: Int): List<MessageDBEntity>

    @Query("SELECT * FROM messages WHERE (:id = from_user_id AND :to_id = to_user_id) OR (:id = to_user_id AND :to_id = from_user_id) ORDER BY id ASC")
    fun getMessages(id: Int, to_id: Int): List<MessageDBEntity>

    @Query("SELECT * FROM messages WHERE (:id = from_user_id OR :id = to_user_id) ORDER BY id DESC LIMIT 1;")
    fun getLastMessage(id: Int): MessageDBEntity?

    @Query("SELECT * FROM messages WHERE (:id = to_user_id AND is_read = 0)")
    fun getUnreadMessages(id: Int): List<MessageDBEntity>

    @Query("SELECT * FROM messages WHERE ((:id = to_user_id AND :fromId = from_user_id) AND is_read = 0)")
    fun getUnreadMessages(id: Int, fromId: Int): List<MessageDBEntity>

    @Update
    fun update(msg: MessageDBEntity?)

    @Delete
    fun delete(msg: MessageDBEntity?)

    @Query("DELETE FROM messages WHERE from_user_id = :id and to_user_id= :to_id")
    fun deleteAll(id: Int, to_id: Int)

    @Query("DELETE FROM messages")
    fun deleteAll()
}