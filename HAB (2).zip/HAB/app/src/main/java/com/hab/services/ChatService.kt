package com.hab.services

import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import com.hab.utils.Utils
import com.hab.utils.Utils.CHAT_SERVICE_NOTIFICATION_ID
import com.hab.utils.Utils.SHARED_PREFS
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG
import com.hab.utils.Utils.SHARED_PREFS_KEY_IS_SEARCHING
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.app.HabApplication
import com.hab.grpc.chatservice.ChatAPIService
import com.hab.grpc.chatservice.SearchingPeerResponse
import com.hab.pojo.PersonInRadius
import com.hab.pojo.RadiusAndListOfPeopleInRadius
import com.hab.utils.Utils.DEFAULT_VISIBILITY_RADIUS_IN_METERS
import com.hab.utils.Utils.RADIUS_1000_METERS
import com.hab.utils.Utils.RADIUS_100_METERS
import com.hab.utils.Utils.RADIUS_10_METERS
import com.hab.utils.Utils.RADIUS_15000_METERS
import com.hab.utils.Utils.RADIUS_250_METERS
import com.hab.utils.Utils.RADIUS_30000_METERS
import com.hab.utils.Utils.RADIUS_5000_METERS
import com.hab.utils.Utils.RADIUS_500_METERS
import com.hab.utils.Utils.RADIUS_50_METERS
import com.hab.utils.Utils.RADIUS_ALL_METERS
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.ArrayList
import java.util.concurrent.CopyOnWriteArrayList


class ChatService : Service() {

    private lateinit var habApp: HabApplication

    private var fusedLocationClient: FusedLocationProviderClient? = null

    private lateinit var locationCallback: LocationCallback

    private var userId = ""

    companion object {
        var instance: ChatService? = null
        var adminSearchingPeerResponse: Flow<SearchingPeerResponse>? = null
        var searchingPeerResponseFlow: Flow<SearchingPeerResponse>? = null
        var listOfPeopleInEveryRadiusList: CopyOnWriteArrayList<RadiusAndListOfPeopleInRadius> = CopyOnWriteArrayList()
        var selfProfileInRadius = PersonInRadius()

        const val TWO_AND_HALF_MIN_IN_MILLISECONDS = 2*60_000L+30_000L

        inline fun <T, R : Comparable<R>> CopyOnWriteArrayList<T>.sortListBy(crossinline selector: (T) -> R?) {
            if (size > 1) {
                /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    sortBy(selector)
                } else*/
                //{
                    val tmpList = ArrayList(this)
                    tmpList.sortBy(selector)
                    clear()
                    addAll(tmpList)
                //}
            }
        }

        fun initListOfPeopleInEveryRadiusList() {
            val METERS_IN_ONE_KM = 1000
            var listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_10_METERS)
            var personInRadiusList: MutableList<PersonInRadius> = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_10_METERS} метров"
            listOfPeopleInEveryRadiusList.add(0, listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_50_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_50_METERS} метров"
            listOfPeopleInEveryRadiusList.add(1,listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_100_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_100_METERS} метров"
            listOfPeopleInEveryRadiusList.add(2,listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_250_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_250_METERS} метров"
            listOfPeopleInEveryRadiusList.add(3,listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_500_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_500_METERS} метров"
            listOfPeopleInEveryRadiusList.add(4,listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_1000_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_1000_METERS/METERS_IN_ONE_KM} Км"
            listOfPeopleInEveryRadiusList.add(5,listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_5000_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_5000_METERS/METERS_IN_ONE_KM} Км"
            listOfPeopleInEveryRadiusList.add(6,listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_15000_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_15000_METERS/METERS_IN_ONE_KM} Км"
            listOfPeopleInEveryRadiusList.add(7,listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_30000_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "${RADIUS_30000_METERS/METERS_IN_ONE_KM} Км"
            listOfPeopleInEveryRadiusList.add(8,listOfPeopleInRadius)

            listOfPeopleInRadius = RadiusAndListOfPeopleInRadius(RADIUS_ALL_METERS)
            personInRadiusList = ArrayList()
            listOfPeopleInRadius.personInRadiusList = personInRadiusList
            listOfPeopleInRadius.textRadius = "Виден всем"
            listOfPeopleInEveryRadiusList.add(9,listOfPeopleInRadius)
            /*val tmpList = ArrayList(listOfPeopleInEveryRadiusList)
            tmpList.sortBy { radiusAndListOfPeopleInRadius ->
                radiusAndListOfPeopleInRadius.radiusDistanceInMeters
            }
            listOfPeopleInEveryRadiusList.clear()
            listOfPeopleInEveryRadiusList.addAll(tmpList)*/

            //val selfProfileInRadius = PersonInRadius()
            selfProfileInRadius.id = "SelfProfile"
            selfProfileInRadius.name = ""
            selfProfileInRadius.imageName = ""
            selfProfileInRadius.status = ""
            selfProfileInRadius.description = ""
            selfProfileInRadius.radiusDistanceInMeters = DEFAULT_VISIBILITY_RADIUS_IN_METERS
            //listOfPeopleInEveryRadiusList[9].personInRadiusList?.add(selfProfileInRadius)
            listOfPeopleInEveryRadiusList.sortListBy{ radiusAndListOfPeopleInRadius ->
                radiusAndListOfPeopleInRadius.radiusDistanceInMeters
            }
        }
    }

    override fun onBind(p0: Intent?): IBinder? {
        TODO("Not yet implemented")
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(CHAT_SERVICE_NOTIFICATION_ID,newSystemNotification())
        initListOfPeopleInEveryRadiusList()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("HAB_", "ChatService.onStartCommand")

        instance = this
        val sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        userId = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult?) {
                locationResult ?: return
                for (location in locationResult.locations) {
                    // Update UI with location data
                    HabApplication.ioScope.launch {
                        val lat = location.latitude
                        val lng = location.longitude
                        val sharedPrefsCurrentCoords = getSharedPreferences(SHARED_PREFS_CURRENT_COORDINATES, MODE_PRIVATE)
                        val sharedPrefsCurrentCoordsEditor = sharedPrefsCurrentCoords.edit()
                        sharedPrefsCurrentCoordsEditor.putLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT, java.lang.Double.doubleToRawLongBits(lat))
                        sharedPrefsCurrentCoordsEditor.putLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG, java.lang.Double.doubleToRawLongBits(lng))
                        sharedPrefsCurrentCoordsEditor.apply()
                        val sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE)
                        val isSearchingPeers = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_SEARCHING, false)
                        if (isSearchingPeers) {
                            // send new coordinates to server
                            try {
                                habApp.chatAPIService.newCoordinates(userId,lat, lng)
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                /*habApp.uiScope.launch {
                                    Utils.showToast(habApp, "Error: server unavailable")
                                }*/
                            }
                            /*searchingPeerResponseFlow = habApp.chatAPIService.searchingPeer(userId, lat, lng,
                                    visibleInRadius, userStatus, userStatusColorId, userName, userDescription, true,
                                    gender, age, searchingGender, searchingMinAge, searchingMaxAge)
                            searchingPeerResponseFlow?.catch { e->
                                habApp.uiScope.launch {
                                    Utils.showToast(habApp, "Error: server unavailable")
                                }
                            }?.collect()*/
                        }
                    }
                    break
                }
            }
        }

        habApp = getApplication() as HabApplication
        try {
            Log.d("HAB_", "ChatService.onStartCommand")
            habApp.chatAPIService = ChatAPIService(habApp)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            //Utils.showToast(habApp, "Error: server unavailable")
        }
        HabApplication.ioScope.launch {
            val response = habApp.chatAPIService.newPeer(userId)
            response.onEach { newPeerResponse ->
                when (newPeerResponse.responseCode) {
                    1-> {
                        //success
                    }
                }
            }.onEmpty {

            }.catch {

            }.collect()
        }
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(habApp)

        val sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE)
        val isSearchingPeers = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_SEARCHING, false)
        if (isSearchingPeers) {
            if (ContextCompat.checkSelfPermission(habApp, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(habApp, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            {
                val locationRequest = LocationRequest.create()
                        .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                        .setInterval(TWO_AND_HALF_MIN_IN_MILLISECONDS)
                fusedLocationClient?.requestLocationUpdates(locationRequest,
                        locationCallback,
                        Looper.getMainLooper())
            }
        }
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    fun startSendingCoordinates() {
        val locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(TWO_AND_HALF_MIN_IN_MILLISECONDS)
        fusedLocationClient?.requestLocationUpdates(locationRequest,
                locationCallback,
                Looper.getMainLooper())
    }

    private fun stopLocationUpdates() {
        fusedLocationClient?.removeLocationUpdates(locationCallback)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)

        runBlocking {
            try {
                habApp.chatAPIService.peerCLosed(userId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {

            }
        }
        adminSearchingPeerResponse = null
        searchingPeerResponseFlow = null
        listOfPeopleInEveryRadiusList.clear()
        stopLocationUpdates()
        stopSelf()
    }

    /*override fun onDestroy() {
        super.onDestroy()
        Log.d("ChatService", "onDestroy")

        isChatServiceRunning.set(false)
        //todo: check if chat open then close opened chat(personal or collective)
        ioScope.launch {
            Log.d("ChatService", "onTaskRemoved: defaultScope.launch")
            chatAPIService.peerCLosed(userId)//fixme: not called sometimes
            Log.d("ChatService", "onTaskRemoved: chatAPIService.peerCLosed()")
        }
        stopLocationUpdates()
    }*/


    fun newSystemNotification(): Notification {
        val notificationChannelId = "chat_service_test"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notificationChannel = NotificationChannel(notificationChannelId, "Service working", NotificationManager.IMPORTANCE_HIGH)
            notificationChannel.description = "Chat service still working"
            notificationManager.createNotificationChannel(notificationChannel)
        }
        //val notificationIntent = Intent(this, ProfileActivity::class.java)
        //notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        //val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0)

        var notificationBuilder: Notification.Builder
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationBuilder = Notification.Builder(this, notificationChannelId)
        } else {
            notificationBuilder = Notification.Builder(this)
        }

        val notification = notificationBuilder
                .setContentTitle("HAB chat service")
                .setContentText("HAB chat service still working")
                //.setContentIntent(pendingIntent)
                .build()

        return notification
    }
}
