package com.hab.activities

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider
import com.hab.BuildConfig
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.GENDER_ALL
import com.hab.utils.Utils.SHARED_PREFS
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT
import com.hab.utils.Utils.SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG
import com.hab.utils.Utils.SHARED_PREFS_KEY_IS_ADMIN_ON
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_AGE
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_DESCRIPTION
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_GENDER
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_IMAGE
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_NAME
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_STATUS
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_STATUS_COLOR
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.db.entities.UserDBEntity
import com.hab.pojo.PersonInRadius
import com.hab.pojo.RadiusAndListOfPeopleInRadius
import com.hab.services.ChatService
import com.hab.services.PushNotificationsService
import com.hab.utils.Utils.DEFAULT_AGE
import com.hab.utils.Utils.DEFAULT_MAX_AGE
import com.hab.utils.Utils.DEFAULT_MIN_AGE
import com.hab.utils.Utils.DEFAULT_SEARCHING_CITY
import com.hab.utils.Utils.DEFAULT_VISIBILITY_RADIUS_IN_METERS
import com.hab.utils.Utils.RADIUS_1000_METERS
import com.hab.utils.Utils.RADIUS_30000_METERS
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_NO_PEER
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_PEER_CLOSED
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_PEER_OUT_OF_RADIUS
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_CITY_NOT_FOUND
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_OFF
import com.hab.utils.Utils.SEARCHING_PEER_RESPONSE_CODE_SUCCESS
import com.hab.utils.Utils.SHARED_PREFS_KEY_IMAGE_VIEW_USER_PHOTO_HEIGHT
import com.hab.utils.Utils.SHARED_PREFS_KEY_IS_LOCATION_ENABLED
import com.hab.utils.Utils.SHARED_PREFS_KEY_IS_SEARCHING
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_CITY
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY
import com.hab.utils.Utils.STATUS_COLOR_BLUE
import com.hab.utils.Utils.STATUS_COLOR_GRAY
import com.hab.utils.Utils.STATUS_COLOR_GREEN
import com.hab.utils.Utils.STATUS_COLOR_LILAC
import com.hab.utils.Utils.STATUS_COLOR_ORANGE
import com.hab.utils.Utils.STATUS_COLOR_RED
import com.hab.utils.Utils.STATUS_COLOR_WHITE
import com.hab.utils.Utils.STATUS_COLOR_YELLOW
import com.hab.utils.Utils.showToast
import com.hab.viewmodels.BillingViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import kotlin.coroutines.cancellation.CancellationException


class ProfileActivity : AppCompatActivity() {
    private lateinit var habApp: HabApplication
    private lateinit var billingViewModel: BillingViewModel
    private lateinit var layout:ConstraintLayout
    private lateinit var textViewUserName: TextView
    private lateinit var textViewStatusText: TextView
    private lateinit var textViewDescriptionText: TextView
    private lateinit var textViewRadiusText: TextView
    private lateinit var photoStub: ImageView
    private lateinit var imageViewUserPhoto: ImageView
    private lateinit var newMessagesInBottomNav: RelativeLayout
    private lateinit var itemsCountLabelInBottomNav: TextView
    private lateinit var textViewStatusColorText: TextView
    private var radiusInMeters = DEFAULT_VISIBILITY_RADIUS_IN_METERS
    private lateinit var userPrefs: SharedPreferences
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var sharedPreferencesUserInfo: SharedPreferences
    private var isAdminChatOn = false
    private lateinit var userId: String
    private var pushnotificationJob: Job? = null


    private val registerForLocationPermissionResult = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions(), {
        permissionsGranted ->
        val permissionCoarseLocation = permissionsGranted[Manifest.permission.ACCESS_COARSE_LOCATION]?:false
        val permissionFineLocation = permissionsGranted[Manifest.permission.ACCESS_FINE_LOCATION]?:false
        if (permissionCoarseLocation || permissionFineLocation) {
            ChatService.instance?.startSendingCoordinates()
            val isSearching = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_SEARCHING, false)
            if (isSearching == true) {
                searchingPeer(isSearching)
            }
        } else {
            Utils.showToast(this, "Приложение не будет полноценно работать без доступа к местоположению!")
        }
    })

    private val registerForReadExternalStorageResult = registerForActivityResult(ActivityResultContracts.RequestPermission(), {
        isGranted ->
        if (isGranted) {
            HabApplication.defaultScope.launch {
                val userImageName = userPrefs.getString(SHARED_PREFS_KEY_USER_IMAGE, "")?: ""
                if (userImageName != "") {
                    val imageUri = Uri.parse(userImageName)
                    val imageStream = contentResolver.openInputStream(imageUri)
                    val selectedImage = BitmapFactory.decodeStream(imageStream)
                    imageStream?.close()
                    /*val displayMetrics = DisplayMetrics()
                    this@ProfileActivity.getWindowManager()
                            .getDefaultDisplay()
                            .getMetrics(displayMetrics)

                    var width = if (imageViewUserPhoto.width > 0) {
                        imageViewUserPhoto.width
                    } else {
                        displayMetrics.widthPixels
                    }
                    var height = imageViewUserPhoto.height
                    if (selectedImage.width < width) {
                        width = selectedImage.width
                    }
                    if (selectedImage.height < height) {
                        height = selectedImage.height
                    }
                    val resizedImage = Bitmap.createScaledBitmap(selectedImage, width, (selectedImage.height * 0.5).toInt(), false)*/
                    //val resizedImage = Bitmap.createBitmap(selectedImage, 0,0,width, height)
                    habApp.uiScope.launch {
                        imageViewUserPhoto.setImageBitmap(selectedImage)
                    }
                }
            }
        } else {
            Utils.showToast(this, "Приложение нет доступа к файлам!")
        }
    })

    private val registerForChangeUserPicActivityResult = registerForActivityResult(StartActivityForResult(), {
        if (it.resultCode == RESULT_OK) {
            imageViewUserPhoto = findViewById(R.id.image_view_user_photo)
            HabApplication.defaultScope.launch {
                val userImageName = userPrefs.getString(SHARED_PREFS_KEY_USER_IMAGE, "")

                if (userImageName != "") {
                    val imageUri = Uri.parse(userImageName)

                    if (ActivityCompat.checkSelfPermission(habApp, Manifest.permission.READ_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                        //ActivityCompat.requestPermissions(this@ProfileActivity,arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE)
                        registerForReadExternalStorageResult.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                    } else {
                        try {
                            val imageStream = contentResolver.openInputStream(imageUri)
                            val selectedImage = BitmapFactory.decodeStream(imageStream)
                            imageStream?.close()
                            /*val displayMetrics = DisplayMetrics()
                            this@ProfileActivity.getWindowManager()
                                    .getDefaultDisplay()
                                    .getMetrics(displayMetrics)

                            var width = if (imageViewUserPhoto.width > 0) {imageViewUserPhoto.width} else {displayMetrics.widthPixels}
                            var height = imageViewUserPhoto.height
                            if (selectedImage.width < width) {
                                width = selectedImage.width
                            }
                            if (selectedImage.height < height) {
                                height = selectedImage.height
                            }
                            val resizedImage = Bitmap.createScaledBitmap(selectedImage, width, (selectedImage.height*0.5).toInt(), false)*/
                            //val resizedImage = Bitmap.createBitmap(selectedImage, 0,0,width, height)
                            habApp.uiScope.launch {
                                imageViewUserPhoto.setImageBitmap(selectedImage)
                            }
                        } catch (e: FileNotFoundException) {
                            habApp.uiScope.launch {
                                Utils.showToast(this@ProfileActivity, "Файл изображения не найден!")
                            }
                        }
                    }

                } else {
                    habApp.uiScope.launch {
                        imageViewUserPhoto.setImageBitmap(null)
                    }
                }
            }
        }
    })

    private val registerForEditUserStatusActivityResult = registerForActivityResult(StartActivityForResult(), {
        if (it.data != null) {
            val userStatus = userPrefs.getString(SHARED_PREFS_KEY_USER_STATUS, "Нет статуса")
            textViewStatusText.text = userStatus
        }
    })

    private val registerForEditUserDescriptionActivityResult = registerForActivityResult(StartActivityForResult(), {
        if (it.data != null) {
            val descriptionText = userPrefs.getString(SHARED_PREFS_KEY_USER_DESCRIPTION, "Нет описания")
            textViewDescriptionText.text = descriptionText
        }
    })

    private val registerForSelectRadiusActivityResult = registerForActivityResult(StartActivityForResult(), {
        val resultIntent = it.data
        if (resultIntent != null) {
            radiusInMeters = resultIntent.getIntExtra("radius_in_meters", DEFAULT_VISIBILITY_RADIUS_IN_METERS)
            val textRadiusInMeters = resultIntent.getStringExtra("text_radius_in_meters")
            textViewRadiusText.text = textRadiusInMeters
        }

        val isSearching = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_SEARCHING, false)
        if (isSearching == true) {
            HabApplication.defaultScope.launch {
                val sharedPrefsCurrentCoords = habApp.getSharedPreferences(SHARED_PREFS_CURRENT_COORDINATES, MODE_PRIVATE)
                val lat: Double = java.lang.Double.longBitsToDouble(sharedPrefsCurrentCoords.getLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT, 0))
                val lng: Double = java.lang.Double.longBitsToDouble(sharedPrefsCurrentCoords.getLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG, 0))

                // get searchingInRadius from user settings
                val userID = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "") ?: ""
                val visibleInRadius = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS, DEFAULT_VISIBILITY_RADIUS_IN_METERS)
                val userStatus = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_STATUS, "Нет статуса")?:"Нет статуса"
                val userStatusColorId = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                val userName = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_NAME, "")?:""
                val userDescription = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_DESCRIPTION, "")?:""
                val gender = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_GENDER, GENDER_ALL)?: GENDER_ALL
                val age = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_AGE, DEFAULT_AGE)
                val city = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_CITY, "")?:""

                val sharedPreferencesSearchSettings = habApp.getSharedPreferences(SHARED_PREFS_SEARCHING_SETTINGS, MODE_PRIVATE)
                val searchingGender = sharedPreferencesSearchSettings.getString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER, GENDER_ALL)?: GENDER_ALL
                val searchingMinAge = sharedPreferencesSearchSettings.getInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE, DEFAULT_MIN_AGE)
                val searchingMaxAge = sharedPreferencesSearchSettings.getInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE, DEFAULT_MAX_AGE)
                val searchingCity = sharedPreferencesSearchSettings.getString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY, DEFAULT_SEARCHING_CITY)?:DEFAULT_SEARCHING_CITY

                try {
                    ChatService.searchingPeerResponseFlow = habApp.chatAPIService.searchingPeer(userID, lat, lng,
                            visibleInRadius, userStatus, userStatusColorId, userName, userDescription, true,
                            gender, age, searchingGender, searchingMinAge, searchingMaxAge, city, searchingCity)
                    searchingPeerResponseFlowCollect()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {

                }
            }
        }
    })

    private val registerForChangeStatusColorActivityResult = registerForActivityResult(StartActivityForResult(), {
        val statusColorId = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
        when (statusColorId) {
            STATUS_COLOR_GREEN -> {
                textViewStatusColorText.setText(R.string.status_color_green)
            }
            STATUS_COLOR_RED -> {
                textViewStatusColorText.setText(R.string.status_color_red)
            }
            STATUS_COLOR_ORANGE -> {
                textViewStatusColorText.setText(R.string.status_color_orange)
            }
            STATUS_COLOR_LILAC -> {
                textViewStatusColorText.setText(R.string.status_color_lilac)
            }
            STATUS_COLOR_BLUE -> {
                textViewStatusColorText.setText(R.string.status_color_blue)
            }
            STATUS_COLOR_YELLOW -> {
                textViewStatusColorText.setText(R.string.status_color_yellow)
            }
            STATUS_COLOR_GRAY -> {
                textViewStatusColorText.setText(R.string.status_color_gray)
            }
            else -> {
                textViewStatusColorText.setText(R.string.status_color_white)
            }
        }
    })

    private val registerForAdminGroupChatActivityResult = registerForActivityResult(StartActivityForResult(), {

    })

    private val registerForEditUserAboutActivityResult = registerForActivityResult(StartActivityForResult(), {

    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        //tabLayout = findViewById(R.id.tab_layout);
        //viewPager = findViewById(R.id.view_pager);
        //viewPager.setUserInputEnabled(false);
        habApp = application as HabApplication

        layout = findViewById(R.id.layout)
        photoStub = findViewById(R.id.photo_stub)
        textViewUserName = findViewById(R.id.text_view_user_name)
        textViewStatusText = findViewById(R.id.text_view_status_text)
        textViewDescriptionText = findViewById(R.id.text_view_description_text)
        textViewRadiusText = findViewById(R.id.text_view_radius_text)
        val imageViewMore = findViewById<ImageView>(R.id.image_view_more)
        imageViewUserPhoto = findViewById<ImageView>(R.id.image_view_user_photo)
        newMessagesInBottomNav = findViewById(R.id.new_messages_in_bottom_nav)
        itemsCountLabelInBottomNav = findViewById(R.id.items_count_label_in_bottom_nav)
        textViewStatusColorText = findViewById(R.id.text_view_status_color_text)

        userPrefs = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        val descriptionText = userPrefs.getString(SHARED_PREFS_KEY_USER_DESCRIPTION, "Нет описания")
        textViewDescriptionText.setText(descriptionText)
        val userStatus = userPrefs.getString(SHARED_PREFS_KEY_USER_STATUS, "Нет статуса")
        textViewStatusText.setText(userStatus)
        radiusInMeters = userPrefs.getInt(SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS, DEFAULT_VISIBILITY_RADIUS_IN_METERS)

        if (radiusInMeters < RADIUS_1000_METERS) {
            textViewRadiusText.setText("${radiusInMeters} м")
        } else if (radiusInMeters <= RADIUS_30000_METERS) {
            textViewRadiusText.setText("${radiusInMeters / 1000} км")
        } else {
            textViewRadiusText.setText("Виден всем")
        }
        photoStub.setOnClickListener(View.OnClickListener { view: View? ->
            val intentChangeUserPicActivity = Intent(this, ChangeUserPicActivity::class.java)
            //startActivityForResult(intentChangeUserPicActivity, CHANGE_USER_PIC)
            registerForChangeUserPicActivityResult.launch(intentChangeUserPicActivity)
        })
        val layoutStatus = findViewById<ConstraintLayout>(R.id.layout_status)
        layoutStatus.setOnClickListener { view: View? ->
            val intentEditUserStatusActivity = Intent(this, EditUserStatusActivity::class.java)
            //startActivityForResult(intentEditUserStatusActivity, EDIT_USER_STATUS_INFO_REQUEST_CODE)
            registerForEditUserStatusActivityResult.launch(intentEditUserStatusActivity)
        }
        val layoutDescription = findViewById<ConstraintLayout>(R.id.layout_description)
        layoutDescription.setOnClickListener { view: View? ->
            val intentEditUserDescriptionActivity = Intent(this, EditUserDescriptionActivity::class.java)
            //startActivityForResult(intentEditUserDescriptionActivity, EDIT_USER_DESCRIPTION_INFO_REQUEST_CODE)
            registerForEditUserDescriptionActivityResult.launch(intentEditUserDescriptionActivity)
        }
        val layoutRadius = findViewById<ConstraintLayout>(R.id.layout_radius)
        layoutRadius.setOnClickListener { view: View? ->
            val intentSelectRadiusActivity = Intent(this, SelectRadiusActivity::class.java)
            intentSelectRadiusActivity.putExtra("current_radius", radiusInMeters)
            //startActivityForResult(intentSelectRadiusActivity, SELECT_RADIUS_REQUEST_CODE)
            registerForSelectRadiusActivityResult.launch(intentSelectRadiusActivity)
        }
        val layoutStatusColor = findViewById<ConstraintLayout>(R.id.layout_status_color)
        layoutStatusColor.setOnClickListener { view: View? ->
            val intentChangeStatusColorActivity = Intent(this, ChangeStatusColorActivity::class.java)
            //intentStartUserStatusActivity.putExtra("activity_title", "Статус");
            //startActivityForResult(intentChangeStatusColorActivity, SELECT_STATUS_COLOR_REQUEST_CODE)
            registerForChangeStatusColorActivityResult.launch(intentChangeStatusColorActivity)
        }
        val buttonProfile = findViewById<Button>(R.id.button_profile)
        val buttonChat = findViewById<Button>(R.id.button_chat)
        buttonProfile.isAllCaps = false
        buttonChat.isAllCaps = false
        buttonProfile.setOnClickListener { view: View? -> }
        buttonChat.setOnClickListener { view: View? ->
            //val intentAdminGroupChatActivity = Intent(this@ProfileActivity, AdminGroupChatActivity::class.java)
            //registerForAdminGroupChatActivityResult.launch(intentAdminGroupChatActivity)
            Utils.showToast(this, "В разработке")
        }

        val imageViewInRadius = findViewById<ImageView>(R.id.image_view_in_radius)
        val imageViewChat = findViewById<ImageView>(R.id.image_view_chat)
        val imageViewSettings = findViewById<ImageView>(R.id.image_view_settings)
        imageViewMore.setOnClickListener { view: View? ->
            val intentEditUserAboutActivity = Intent(this@ProfileActivity, EditUserAboutActivity::class.java)
            //startActivityForResult(intentEditUserAboutActivity, EDIT_USER_ABOUT_ACTIVITY)
            registerForEditUserAboutActivityResult.launch(intentEditUserAboutActivity)
        }
        imageViewInRadius.setOnClickListener { view: View? ->
            val intentSearchInRadiusActivity = Intent(this@ProfileActivity, SearchInRadiusActivity::class.java)
            startActivity(intentSearchInRadiusActivity)
            finish()
        }
        imageViewChat.setOnClickListener { view: View? ->
            val intentChatPartnersListActivity = Intent(this@ProfileActivity, ChatPartnersListActivity::class.java)
            startActivity(intentChatPartnersListActivity)
        }
        imageViewSettings.setOnClickListener { view: View? ->
            val intentSettingsActivity = Intent(this@ProfileActivity, SettingsActivity::class.java)
            startActivity(intentSettingsActivity)
        }

        sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, Context.MODE_PRIVATE)
        userId = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""
        sharedPreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE)
        isAdminChatOn = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_ADMIN_ON, false)
        /*if (isAdminChatOn == true) {
            ChatService.ioScope.launch {
                try {
                    habApp.chatAPIService.adminStatus(userId, true)
                } catch (e: Exception) {
                    showToast(this@ProfileActivity, "Server problem")
                }
            }
        } else {
            ChatService.ioScope.launch {
                try {
                    habApp.chatAPIService.adminStatus(userId, false)
                } catch (e: Exception) {
                    showToast(this@ProfileActivity, "Server problem")
                }
            }
        }*/
        HabApplication.ioScope.launch {
            try {
                habApp.chatAPIService.adminStatus(userId, isAdminChatOn)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                /*habApp.uiScope.launch {
                    showToast(this@ProfileActivity, "Server problem")
                }*/
            }
        }
        val statusColorId = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
        when (statusColorId) {
            STATUS_COLOR_GREEN -> {
                textViewStatusColorText.setText(R.string.status_color_green)
            }
            STATUS_COLOR_RED -> {
                textViewStatusColorText.setText(R.string.status_color_red)
            }
            STATUS_COLOR_ORANGE -> {
                textViewStatusColorText.setText(R.string.status_color_orange)
            }
            STATUS_COLOR_LILAC -> {
                textViewStatusColorText.setText(R.string.status_color_lilac)
            }
            STATUS_COLOR_BLUE -> {
                textViewStatusColorText.setText(R.string.status_color_blue)
            }
            STATUS_COLOR_YELLOW -> {
                textViewStatusColorText.setText(R.string.status_color_yellow)
            }
            STATUS_COLOR_GRAY -> {
                textViewStatusColorText.setText(R.string.status_color_gray)
            }
            else -> {
                textViewStatusColorText.setText(R.string.status_color_white)
            }
        }
        billingViewModel = ViewModelProvider(this).get(BillingViewModel::class.java)
        billingViewModel.statusColorLiveData.observe(this, {
            it?.apply {

                if (entitled == false) {
                    textViewStatusColorText.setText(R.string.status_color_white)
                    val sharedPreferencesUserInfoEditor: SharedPreferences.Editor = sharedPreferencesUserInfo.edit()
                    sharedPreferencesUserInfoEditor.putInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
                    sharedPreferencesUserInfoEditor.apply()
                }
            }
        })
    }

    fun searchingPeer(isSearching: Boolean) {
        HabApplication.ioScope.launch {
            //set latitude longitude instead of radius distance
            // get searchingInRadius from user settings
            val visibleInRadius = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS, DEFAULT_VISIBILITY_RADIUS_IN_METERS)
            val userStatus = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_STATUS, "Нет статуса")?: "Нет статуса"
            val userStatusColorId = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_STATUS_COLOR, STATUS_COLOR_WHITE)
            val userName = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_NAME, "")?: ""
            val userDescription = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_DESCRIPTION, "")?: "Нет описания"
            val gender = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_GENDER, GENDER_ALL)?: GENDER_ALL
            val age = sharedPreferencesUserInfo.getInt(SHARED_PREFS_KEY_USER_AGE, DEFAULT_AGE)
            val city = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_CITY, "")?: ""

            val sharedPreferencesSearchSettings = habApp.getSharedPreferences(SHARED_PREFS_SEARCHING_SETTINGS, MODE_PRIVATE)
            val searchingGender = sharedPreferencesSearchSettings.getString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER, GENDER_ALL)
                    ?: GENDER_ALL
            val searchingMinAge = sharedPreferencesSearchSettings.getInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE, DEFAULT_MIN_AGE)
            val searchingMaxAge = sharedPreferencesSearchSettings.getInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE, DEFAULT_MAX_AGE)

            val sharedPrefsCurrentCoords = getSharedPreferences(SHARED_PREFS_CURRENT_COORDINATES, MODE_PRIVATE)
            val lat = Double.Companion.fromBits(sharedPrefsCurrentCoords.getLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT, 0))
            val lng = java.lang.Double.longBitsToDouble(sharedPrefsCurrentCoords.getLong(SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG, 0))
            val searchingCity = sharedPreferencesSearchSettings.getString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY, DEFAULT_SEARCHING_CITY)?:DEFAULT_SEARCHING_CITY

            try {
                ChatService.searchingPeerResponseFlow = habApp.chatAPIService.searchingPeer(userId, lat, lng,
                        visibleInRadius, userStatus, userStatusColorId, userName, userDescription, isSearching,
                        gender, age, searchingGender, searchingMinAge, searchingMaxAge, city, searchingCity)
                searchingPeerResponseFlowCollect()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                //Log.d("InRadiusVisibleFragment", "searchingPeer error: ${e.message}")
            }
        }
    }

    override fun onStart() {
        super.onStart()

        HabApplication.ioScope.launch {
            val db = HabDB.getDatabase(applicationContext)
            val usersDAO = db.userDAO()
            val messagesDAO = db.messageDAO()
            val id = usersDAO.getUserByUserId(userId).id
            val unreadMessages = messagesDAO.getUnreadMessages(id)
            val messageCount: Int = unreadMessages.size
            habApp.uiScope.launch {
                if (messageCount > 0) {
                    newMessagesInBottomNav.visibility = View.VISIBLE
                    itemsCountLabelInBottomNav.setText("$messageCount")
                } else {
                    itemsCountLabelInBottomNav.setText("0")
                    newMessagesInBottomNav.visibility = View.GONE
                }
            }
        }

        pushnotificationJob = HabApplication.defaultScope.launch {
            PushNotificationsService.pushNotificationsFlow.onEach {
                //val messageCount: Int = PushNotificationsService.messageCounter.get()
                val db = HabDB.getDatabase(applicationContext)
                val usersDAO = db.userDAO()
                val messagesDAO = db.messageDAO()
                val id = usersDAO.getUserByUserId(userId).id
                val unreadMessages = messagesDAO.getUnreadMessages(id)
                val messageCount: Int = unreadMessages.size
                habApp.uiScope.launch {
                    if (messageCount > 0) {
                        newMessagesInBottomNav.visibility = View.VISIBLE
                        itemsCountLabelInBottomNav.setText("$messageCount")
                    } else {
                        itemsCountLabelInBottomNav.setText("0")
                        newMessagesInBottomNav.visibility = View.GONE
                    }
                }
            }.onEmpty {

            }.catch { e ->

            }.collect()
        }
    }

    override fun onStop() {
        pushnotificationJob?.cancel()
        super.onStop()
    }

    override fun onResume() {
        Log.d("HAB_", "ProfileActivity.onResume")
        super.onResume()
        val userName = userPrefs.getString(SHARED_PREFS_KEY_USER_NAME, "Нет имени")
        textViewUserName.text = userName

        val isLocationEnabled = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_LOCATION_ENABLED, false)
        if (isLocationEnabled) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            {
                createAndShowLocationPermissionDialog()
            } else {
                val isSearching = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_SEARCHING, false)
                if (isSearching == true) {
                    searchingPeer(isSearching)
                }
            }
        } else {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            {
                createAndShowLocationPermissionDialog()
            } else {
                val isSearching = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_SEARCHING, false)
                if (isSearching == true) {
                    searchingPeer(isSearching)
                }
            }
        }
    }

    fun createAndShowLocationPermissionDialog() {
        val alertDialog: AlertDialog = this.let {
            val builder = AlertDialog.Builder(it)
            builder.apply {
                setPositiveButton("Принимаю",
                        { dialog, id ->
                            // User clicked OK button
                            sharedPreferences
                                    .edit()
                                    .putBoolean(SHARED_PREFS_KEY_IS_LOCATION_ENABLED, true)
                                    .apply()
                            val locationPermissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            //ActivityCompat.requestPermissions(this@ProfileActivity, locationPermissions, REQUEST_LOCATION_PERMISSION_CODE)
                            registerForLocationPermissionResult.launch(locationPermissions)
                        })
                setNegativeButton("Отмена",
                        { dialog, id ->
                            // User cancelled the dialog
                            Utils.showToast(this@ProfileActivity, "Приложение не будет полноценно работать без доступа к местоположению!")
                            sharedPreferences
                                    .edit()
                                    .putBoolean(SHARED_PREFS_KEY_IS_LOCATION_ENABLED, false)
                                    .apply()
                        })
            }
            // Set other dialog properties
            builder.setCancelable(false)
            builder.setTitle(getString(R.string.location_alert_title))
            builder.setMessage(getString(R.string.location_alert_message))

            // Create the AlertDialog
            builder.create()
        }
        alertDialog.show()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            imageViewUserPhoto = findViewById(R.id.image_view_user_photo)

            userPrefs.edit().putInt(SHARED_PREFS_KEY_IMAGE_VIEW_USER_PHOTO_HEIGHT, imageViewUserPhoto.height).apply()
            HabApplication.defaultScope.launch {
                val userImageName = userPrefs.getString(SHARED_PREFS_KEY_USER_IMAGE, "")?:""
                if (userImageName != "") {
                    val imageUri = Uri.parse(userImageName)
                    if (ActivityCompat.checkSelfPermission(habApp, Manifest.permission.READ_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                        //ActivityCompat.requestPermissions(this@ProfileActivity,arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE)
                        registerForReadExternalStorageResult.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                    } else {
                        try {
                            /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                                contentResolver.takePersistableUriPermission(imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }*/
                            grantUriPermission(BuildConfig.APPLICATION_ID, imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            val imageStream = contentResolver.openInputStream(imageUri)
                            val selectedImage = BitmapFactory.decodeStream(imageStream)
                            imageStream?.close()
                            /*val displayMetrics = DisplayMetrics()
                            this@ProfileActivity.getWindowManager()
                                    .getDefaultDisplay()
                                    .getMetrics(displayMetrics)

                            var width = if (imageViewUserPhoto.width > 0) {imageViewUserPhoto.width} else {displayMetrics.widthPixels}
                            var height = imageViewUserPhoto.height
                            if (selectedImage.width < width) {
                                width = selectedImage.width
                            }
                            if (selectedImage.height < height) {
                                height = selectedImage.height
                            }
                            val resizedImage = Bitmap.createScaledBitmap(selectedImage, width, (selectedImage.height*0.5).toInt(), false)*/

                            //val resizedImage = Bitmap.createBitmap(selectedImage, 0,0,width, height)
                            habApp.uiScope.launch {
                                imageViewUserPhoto.setImageBitmap(selectedImage)
                            }
                        } catch (e: FileNotFoundException) {
                            habApp.uiScope.launch {
                                Utils.showToast(this@ProfileActivity, "Файл изображения не найден!")
                            }
                        }
                    }
                }
            }

        }
    }

    private suspend fun searchingPeerResponseFlowCollect() {
        ChatService.searchingPeerResponseFlow?.onEach { searchingPeerResponse->
            val responseCode = searchingPeerResponse.responseCode
            when (responseCode) {
                SEARCHING_PEER_RESPONSE_CODE_SUCCESS -> {// new searching peer found
                    //Log.d("InRadiusVisibleFragment", "1==success")
                    // download image of searching peer

                    val imageFileName = "${habApp.filesDir.absolutePath}/${searchingPeerResponse.userId}"//todo: use filename instead of searchingPeerResponse.userId
                    val imageFile = File(imageFileName)
                    if (imageFile.exists() == true) {
                        imageFile.delete()
                    }
                    try {
                        var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                        val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(searchingPeerResponse.userId)

                        downloadImageResponseFlow.onEach { downloadImageResponse ->
                            val responseCode = downloadImageResponse.responseCode
                            when (responseCode) {
                                1 -> {//keep reading file
                                    val buffer = downloadImageResponse.fileChunk.toByteArray()
                                    fileImageStream?.write(buffer)
                                    //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                                }
                                2 -> {//End of file reached
                                    fileImageStream?.flush()
                                    fileImageStream?.close()
                                    //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                                }
                                -1 -> {//error
                                    //todo: error
                                    fileImageStream?.close()
                                    fileImageStream = null
                                }
                            }
                        }.onEmpty {
                            //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                        }.catch { e ->

                        }.collect()
                    } catch (e: FileNotFoundException) {
                        //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
                    }
                    habApp.uiScope.launch {

                        //check if it.userId already exists then remove
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedUser = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedUser = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }

                        //Log.d("InRadiusVisibleFragment", "onCreateView searchingPeer: success! user_id: ${searchingPeerResponse.userId}")
                        val radiusDistanceInMeters = searchingPeerResponse.radiusDistanceInMeters
                        var listOfPeopleInRadius: RadiusAndListOfPeopleInRadius? = null

                        var indexOfRadiusCategory = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            if (radiusAndListOfPeopleInRadius.radiusDistanceInMeters == radiusDistanceInMeters) {
                                listOfPeopleInRadius = radiusAndListOfPeopleInRadius
                                indexOfRadiusCategory = index
                            }
                        }

                        /*val METERS_IN_ONE_KM = 1000
                        if (radiusDistanceInMeters == RADIUS_ALL_METERS) {
                            listOfPeopleInRadius?.textRadius = "Виден всем"
                        } else if (radiusDistanceInMeters >= METERS_IN_ONE_KM) {
                            listOfPeopleInRadius?.textRadius = "${radiusDistanceInMeters / METERS_IN_ONE_KM} Км"
                        } else {
                            listOfPeopleInRadius?.textRadius = "$radiusDistanceInMeters метров"
                        }*/
                        var existingPersonInRadiusNullable: PersonInRadius? = null
                        var isUserAlreadyExists = false

                        listOfPeopleInRadius?.personInRadiusList?.forEach { personInRadius ->
                            if (personInRadius.id == searchingPeerResponse.userId) {
                                isUserAlreadyExists = true
                                existingPersonInRadiusNullable = personInRadius
                            }
                        }

                        if (isUserAlreadyExists == true) {
                            existingPersonInRadiusNullable?.let { existingPersonInRadius ->
                                existingPersonInRadius.name = searchingPeerResponse.userName
                                existingPersonInRadius.status = searchingPeerResponse.status
                                existingPersonInRadius.description = searchingPeerResponse.description
                                existingPersonInRadius.imageName = imageFileName
                                existingPersonInRadius.radiusDistanceInMeters = radiusDistanceInMeters
                                existingPersonInRadius.statusColorId = searchingPeerResponse.statusColorId
                            }
                        } else {
                            val personInRadius = PersonInRadius()
                            personInRadius.id = searchingPeerResponse.userId
                            personInRadius.name = searchingPeerResponse.userName
                            personInRadius.status = searchingPeerResponse.status
                            personInRadius.description = searchingPeerResponse.description
                            personInRadius.radiusDistanceInMeters = radiusDistanceInMeters
                            personInRadius.imageName = imageFileName
                            personInRadius.isAdminOn = searchingPeerResponse.isAdminOn
                            personInRadius.statusColorId = searchingPeerResponse.statusColorId
                            listOfPeopleInRadius?.personInRadiusList?.add(personInRadius)
                        }
                        //Utils.showToast(habApp, "SearchingPeer: SucCESS!")
                    }
                    val db = HabDB.getDatabase(habApp)
                    val userDao = db.userDAO()
                    HabApplication.ioScope.launch {
                        //if (userDao.getUserByUserId(it.userId) == null) {
                        val user = UserDBEntity()
                        user.userId = searchingPeerResponse.userId
                        userDao.insert(user.userId, searchingPeerResponse.userName)
                        //}
                    }
                }
                SEARCHING_PEER_RESPONSE_CODE_NO_PEER -> {
                    //habApp.uiScope.launch {
                    //Utils.showToast(habApp, "SearchingPeer no user id: ${searchingPeerResponse.userId}")
                    //}
                }
                SEARCHING_PEER_RESPONSE_CODE_PEER_CLOSED -> {
                    habApp.uiScope.launch {
                        // remove searchingPeerResponse.userId from searching list
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedItem = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedItem = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                        //Utils.showToast(habApp, "SearchingPeer PEER closed")
                    }
                }
                SEARCHING_PEER_RESPONSE_CODE_PEER_OUT_OF_RADIUS -> {
                    habApp.uiScope.launch {
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedItem = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedItem = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                    }
                }
                SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_OFF -> {
                    habApp.uiScope.launch {
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedItem = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedItem = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                    }
                }
                SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_CITY_NOT_FOUND -> {
                    habApp.uiScope.launch {
                        val userIdFromResponse = searchingPeerResponse.userId
                        var indexOfRadiusCategoryOfRemovedItem = -1
                        ChatService.listOfPeopleInEveryRadiusList.forEachIndexed { index, radiusAndListOfPeopleInRadius ->
                            radiusAndListOfPeopleInRadius.personInRadiusList?.forEach { personInRadius ->
                                if (personInRadius.id == userIdFromResponse) {
                                    indexOfRadiusCategoryOfRemovedItem = index
                                }
                            }
                            radiusAndListOfPeopleInRadius.personInRadiusList?.removeAll { personInRadius ->
                                personInRadius.id == userIdFromResponse
                            }
                        }
                    }
                }
            }
        }?.onEmpty {
            /*habApp.uiScope.launch {
                Utils.showToast(habApp, "SearchingPeer: onEmpty!")
            }*/
        }?.catch { e ->
            /*habApp.uiScope.launch {
                Utils.showToast(habApp, "SearchingPeer: ERROR: ${e.message}")
            }*/
        }?.collect()
    }
}