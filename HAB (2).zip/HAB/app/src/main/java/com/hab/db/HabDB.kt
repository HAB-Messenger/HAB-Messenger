package com.hab.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.hab.utils.Utils.HAB_DATABASE
import com.hab.db.dao.BlockedUserInCollectiveChatDAO
import com.hab.db.dao.BlockedUserInPersonalChatDAO
import com.hab.db.dao.MessageDAO
import com.hab.db.dao.UserDAO
import com.hab.db.entities.BlockedUserInCollectiveChatDBEntity
import com.hab.db.entities.BlockedUserInPersonalChatDBEntity
import com.hab.db.entities.MessageDBEntity
import com.hab.db.entities.UserDBEntity

@Database(entities = [UserDBEntity::class, MessageDBEntity::class,
    BlockedUserInCollectiveChatDBEntity::class, BlockedUserInPersonalChatDBEntity::class],
        version = 1, exportSchema = false)
abstract class HabDB : RoomDatabase() {

    abstract fun userDAO(): UserDAO
    abstract fun messageDAO(): MessageDAO
    abstract fun blockedUserInCollectiveChatDAO() : BlockedUserInCollectiveChatDAO
    abstract fun blockedUserInPersonalChatDAO() : BlockedUserInPersonalChatDAO

    companion object {
        @Volatile
        private var INSTANCE: HabDB? = null

        fun getDatabase(context: Context): HabDB {
            if (INSTANCE == null) {
                synchronized(HabDB::class.java) {
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                            HabDB::class.java, HAB_DATABASE)
                            .build()
                }
            }
            return INSTANCE!!
        }
    }
}