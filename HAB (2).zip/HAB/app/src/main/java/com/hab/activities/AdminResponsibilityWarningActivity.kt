package com.hab.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.constraintlayout.widget.ConstraintLayout
import com.hab.R

class AdminResponsibilityWarningActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_responsibility_warning)

        val layoutAdminResponsibilityWarning = findViewById<ConstraintLayout>(R.id.layout_admin_responsibility_warning)
        layoutAdminResponsibilityWarning.setOnClickListener {
            finish()
        }
    }
}