package com.hab.fragments

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.hab.R
import com.hab.app.HabApplication
import com.hab.fragments.InRadiusInvisibleFragment
import com.hab.services.ChatService
import com.hab.utils.Utils
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class InRadiusInvisibleFragment : Fragment {


    constructor() : super() {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_in_radius_invisible, container, false)
    }

    override fun onResume() {
        super.onResume()

        val habApp = requireActivity().application as HabApplication
        val sharedPreferencesUserInfo = habApp.getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, Context.MODE_PRIVATE)
        val userID = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_ID, "") ?: ""

        HabApplication.ioScope.launch {
            ChatService.searchingPeerResponseFlow = habApp.chatAPIService.searchingPeer(userID, 0.0, 0.0,
                    -1, "", -1, "", "", false,
                    "", -1, "", -1, -1, "", "")
            ChatService.searchingPeerResponseFlow?.catch { e->
                //todo:
            }?.collect()
        }
    }
}