package com.hab.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.NEW_MESSAGE_NOTIFICATION_ID
import com.hab.utils.Utils.PUSH_SERVICE_NOTIFICATION_ID
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_NOTIFICATION_SETTINGS
import com.hab.utils.Utils.SHARED_PREFS_NOTIFICATION_SOUND
import com.hab.utils.Utils.SHARED_PREFS_NOTIFICATION_VIBRATION
import com.hab.utils.Utils.SHARED_PREFS_SHOW_PUSH_NOTIFICATION
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.activities.PersonalChatActivity
import com.hab.activities.ProfileActivity
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.db.entities.MessageDBEntity
import com.hab.grpc.pushnotificationservice.PushNotificationAPIService
import com.hab.grpc.pushnotificationsservice.SubscribePushNotificationResponce
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicInteger

class PushNotificationsService : Service() {

    private var isServiceRunning = false
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var pushNotificationAPIService: PushNotificationAPIService
    private var userId = ""

    companion object {
        val ioScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        //val channel = Channel<SubscribePushNotificationResponce>()
        private val _pushNotificationsFlow: MutableSharedFlow<SubscribePushNotificationResponce> = MutableSharedFlow()
        val pushNotificationsFlow = _pushNotificationsFlow.asSharedFlow()
        val messageCounter = AtomicInteger(0)
    }

    override fun onCreate() {
        pushNotificationAPIService = PushNotificationAPIService(application)
        startForeground(PUSH_SERVICE_NOTIFICATION_ID, newSystemNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        userId = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""
        startService()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }


    fun startService() {
        if (isServiceRunning == false) {
            isServiceRunning = true

            this.wakeLock = ((getSystemService(Context.POWER_SERVICE)) as PowerManager)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HAB:PushNotificationsService")
            this.wakeLock?.acquire(1*60*1000L /*1 minutes*/)

            ioScope.launch {
                    val flowSubscribeToPushNotifications = pushNotificationAPIService.subscribeToNotifications(userId)
                    flowSubscribeToPushNotifications.onEach {response:SubscribePushNotificationResponce ->
                        messageCounter.incrementAndGet()
                        //save message to HABdb.messages
                        val newMsg = response.message
                        val db = HabDB.getDatabase(applicationContext)
                        val usersDAO = db.userDAO()
                        val messagesDAO = db.messageDAO()
                        val messageEntity = MessageDBEntity()
                        var fromUser = usersDAO.getUserByUserId(response.fromUserId)
                        if (fromUser == null) {
                            usersDAO.insert(response.fromUserId, response.fromUserName)
                            fromUser = usersDAO.getUserByUserId(response.fromUserId)
                        }
                        messageEntity.toUserId = usersDAO.getUserByUserId(userId).id
                        messageEntity.fromUserId = fromUser.id
                        messageEntity.message = newMsg
                        messagesDAO.insert(messageEntity)

                        val habApp = application as HabApplication
                        habApp.uiScope.launch {
                            // check if notification is enabled in settings
                            val sharedPreferencesNotificationSettings = getSharedPreferences(SHARED_PREFS_NOTIFICATION_SETTINGS, MODE_PRIVATE)
                            val showPushNotifications = sharedPreferencesNotificationSettings.getBoolean(SHARED_PREFS_SHOW_PUSH_NOTIFICATION, true)
                            if (showPushNotifications == true) {
                                val notificationNewMessage = newNotification(response.fromUserId, fromUser.userName, newMsg)
                                val notificationManagerCompat = NotificationManagerCompat.from(applicationContext)
                                notificationManagerCompat.notify(NEW_MESSAGE_NOTIFICATION_ID, notificationNewMessage)
                            }
                        }
                        _pushNotificationsFlow.emit(response)
                    }.onEmpty {

                    }.catch {e->
                        /*val habApp = application as HabApplication
                        habApp.uiScope.launch {
                            Utils.showToast(application, "Error: ${e.message}")
                        }*/
                    }.collect()
                }
            // subscribe to push_notifications

        }
    }

    fun stopService() {
        isServiceRunning = false
        // unsubscribe from push notifications
        runBlocking {
            try {
                pushNotificationAPIService.unsubscribeToNotifications(userId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {

            }
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)

        stopService()
        stopSelf()
    }

    /*override fun onDestroy() {
        super.onDestroy()

        stopService()
    }*/

    fun newSystemNotification(): Notification {
        val notificationChannelId = "sdfsdf"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notificationChannel = NotificationChannel(notificationChannelId, "Service working", NotificationManager.IMPORTANCE_HIGH)
            notificationChannel.description = "Push service still working"
            notificationManager.createNotificationChannel(notificationChannel)
        }
        val notificationIntent = Intent(this, ProfileActivity::class.java)
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        var pendingIntentFlags = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pendingIntentFlags = PendingIntent.FLAG_IMMUTABLE
        }
        val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, Intent(), pendingIntentFlags)

        val notificationBuilder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, notificationChannelId)
        } else {
            Notification.Builder(this)
        }

        val notification = notificationBuilder
                .setContentTitle("HAB push notification service")
                .setContentText("HAB service still working")
                .setContentIntent(pendingIntent)
                .setOngoing(false)
                .build()

        return notification
    }

    suspend fun newNotification(fromUserId: String, fromUserName: String, msg:String): Notification {
        val notificationChannelId = "sdfsdf"

        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notificationChannel = NotificationChannel(notificationChannelId, "Service working", NotificationManager.IMPORTANCE_HIGH)
            notificationChannel.description = "Push service still working"
            notificationManager.createNotificationChannel(notificationChannel)
        }*/
        val notificationIntent = Intent(this, PersonalChatActivity::class.java)
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        notificationIntent.putExtra("toUserId", fromUserId)
        var pendingIntentFlags = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pendingIntentFlags = PendingIntent.FLAG_IMMUTABLE
        }
        val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, Intent(), pendingIntentFlags)

        var notificationBuilder = NotificationCompat.Builder(this, notificationChannelId)
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, notificationChannelId)
        } else {
            NotificationCompat.Builder(this, notificationChannelId)
        }*/

        notificationBuilder.setContentTitle("HAB: new message from ${fromUserName}")
                .setContentText(msg)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setOngoing(false)
                .setSmallIcon(R.drawable.user_photo_stub)
                .setAutoCancel(true)
        val sharedPreferencesNotificationSettings = getSharedPreferences(SHARED_PREFS_NOTIFICATION_SETTINGS, MODE_PRIVATE)

        val shouldVibrate = sharedPreferencesNotificationSettings.getBoolean(SHARED_PREFS_NOTIFICATION_VIBRATION, true)
        if (shouldVibrate) {
            notificationBuilder.setVibrate(longArrayOf(1000, 1000, 1000, 1000, 1000))
        } else {
            //notificationBuilder.setDefaults(DEFAULT_VIBRATE)
            notificationBuilder.setVibrate(null)
        }
        val shouldSound = sharedPreferencesNotificationSettings.getBoolean(SHARED_PREFS_NOTIFICATION_SOUND, true)
        if (shouldSound) {
            val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            notificationBuilder.setOnlyAlertOnce(true)
            notificationBuilder.setSound(alarmSound)
        } else {
            //notificationBuilder.setDefaults(DEFAULT_SOUND)
            notificationBuilder.setSound(null)
        }
        val habApp = application as HabApplication
        withContext(HabApplication.ioScope.coroutineContext) {
            val imageFileName = "${habApp.filesDir.absolutePath}/${fromUserId}"
            try {
                var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(fromUserId)

                downloadImageResponseFlow.onEach { downloadImageResponse ->
                    val responseCode = downloadImageResponse.responseCode
                    when (responseCode) {
                        1 -> {//keep reading file
                            val buffer = downloadImageResponse.fileChunk.toByteArray()
                            fileImageStream?.write(buffer)
                            Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                        }
                        2 -> {//End of file reached
                            fileImageStream?.flush()
                            fileImageStream?.close()
                            Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                            val imageUri = Uri.parse(imageFileName)
                            val imageBitmap = BitmapFactory.decodeFile(imageUri.getPath())
                            if (imageBitmap != null) {
                                /*habApp.uiScope.launch {
                                    customViewHolder.imageViewPartnerPhoto.setImageDrawable(imageDrawable)
                                }*/
                                notificationBuilder.setLargeIcon(imageBitmap)
                            } else {
                                notificationBuilder.setSmallIcon(R.drawable.user_photo_stub)

                                /*habApp.uiScope.launch {
                                    val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                    customViewHolder.imageViewPartnerPhoto.setImageDrawable(userPhotoStub)
                                }*/
                            }
                        }
                        -1 -> {//error
                            //todo: error
                            fileImageStream?.close()
                            fileImageStream = null
                            notificationBuilder.setSmallIcon(R.drawable.user_photo_stub)

                            /*habApp.uiScope.launch {
                                val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                customViewHolder.imageViewPartnerPhoto.setImageDrawable(userPhotoStub)
                            }*/
                        }
                    }
                }.onEmpty {
                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                }.catch { e ->

                }.collect()
            } catch (e: FileNotFoundException) {
                Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
            }
        }

        val notification:Notification = notificationBuilder.build()

        return notification
    }

    fun buildNotification(notificationChannelId: String, icon: Int, largeIcon: Bitmap?, fromUserName: String, msg: String):Notification {
        var notificationBuilder: Notification.Builder
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationBuilder = Notification.Builder(this, notificationChannelId)
        } else {
            notificationBuilder = Notification.Builder(this)
        }
        notificationBuilder
                .setContentTitle("HAB: new message from ${fromUserName}")
                .setContentText(msg)
                .setContentIntent(null)
                .setAutoCancel(true)
                .setOngoing(false)
                .setSmallIcon(R.drawable.user_photo_stub)
                .setAutoCancel(true)
        var notification:Notification = notificationBuilder.build()
        return notification
    }
}
