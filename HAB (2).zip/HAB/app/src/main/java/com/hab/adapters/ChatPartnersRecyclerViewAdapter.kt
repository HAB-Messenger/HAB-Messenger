package com.hab.adapters

import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils.showToast
import com.hab.activities.PersonalChatActivity
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.listeners.RemovePersonalChatListener
import com.hab.pojo.ChatPartner
import com.hab.services.ChatService
import com.hab.services.PushNotificationsService
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.io.FileOutputStream

class ChatPartnersRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private val habApp: HabApplication
    private val chatPartnerList: MutableList<ChatPartner>
    private var removePersonalChatListener: RemovePersonalChatListener

    constructor(habApp: HabApplication, chatPartnerList: MutableList<ChatPartner>, removePersonalChatListener: RemovePersonalChatListener) {
        this.habApp = habApp
        this.chatPartnerList = chatPartnerList
        this.removePersonalChatListener = removePersonalChatListener
    }

    internal inner class CustomViewHolder : RecyclerView.ViewHolder {
        var layoutChatPartner: ConstraintLayout
        var imageViewPhotoChatPartner: ShapeableImageView
        var itemsCountLabel: MaterialTextView
        var textViewNameChatPartner: TextView
        var textViewLastMessageChatPartner: TextView
        var moreActions: ImageView
        var viewAnchor: View
        private var popupWindow: PopupWindow? = null
        var Id: String? = null
        var name = ""
        var positionIndex: Int = 0

        constructor(itemView: View): super(itemView) {
            layoutChatPartner = itemView.findViewById(R.id.layout_chat_partner)
            imageViewPhotoChatPartner = itemView.findViewById(R.id.image_view_photo_chat_partner)
            itemsCountLabel = itemView.findViewById(R.id.items_count_label)
            textViewNameChatPartner = itemView.findViewById(R.id.text_view_name_chat_partner)
            textViewLastMessageChatPartner = itemView.findViewById(R.id.text_view_last_message_chat_partner)
            moreActions = itemView.findViewById(R.id.more_actions)
            viewAnchor = itemView.findViewById(R.id.view_anchor)
            layoutChatPartner.setOnClickListener { view: View? ->
                val intentChatActivity = Intent(habApp, PersonalChatActivity::class.java)
                //pass id of chat partner to ChatActivity
                intentChatActivity.putExtra("toUserId", Id)
                intentChatActivity.putExtra("toUserName", name)
                intentChatActivity.addFlags(FLAG_ACTIVITY_NEW_TASK)
                habApp.startActivity(intentChatActivity)
                itemsCountLabel.setText("0")
                chatPartnerList[positionIndex].unreadMessagesCount = 0
            }
            moreActions.setOnClickListener { view: View? ->
                //show popup window
                val inflater = habApp.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

                // Inflate the custom layout/view
                val customView = inflater.inflate(R.layout.popup_window_remove_chat, null)
                customView.setOnClickListener { view1: View? ->
                    showToast(habApp, "Чат удалён")
                    // remove chat
                    removePersonalChatListener.removePersonalChat(positionIndex)
                    popupWindow?.dismiss()
                }
                popupWindow = PopupWindow(customView,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT)
                popupWindow?.setOutsideTouchable(true)
                //popupWindow.setTouchable(true);
                popupWindow?.setFocusable(true)
                popupWindow?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                /*popupWindow.setTouchInterceptor((v, event) -> {
                    popupWindow.dismiss();
                    return true;
                });*/
                popupWindow?.showAsDropDown(viewAnchor, 0, 0)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chat_partners, parent, false)
        return CustomViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val customViewHolder = holder as CustomViewHolder
        val (id, name, lastMessage, unreadMessagesCount) = chatPartnerList[position]
        customViewHolder.textViewNameChatPartner.text = name
        customViewHolder.textViewLastMessageChatPartner.text = lastMessage
        customViewHolder.itemsCountLabel.text = "$unreadMessagesCount"
        customViewHolder.Id = id
        customViewHolder.name = name
        customViewHolder.positionIndex = position

        val imageFileName = "${habApp.filesDir.absolutePath}/${id}"
        val imageUri = Uri.parse(imageFileName)
        val imageDrawable = Drawable.createFromPath(imageUri.path)
        if (imageDrawable != null) {
            customViewHolder.imageViewPhotoChatPartner.setImageDrawable(imageDrawable)
        } else {
            HabApplication.ioScope.launch {
                try {
                    var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                    val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(id)

                    downloadImageResponseFlow.onEach { downloadImageResponse ->
                        val responseCode = downloadImageResponse.responseCode
                        when (responseCode) {
                            1 -> {//keep reading file
                                val buffer = downloadImageResponse.fileChunk.toByteArray()
                                fileImageStream?.write(buffer)
                            }
                            2 -> {//End of file reached
                                fileImageStream?.flush()
                                fileImageStream?.close()
                                val imageUri = Uri.parse(imageFileName)
                                val imageDrawable = Drawable.createFromPath(imageUri.path)
                                if (imageDrawable != null) {
                                    habApp.uiScope.launch {
                                        customViewHolder.imageViewPhotoChatPartner.setImageDrawable(imageDrawable)
                                    }
                                } else {
                                    habApp.uiScope.launch {
                                        val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                        customViewHolder.imageViewPhotoChatPartner.setImageDrawable(userPhotoStub)
                                    }
                                }
                            }
                            -1 -> {//error
                                //todo: error
                                fileImageStream?.close()
                                fileImageStream = null
                                habApp.uiScope.launch {
                                    val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                    customViewHolder.imageViewPhotoChatPartner.setImageDrawable(userPhotoStub)
                                }
                            }
                        }
                    }.onEmpty {
                        Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                    }.catch { e ->

                    }.collect()
                } catch (e: FileNotFoundException) {
                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return chatPartnerList.size
    }
}