package com.hab.listeners

interface RespondToMessageCollectiveChatListener {
    fun respond(userName: String)
}