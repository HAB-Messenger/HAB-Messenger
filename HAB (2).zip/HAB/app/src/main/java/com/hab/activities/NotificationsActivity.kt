package com.hab.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import com.hab.R
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textview.MaterialTextView
import android.widget.RadioButton
import android.widget.CompoundButton
import com.hab.utils.Utils
import com.hab.utils.Utils.SHARED_PREFS_NOTIFICATION_SOUND
import com.hab.utils.Utils.SHARED_PREFS_NOTIFICATION_VIBRATION
import com.hab.utils.Utils.SHARED_PREFS_SHOW_PUSH_NOTIFICATION

class NotificationsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Уведомления"
        val sharedPreferencesNotificationSettings = getSharedPreferences(Utils.SHARED_PREFS_NOTIFICATION_SETTINGS, MODE_PRIVATE)
        val editorSharedPreferencesNotificationSettings = sharedPreferencesNotificationSettings.edit()
        val radiobuttonNotificationsOff = findViewById<RadioButton>(R.id.radiobutton_notifications_off)
        val radiobuttonNotificationsOn = findViewById<RadioButton>(R.id.radiobutton_notifications_on)
        val radiobuttonSoundsOff = findViewById<RadioButton>(R.id.radiobutton_sounds_off)
        val radiobuttonSoundsOn = findViewById<RadioButton>(R.id.radiobutton_sounds_on)
        val radiobuttonVibrationOff = findViewById<RadioButton>(R.id.radiobutton_vibration_off)
        val radiobuttonVibrationOn = findViewById<RadioButton>(R.id.radiobutton_vibration_on)
        val radiobuttonPopupNotificationsOff = findViewById<RadioButton>(R.id.radiobutton_popup_notifications_off)
        val radiobuttonPopupNotificationsOn = findViewById<RadioButton>(R.id.radiobutton_popup_notifications_on)

        val buttonSave = findViewById<Button>(R.id.button_save)

        val isSoundOn = sharedPreferencesNotificationSettings.getBoolean(SHARED_PREFS_NOTIFICATION_SOUND, true)
        if (isSoundOn == true) {
            radiobuttonSoundsOn.isChecked = true
            radiobuttonSoundsOff.isChecked = false
        } else {
            radiobuttonSoundsOn.isChecked = false
            radiobuttonSoundsOff.isChecked = true
        }
        val isVibroOn = sharedPreferencesNotificationSettings.getBoolean(SHARED_PREFS_NOTIFICATION_VIBRATION, true)
        if (isVibroOn == true) {
            radiobuttonVibrationOn.isChecked = true
            radiobuttonVibrationOff.isChecked = false
        } else {
            radiobuttonVibrationOn.isChecked = false
            radiobuttonVibrationOff.isChecked = true
        }
        val showPushNotificationsOn = sharedPreferencesNotificationSettings.getBoolean(SHARED_PREFS_SHOW_PUSH_NOTIFICATION, true)
        if (showPushNotificationsOn == true) {
            radiobuttonPopupNotificationsOn.isChecked = true
            radiobuttonPopupNotificationsOff.isChecked = false
        } else {
            radiobuttonPopupNotificationsOn.isChecked = false
            radiobuttonPopupNotificationsOff.isChecked = true
        }
        radiobuttonNotificationsOff.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                radiobuttonNotificationsOn.isChecked = false
            }
        }
        radiobuttonNotificationsOn.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                radiobuttonNotificationsOff.isChecked = false
            }
        }
        radiobuttonSoundsOff.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                radiobuttonSoundsOn.isChecked = false
                editorSharedPreferencesNotificationSettings.putBoolean(SHARED_PREFS_NOTIFICATION_SOUND, false)
            }
        }
        radiobuttonSoundsOn.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                radiobuttonSoundsOff.isChecked = false
                editorSharedPreferencesNotificationSettings.putBoolean(SHARED_PREFS_NOTIFICATION_SOUND, true)
            }
        }
        radiobuttonVibrationOff.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                radiobuttonVibrationOn.isChecked = false
                editorSharedPreferencesNotificationSettings.putBoolean(SHARED_PREFS_NOTIFICATION_VIBRATION, false)
            }
        }
        radiobuttonVibrationOn.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                radiobuttonVibrationOff.isChecked = false
                editorSharedPreferencesNotificationSettings.putBoolean(SHARED_PREFS_NOTIFICATION_VIBRATION, true)
            }
        }
        radiobuttonPopupNotificationsOff.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                radiobuttonPopupNotificationsOn.isChecked = false
                editorSharedPreferencesNotificationSettings.putBoolean(SHARED_PREFS_SHOW_PUSH_NOTIFICATION, false)
            }
        }
        radiobuttonPopupNotificationsOn.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                radiobuttonPopupNotificationsOff.isChecked = false
                editorSharedPreferencesNotificationSettings.putBoolean(SHARED_PREFS_SHOW_PUSH_NOTIFICATION, true)
            }
        }
        buttonSave.setOnClickListener {
            editorSharedPreferencesNotificationSettings.apply()
            finish()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}