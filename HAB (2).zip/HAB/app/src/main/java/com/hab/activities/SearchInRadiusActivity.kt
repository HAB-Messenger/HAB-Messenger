package com.hab.activities

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.res.ResourcesCompat
import androidx.viewpager2.widget.ViewPager2
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener
import com.google.android.material.tabs.TabLayoutMediator
import com.google.android.material.tabs.TabLayoutMediator.TabConfigurationStrategy
import com.hab.R
import com.hab.adapters.InRadiusTabsAdapter
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.fragments.InRadiusInvisibleFragment
import com.hab.fragments.InRadiusVisibleFragment
import com.hab.services.ChatService
import com.hab.services.PushNotificationsService
import com.hab.utils.Utils
import com.hab.utils.Utils.SHARED_PREFS
import com.hab.utils.Utils.SHARED_PREFS_KEY_IS_SEARCHING
import com.hab.utils.Utils.isServiceRunning
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.launch
import java.util.*


class SearchInRadiusActivity : AppCompatActivity {

    private lateinit var habApp: HabApplication
    private lateinit var sharedPreferences: SharedPreferences
    private var tabLayout: TabLayout? = null
    private var viewPager: ViewPager2? = null
    private lateinit var newMessagesInBottomNav: RelativeLayout
    private lateinit var itemsCountLabelInBottomNav: TextView
    private var isSearching = false
    private lateinit var inRadiusVisibleFragment: InRadiusVisibleFragment

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private var lastLocation: Location? = null
    private lateinit var userId: String
    private var pushnotificationJob: Job? = null

    private val registerForFilterSearchPeopleActivity = registerForActivityResult(StartActivityForResult(), ActivityResultCallback {
        if (it.resultCode == RESULT_OK) {

        }
    })

    private val registerForLocationPermissionResult = registerForActivityResult(RequestMultiplePermissions(), ActivityResultCallback {
        permissionsGranted ->
        val permissionCoarseLocation = permissionsGranted[Manifest.permission.ACCESS_COARSE_LOCATION]?:false
        val permissionFineLocation = permissionsGranted[Manifest.permission.ACCESS_FINE_LOCATION]?:false
        if (permissionCoarseLocation || permissionFineLocation) {
            ChatService.instance?.startSendingCoordinates()
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                val lat = location?.latitude ?: 0.0
                val lng = location?.longitude ?: 0.0
                inRadiusVisibleFragment.searchingPeer(lat, lng, true)
            }
        } else {
            Utils.showToast(this, "Приложение не будет работать без доступа к местоположению!")
        }
    })

    constructor() : super(R.layout.activity_search_in_radius) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE)
        isSearching = sharedPreferences.getBoolean(SHARED_PREFS_KEY_IS_SEARCHING, false)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        val sharedPreferencesUserInfo = getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, Context.MODE_PRIVATE)
        userId = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_ID, "")?:""

        habApp = application as HabApplication

        if (isServiceRunning(this, ChatService::class.java) == false) {
            Utils.startChatServiceService(this)
        }
        if (isServiceRunning(this, PushNotificationsService::class.java) == false) {
            Utils.startPushNotificationsServiceService(this)
        }
        tabLayout = findViewById(R.id.tab_layout)
        viewPager = findViewById(R.id.view_pager)
        viewPager?.setUserInputEnabled(false)
        val imageViewRefreshSearch = findViewById<ImageView>(R.id.image_view_refresh_search)
        val imageViewFilterPeople = findViewById<ImageView>(R.id.image_view_filter_people)
        val imageViewProfile = findViewById<ImageView>(R.id.image_view_profile)
        val imageViewChat = findViewById<ImageView>(R.id.image_view_chat)
        val imageViewInRadius = findViewById<ImageView>(R.id.image_view_in_radius)
        val imageViewSettings = findViewById<ImageView>(R.id.image_view_settings)

        newMessagesInBottomNav = findViewById(R.id.new_messages_in_bottom_nav)
        itemsCountLabelInBottomNav = findViewById(R.id.items_count_label_in_bottom_nav)

        imageViewProfile.setImageResource(R.drawable.ic_profile_not_selected)
        imageViewInRadius.setImageResource(R.drawable.ic_in_radius_selected)

        imageViewRefreshSearch.setOnClickListener { view: View? ->
            val isLocationEnabled = sharedPreferences.getBoolean(Utils.SHARED_PREFS_KEY_IS_LOCATION_ENABLED, false)
            if (isLocationEnabled) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {
                    createAndShowLocationPermissionDialog()
                } else {

                    if (isSearching == true) {
                        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                            lastLocation = location
                            val lat = lastLocation?.latitude?:0.0
                            val lng = lastLocation?.longitude?:0.0
                            inRadiusVisibleFragment.searchingPeer(lat, lng, true)
                        }
                    }
                }
            } else {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {
                    createAndShowLocationPermissionDialog()
                } else {

                    if (isSearching == true) {
                        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                            lastLocation = location
                            val lat = lastLocation?.latitude?:0.0
                            val lng = lastLocation?.longitude?:0.0
                            inRadiusVisibleFragment.searchingPeer(lat, lng, true)
                        }
                    }
                }
            }
            /*if (isSearching == true) {
                if (ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    val locationPermissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    ActivityCompat.requestPermissions(this@SearchInRadiusActivity, locationPermissions, REQUEST_LOCATION_PERMISSION_CODE)
                } else {

                    fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                        lastLocation = location
                        val lat = lastLocation?.latitude?:0.0
                        val lng = lastLocation?.longitude?:0.0
                        inRadiusVisibleFragment.searchingPeer(lat, lng, true)
                    }
                }
            }*/
        }
        imageViewFilterPeople.setOnClickListener { view: View? ->
            val intentFilterPeopleActivity = Intent(this, FilterSearchPeopleActivity::class.java)
            //startActivityForResult(intentFilterPeopleActivity, FILTER_PEOPLE_RESULT)
            registerForFilterSearchPeopleActivity.launch(intentFilterPeopleActivity)
        }
        imageViewProfile.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@SearchInRadiusActivity, ProfileActivity::class.java)
            startActivity(intentProfileActivity)
        }
        imageViewChat.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@SearchInRadiusActivity, ChatPartnersListActivity::class.java)
            startActivity(intentProfileActivity)
        }
        imageViewSettings.setOnClickListener { view: View? ->
            val intentSettingsActivity = Intent(this@SearchInRadiusActivity, SettingsActivity::class.java)
            startActivity(intentSettingsActivity)
        }
    }

    override fun onStart() {
        super.onStart()

        inRadiusVisibleFragment = InRadiusVisibleFragment(application as HabApplication)
        val inRadiusTabsAdapter = InRadiusTabsAdapter(supportFragmentManager, lifecycle)
        inRadiusTabsAdapter.addFragment(inRadiusVisibleFragment)
        inRadiusTabsAdapter.addFragment(InRadiusInvisibleFragment())
        viewPager?.setAdapter(inRadiusTabsAdapter)
        if (tabLayout != null && viewPager != null) {
            TabLayoutMediator(tabLayout as TabLayout, viewPager as ViewPager2,
                TabConfigurationStrategy { tab: TabLayout.Tab, position: Int ->
                    if (position == 0) {
                        tab.text = "On"
                    } else if (position == 1) {
                        tab.text = "Off"
                    }
                }
            ).attach()
        }

        if (isSearching == false) {
            tabLayout?.setScrollPosition(1, 0f, true)
            viewPager?.currentItem = 1
        }

        HabApplication.ioScope.launch {
            val db = HabDB.getDatabase(applicationContext)
            val usersDAO = db.userDAO()
            val messagesDAO = db.messageDAO()
            val id = usersDAO.getUserByUserId(userId).id
            val unreadMessages = messagesDAO.getUnreadMessages(id)
            val messageCount: Int = unreadMessages.size
            habApp.uiScope.launch {
                if (messageCount > 0) {
                    newMessagesInBottomNav.visibility = View.VISIBLE
                    itemsCountLabelInBottomNav.setText("$messageCount")
                } else {
                    itemsCountLabelInBottomNav.setText("0")
                    newMessagesInBottomNav.visibility = View.GONE
                }
            }
        }

        pushnotificationJob = HabApplication.defaultScope.launch {
            PushNotificationsService.pushNotificationsFlow.onEach {
                //val messageCount: Int = PushNotificationsService.messageCounter.get()
                val db = HabDB.getDatabase(applicationContext)
                val usersDAO = db.userDAO()
                val messagesDAO = db.messageDAO()
                val id = usersDAO.getUserByUserId(userId).id
                val unreadMessages = messagesDAO.getUnreadMessages(id)
                val messageCount: Int = unreadMessages.size
                habApp.uiScope.launch {
                    if (messageCount > 0) {
                        newMessagesInBottomNav.visibility = View.VISIBLE
                        itemsCountLabelInBottomNav.setText("$messageCount")
                    } else {
                        itemsCountLabelInBottomNav.setText("0")
                        newMessagesInBottomNav.visibility = View.GONE
                    }
                }
            }.onEmpty {

            }.catch { e ->
            //todo
            }.collect()
        }
        when((tabLayout as TabLayout).selectedTabPosition) {
            0 -> {
                val colorTabGreen = ResourcesCompat.getColor(resources, R.color.colorTabGreen, null)
                tabLayout?.setSelectedTabIndicatorColor(colorTabGreen)
                //inRadiusVisibleFragment.searchingPeer()

                val isLocationEnabled = sharedPreferences.getBoolean(Utils.SHARED_PREFS_KEY_IS_LOCATION_ENABLED, false)
                if (isLocationEnabled) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                            && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        createAndShowLocationPermissionDialog()
                    } else {

                        /*if (isSearching == true) {
                            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                                lastLocation = location
                                val lat = lastLocation?.latitude ?: 0.0
                                val lng = lastLocation?.longitude ?: 0.0
                                inRadiusVisibleFragment.searchingPeer(lat, lng, true)
                            }
                        }*/
                    }
                } else {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                            && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        createAndShowLocationPermissionDialog()
                    }
                }

                /*if (ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    val locationPermissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                    ActivityCompat.requestPermissions(this@SearchInRadiusActivity, locationPermissions, REQUEST_LOCATION_PERMISSION_CODE)
                } else {
                    fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                        this@SearchInRadiusActivity.lastLocation = location
                        val lat = location?.latitude ?: 0.0
                        val lng = location?.longitude ?: 0.0
                        inRadiusVisibleFragment.searchingPeer(lat, lng, true)
                    }
                }*/
            }
            1 -> {
                val colorTabRed = ResourcesCompat.getColor(resources, R.color.colorTabRed, null)
                tabLayout?.setSelectedTabIndicatorColor(colorTabRed)
                inRadiusVisibleFragment.searchingPeer(0.0, 0.0, false)
            }
        }
        tabLayout?.addOnTabSelectedListener(object : OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                val position = tab.position
                when (position) {
                    0 -> {
                        val colorTabGreen = ResourcesCompat.getColor(resources, R.color.colorTabGreen, null)
                        tabLayout?.setSelectedTabIndicatorColor(colorTabGreen)
                        isSearching = true

                        val isLocationEnabled = sharedPreferences.getBoolean(Utils.SHARED_PREFS_KEY_IS_LOCATION_ENABLED, false)
                        if (isLocationEnabled) {
                            if (ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                                    && ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                createAndShowLocationPermissionDialog()
                            } else {

                                if (isSearching == true) {
                                    fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                                        lastLocation = location
                                        val lat = lastLocation?.latitude ?: 0.0
                                        val lng = lastLocation?.longitude ?: 0.0
                                        inRadiusVisibleFragment.searchingPeer(lat, lng, true)
                                    }
                                }
                            }
                        } else {
                            if (ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                                    && ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                createAndShowLocationPermissionDialog()
                            }
                        }
                        /*if (ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                                && ActivityCompat.checkSelfPermission(this@SearchInRadiusActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            val locationPermissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            ActivityCompat.requestPermissions(this@SearchInRadiusActivity, locationPermissions, REQUEST_LOCATION_PERMISSION_CODE)
                        } else {
                            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                                this@SearchInRadiusActivity.lastLocation = location
                                val lat = location?.latitude ?: 0.0
                                val lng = location?.longitude ?: 0.0
                                inRadiusVisibleFragment.searchingPeer(lat, lng, true)
                            }
                        }*/
                    }
                    1 -> {
                        val colorTabRed = ResourcesCompat.getColor(resources, R.color.colorTabRed, null)
                        tabLayout?.setSelectedTabIndicatorColor(colorTabRed)
                        isSearching = false
                        inRadiusVisibleFragment.searchingPeer(0.0, 0.0, false)
                    }
                }
                sharedPreferences.edit()
                        .putBoolean(SHARED_PREFS_KEY_IS_SEARCHING, isSearching)
                        .apply()
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {
                //int position = tab.getPosition();
                //Utils.showToast(InRadiusActivity.this, "onTabReselected:"+String.valueOf(position));
            }
        })
    }

    override fun onStop() {
        pushnotificationJob?.cancel()
        super.onStop()
    }


    fun createAndShowLocationPermissionDialog() {
        val alertDialog: AlertDialog = this.let {
            val builder = AlertDialog.Builder(it)
            builder.apply {
                setPositiveButton("Принимаю",
                        { dialog, id ->
                            // User clicked OK button
                            sharedPreferences
                                    .edit()
                                    .putBoolean(Utils.SHARED_PREFS_KEY_IS_LOCATION_ENABLED, true)
                                    .apply()
                            val locationPermissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                            //ActivityCompat.requestPermissions(this@SearchInRadiusActivity, locationPermissions, REQUEST_LOCATION_PERMISSION_CODE)
                            registerForLocationPermissionResult.launch(locationPermissions)
                        })
                setNegativeButton("Отмена",
                        { dialog, id ->
                            // User cancelled the dialog
                            Utils.showToast(this@SearchInRadiusActivity, "Приложение не будет полноценно работать без доступа к местоположению!")
                            sharedPreferences
                                    .edit()
                                    .putBoolean(Utils.SHARED_PREFS_KEY_IS_LOCATION_ENABLED, false)
                                    .apply()
                        })
            }
            // Set other dialog properties
            builder.setCancelable(false)
            builder.setTitle(getString(R.string.location_alert_title))
            builder.setMessage(getString(R.string.location_alert_message))

            // Create the AlertDialog
            builder.create()
        }
        alertDialog.show()
    }

    private fun getCalendar(date: Date?): Calendar {
        val cal = Calendar.getInstance(Locale.US)
        cal.time = date
        return cal
    }
}