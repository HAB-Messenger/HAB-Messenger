package com.hab.activities

import androidx.appcompat.app.AppCompatActivity
import android.content.SharedPreferences
import android.os.Bundle
import com.hab.R
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textview.MaterialTextView
import android.content.Intent
import android.app.Activity
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
//import com.google.android.gms.ads.*
//import com.google.android.gms.ads.interstitial.InterstitialAd
//import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.hab.utils.Utils.DEFAULT_VISIBILITY_RADIUS_IN_METERS
import com.hab.utils.Utils.RADIUS_1000_METERS
import com.hab.utils.Utils.RADIUS_100_METERS
import com.hab.utils.Utils.RADIUS_10_METERS
import com.hab.utils.Utils.RADIUS_15000_METERS
import com.hab.utils.Utils.RADIUS_250_METERS
import com.hab.utils.Utils.RADIUS_30000_METERS
import com.hab.utils.Utils.RADIUS_5000_METERS
import com.hab.utils.Utils.RADIUS_500_METERS
import com.hab.utils.Utils.RADIUS_50_METERS
import com.hab.utils.Utils.RADIUS_ALL_METERS
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO

class SelectRadiusActivity : AppCompatActivity() {
    //private var AD_UNIT_ID = ""
    //private var mInterstitialAd: InterstitialAd? = null
    var radiusInMeters: Int = DEFAULT_VISIBILITY_RADIUS_IN_METERS
    var textRadiusInMeters: String = "${DEFAULT_VISIBILITY_RADIUS_IN_METERS}м"
    lateinit var userPrefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_radius)
        userPrefs = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        val buttonSave = findViewById<Button>(R.id.button_save)
        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Радиус"
        radiusInMeters = intent.getIntExtra("current_radius", DEFAULT_VISIBILITY_RADIUS_IN_METERS)
        val imageView10mRadius = findViewById<ImageView>(R.id.image_view_10m_radius)
        val imageView50mRadius = findViewById<ImageView>(R.id.image_view_50m_radius)
        val imageView100mRadius = findViewById<ImageView>(R.id.image_view_100m_radius)
        val imageView250mRadius = findViewById<ImageView>(R.id.image_view_250m_radius)
        val imageView500mRadius = findViewById<ImageView>(R.id.image_view_500m_radius)
        val imageView1kmRadius = findViewById<ImageView>(R.id.image_view_1km_radius)
        val imageView5kmRadius = findViewById<ImageView>(R.id.image_view_5km_radius)
        val imageView15kmRadius = findViewById<ImageView>(R.id.image_view_15km_radius)
        val imageView30kmRadius = findViewById<ImageView>(R.id.image_view_30km_radius)
        val imageViewAllRadius = findViewById<ImageView>(R.id.image_view_all_radius)

        //AD_UNIT_ID = getString(R.string.admob_interstitial_id_test)
        //loadAd()

        when (radiusInMeters) {
            RADIUS_10_METERS -> {
                imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_selected)
                textRadiusInMeters = getString(R.string.radius_10_meters)//"10 м"
            }
            RADIUS_50_METERS -> {
                imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_selected)
                textRadiusInMeters = getString(R.string.radius_50_meters)//"50 м"
            }
            RADIUS_100_METERS -> {
                imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_selected)
                textRadiusInMeters = getString(R.string.radius_100_meters)//"100 м"
            }
            RADIUS_250_METERS -> {
                imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_selected)
                textRadiusInMeters = getString(R.string.radius_250_meters)//"250 м"
            }
            RADIUS_500_METERS -> {
                imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_selected)
                textRadiusInMeters = getString(R.string.radius_500_meters)//"500 м"
            }
            RADIUS_1000_METERS -> {
                imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_selected)
                textRadiusInMeters = getString(R.string.radius_1000_meters)//"1 км"
            }
            RADIUS_5000_METERS -> {
                imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_selected)
                textRadiusInMeters = getString(R.string.radius_5000_meters)//"5 км"
            }
            RADIUS_15000_METERS -> {
                imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_selected)
                textRadiusInMeters = getString(R.string.radius_15000_meters)//"15 км"
            }
            RADIUS_30000_METERS -> {
                imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_selected)
                textRadiusInMeters = getString(R.string.radius_30000_meters)//"30 км"
            }
            RADIUS_ALL_METERS -> {
                imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_selected)
                textRadiusInMeters = getString(R.string.radius_all)//"Виден всем"
            }
        }
        imageView10mRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> {}
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_selected)
            //imageView10mRadius.setBackgroundResource(R.drawable.ic_10m_radius_selected);
            radiusInMeters = RADIUS_10_METERS
            textRadiusInMeters = "10 м"
        }
        imageView50mRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> {
                }
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_selected)
            radiusInMeters = RADIUS_50_METERS
            textRadiusInMeters = "50 м"
        }
        imageView100mRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> {
                }
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_selected)
            radiusInMeters = RADIUS_100_METERS
            textRadiusInMeters = "100 м"
        }
        imageView250mRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> {
                }
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_selected)
            radiusInMeters = RADIUS_250_METERS
            textRadiusInMeters = "250 м"
        }
        imageView500mRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> {
                }
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_selected)
            radiusInMeters = RADIUS_500_METERS
            textRadiusInMeters = "500 м"
        }
        imageView1kmRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> {
                }
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_selected)
            radiusInMeters = RADIUS_1000_METERS
            textRadiusInMeters = "1 км"
        }
        imageView5kmRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> {
                }
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_selected)
            radiusInMeters = RADIUS_5000_METERS
            textRadiusInMeters = "5 км"
        }
        imageView15kmRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> {
                }
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_selected)
            radiusInMeters = RADIUS_15000_METERS
            textRadiusInMeters = "15 км"
        }
        imageView30kmRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> {
                }
                RADIUS_ALL_METERS -> imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_selected)
            radiusInMeters = RADIUS_30000_METERS
            textRadiusInMeters = "30 км"
        }
        imageViewAllRadius.setOnClickListener { view: View? ->
            when (radiusInMeters) {
                RADIUS_10_METERS -> imageView10mRadius.setImageResource(R.drawable.ic_10m_radius_not_selected)
                RADIUS_50_METERS -> imageView50mRadius.setImageResource(R.drawable.ic_50m_radius_not_selected)
                RADIUS_100_METERS -> imageView100mRadius.setImageResource(R.drawable.ic_100m_radius_not_selected)
                RADIUS_250_METERS -> imageView250mRadius.setImageResource(R.drawable.ic_250m_radius_not_selected)
                RADIUS_500_METERS -> imageView500mRadius.setImageResource(R.drawable.ic_500m_radius_not_selected)
                RADIUS_1000_METERS -> imageView1kmRadius.setImageResource(R.drawable.ic_1km_radius_not_selected)
                RADIUS_5000_METERS -> imageView5kmRadius.setImageResource(R.drawable.ic_5km_radius_not_selected)
                RADIUS_15000_METERS -> imageView15kmRadius.setImageResource(R.drawable.ic_15km_radius_not_selected)
                RADIUS_30000_METERS -> imageView30kmRadius.setImageResource(R.drawable.ic_30km_radius_not_selected)
            }
            imageViewAllRadius.setImageResource(R.drawable.ic_30km_radius_selected)
            radiusInMeters = RADIUS_ALL_METERS
            textRadiusInMeters = "Виден всем"
        }
        buttonSave.setOnClickListener { view: View? ->
            /*if (mInterstitialAd != null) {
                mInterstitialAd?.show(this)
            } else {
                saveAndFinish()
            }*/
            saveAndFinish()
        }
    }

    /*private fun loadAd() {

        val adRequest = AdRequest.Builder().build()

        InterstitialAd.load(this, AD_UNIT_ID, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                mInterstitialAd = null
            }

            override fun onAdLoaded(interstitialAd: InterstitialAd) {
                mInterstitialAd = interstitialAd
                setFullScreenContentCallback()
            }
        })
    }*/

    /*private fun setFullScreenContentCallback() {
        mInterstitialAd?.fullScreenContentCallback = object: FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                mInterstitialAd = null
                saveAndFinish()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError?) {
                mInterstitialAd = null
                saveAndFinish()
            }

            override fun onAdShowedFullScreenContent() {
            }
        }
    }*/

    private fun saveAndFinish() {
        val resultIntent = Intent()
        resultIntent.putExtra("radius_in_meters", radiusInMeters)
        resultIntent.putExtra("text_radius_in_meters", textRadiusInMeters)
        setResult(RESULT_OK, resultIntent)
        val userPrefsEditor = userPrefs.edit()
        userPrefsEditor.putInt(SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS, radiusInMeters)
        userPrefsEditor.apply()
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}