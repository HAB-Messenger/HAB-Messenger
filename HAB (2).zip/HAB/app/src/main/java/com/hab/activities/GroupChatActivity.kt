package com.hab.activities

import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils.BLOCKING_TIME_1_HOUR
import com.hab.utils.Utils.BLOCKING_TIME_3_HOURS
import com.hab.utils.Utils.BLOCKING_TIME_5_HOURS
import com.hab.utils.Utils.BLOCKING_TIME_ALWAYS
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_NAME
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.utils.Utils.showToast
import com.hab.adapters.GroupChatRecyclerViewAdapter
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.db.entities.BlockedUserInCollectiveChatDBEntity
import com.hab.grpc.chatservice.*
import com.hab.pojo.Message
import com.hab.services.ChatService
import com.hab.services.PushNotificationsService
import com.hab.utils.Utils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.util.*

class GroupChatActivity : AppCompatActivity {

    private lateinit var habApp: HabApplication
    private lateinit var newCollectiveMessageResponse: Flow<NewCollectiveMessageResponse>
    private lateinit var typingMessageResponse: Flow<TypingMessageResponse>
    private lateinit var collectiveChatClosedResponse: Flow<CollectiveChatClosedResponse>
    private lateinit var blockUserInCollectiveChatRequest: Flow<BlockUserInCollectiveChatResponse>
    private lateinit var clearCollectiveChatResponse: Flow<ClearCollectiveChatResponse>
    private var adminId: String = ""
    private var adminName: String = ""
    private var userId = ""
    private var userName = ""
    private lateinit var db:HabDB
    private lateinit var sharedPrefsUserInfo: SharedPreferences

    constructor() : super(R.layout.activity_group_chat) {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Чат"

        if (Utils.isServiceRunning(this, ChatService::class.java) == false) {
            Utils.startChatServiceService(this)
        }
        if (Utils.isServiceRunning(this, PushNotificationsService::class.java) == false) {
            Utils.startPushNotificationsServiceService(this)
        }

        sharedPrefsUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        adminId = getIntent().getStringExtra("adminId")?:""
        adminName = getIntent().getStringExtra("adminName")?:""
        //val isAdminOn = getIntent().getBooleanExtra("is_admin_on", false)
        userId = sharedPrefsUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""
        userName = sharedPrefsUserInfo.getString(SHARED_PREFS_KEY_USER_NAME, "")?:""

        habApp = application as HabApplication
        db = HabDB.getDatabase(habApp)

        val layoutChatOn: ConstraintLayout = findViewById(R.id.layout_chat_on)
        val layoutChatOff: ConstraintLayout = findViewById(R.id.layout_chat_off)
        /*if (isAdminOn) {
            layoutChatOn.setVisibility(View.VISIBLE)
            layoutChatOff.setVisibility(View.INVISIBLE)
        } else {
            layoutChatOn.setVisibility(View.INVISIBLE)
            layoutChatOff.setVisibility(View.VISIBLE)
        }*/

        val imageViewUserIcon = findViewById<ShapeableImageView>(R.id.image_view_user_icon)
        //val textViewTypingMsg = findViewById<TextView>(R.id.text_view_typing_msg)
        val animationViewTypingMsg = findViewById<LottieAnimationView>(R.id.animation_view_typing_msg)
        val recyclerViewChat = findViewById<RecyclerView>(R.id.recycler_view_chat)
        val editTextInput = findViewById<EditText>(R.id.edit_text_input)
        val textViewUserName = findViewById<TextView>(R.id.text_view_user_name)
        textViewUserName.setText(adminName)
        val buttonSendMsg = findViewById<ImageButton>(R.id.button_send_msg)
        recyclerViewChat.setLayoutManager(LinearLayoutManager(this))
        val messageList: MutableList<Message> = ArrayList()

        val imageFileName = "${habApp.filesDir.absolutePath}/${adminId}"
        val imageUri = Uri.parse(imageFileName)
        val imageDrawable = Drawable.createFromPath(imageUri.path)
        if (imageDrawable != null) {
            imageViewUserIcon.setImageDrawable(imageDrawable)
        } else {
            HabApplication.ioScope.launch {
                try {
                    var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                    val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(adminId)

                    downloadImageResponseFlow.onEach { downloadImageResponse ->
                        val responseCode = downloadImageResponse.responseCode
                        when (responseCode) {
                            1 -> {//keep reading file
                                val buffer = downloadImageResponse.fileChunk.toByteArray()
                                fileImageStream?.write(buffer)
                                Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                            }
                            2 -> {//End of file reached
                                fileImageStream?.flush()
                                fileImageStream?.close()
                                Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                                val imageUri = Uri.parse(imageFileName)
                                val imageDrawable = Drawable.createFromPath(imageUri.path)
                                if (imageDrawable != null) {
                                    habApp.uiScope.launch {
                                        imageViewUserIcon.setImageDrawable(imageDrawable)
                                    }
                                } else {
                                    habApp.uiScope.launch {
                                        val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                        imageViewUserIcon.setImageDrawable(userPhotoStub)
                                    }
                                }
                            }
                            -1 -> {//error
                                //todo: error
                                fileImageStream?.close()
                                fileImageStream = null
                                habApp.uiScope.launch {
                                    val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                    imageViewUserIcon.setImageDrawable(userPhotoStub)
                                }
                            }
                        }
                    }.onEmpty {
                        Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                    }.catch { e ->

                    }.collect()
                } catch (e: FileNotFoundException) {
                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
                }
            }
        }

        /*for (i in 0..39) {
            val message = Message()
            if (i % 2 == 0) {
                message.isFromPartner = true
            } else {
                message.isFromPartner = false
            }
            message.text = "9999dfsdfsdfsdfsdfsdfsdf9999dfsdfsdfsdfsdfsdfsdf"
            messageList.add(message)
        }*/
        val groupChatRecyclerViewAdapter: GroupChatRecyclerViewAdapter
        groupChatRecyclerViewAdapter = GroupChatRecyclerViewAdapter(habApp, messageList)
        recyclerViewChat.adapter = groupChatRecyclerViewAdapter
        recyclerViewChat.smoothScrollToPosition(groupChatRecyclerViewAdapter.itemCount)
        editTextInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun afterTextChanged(editable: Editable) {
                if (editTextInput.text.toString() == "") {
                    buttonSendMsg.setBackgroundResource(R.drawable.shape_button_send_msg)
                } else {
                    buttonSendMsg.setBackgroundResource(R.drawable.shape_pressed_button_send_msg)
                    HabApplication.ioScope.launch {
                        habApp.chatAPIService.typingGroupMessage(userId=userId)
                                .catch { e->
                                    //todo: solve error
                                }.collect()
                    }
                }
            }
        })
        //to init streaming send empty message to server via new_message grpc request
        HabApplication.ioScope.launch {
            newCollectiveMessageResponse = habApp.chatAPIService.newGroupMessage(userId,"", adminId, isAdmin = false)
            newCollectiveMessageResponse.onEach {
                val responseCode = it.responseCode
                when(responseCode) {
                    1 -> {
                        habApp.uiScope.launch {
                            layoutChatOn.setVisibility(View.VISIBLE)
                            layoutChatOff.setVisibility(View.INVISIBLE)
                            if (it.message != "") {
                                val message = Message(it.message, true, it.userId, it.userName)
                                messageList.add(message)
                                groupChatRecyclerViewAdapter.notifyDataSetChanged()
                                recyclerViewChat.smoothScrollToPosition(groupChatRecyclerViewAdapter.itemCount)
                            }
                        }
                        Log.d("ChatAPIService", "newCollectiveMessage: success!")
                    }
                    -1 -> {
                        habApp.uiScope.launch {
                            layoutChatOn.setVisibility(View.INVISIBLE)
                            layoutChatOff.setVisibility(View.VISIBLE)
                        }
                    }
                }
            }.onEmpty{
                Log.d("ChatAPIService","newCollectiveMessage: nothing")
            }.catch{ e ->
                Log.d("ChatAPIService","newCollectiveMessage error: ${e.message}")
            }.collect()
        }
        HabApplication.ioScope.launch {
            typingMessageResponse = habApp.chatAPIService.typingGroupMessage(userId=userId)
            typingMessageResponse.onEach {
                val responseCode = it.responseCode
                when(responseCode) {
                    1 -> {
                        habApp.uiScope.launch {
                            animationViewTypingMsg.visibility = View.VISIBLE
                            animationViewTypingMsg.playAnimation()
                            //textViewTypingMsg.visibility = View.VISIBLE
                            /*image_view_typing_msg.visibility = View.VISIBLE
                            val drawable = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                image_view_typing_msg.drawable as AnimatedVectorDrawable
                            } else {
                                image_view_typing_msg.drawable
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                if (drawable is AnimatedVectorDrawable) {
                                    drawable.start()
                                }
                            }*/
                            Handler(Looper.getMainLooper()).postDelayed({
                                animationViewTypingMsg.cancelAnimation()
                                animationViewTypingMsg.visibility = View.INVISIBLE
                                //textViewTypingMsg.visibility = View.INVISIBLE
                                //image_view_typing_msg.visibility = View.INVISIBLE
                            }, 2000)
                        }
                        //Log.d("ChatAPIService", "typingMessage: success!")
                    }
                }

            }.onEmpty {
                //Log.d("ChatAPIService","typingMessage: nothing")
            }.catch { e ->
                //Log.d("ChatAPIService","typingMessage error: ${e.message}")
            }.collect()
        }
        HabApplication.ioScope.launch {
            collectiveChatClosedResponse = habApp.chatAPIService.groupChatClosed(userId,false)
            collectiveChatClosedResponse.onEach {
                habApp.uiScope.launch {
                    showToast(this@GroupChatActivity, "Собеседник вышел из чата")
                    //finish()
                }
            }.onEmpty {
                //Log.d("ChatAPIService","collectiveChatClosed: nothing")
            }.catch { e->
                //Log.d("ChatAPIService","collectiveChatClosed error: ${e.message}")
            }.collect()
        }
        HabApplication.ioScope.launch {
            blockUserInCollectiveChatRequest = habApp.chatAPIService.blockUserInGroupChat(userIdToBlock = userId)
            blockUserInCollectiveChatRequest.onEach {
                when(it.responseCode) {
                    1-> {
                        //val userId = sharedPrefsUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""
                        val adminIdInDB: Int = db.userDAO().getUserByUserId(adminId).id
                        val blockedUserIdInDB: Int = db.userDAO().getUserByUserId(userId).id
                        when(it.blockingTime) {
                            BLOCKING_TIME_1_HOUR -> {
                                val currentTime = System.currentTimeMillis()
                                val blockUntilInMillis = currentTime + 1*3600*1000

                                val blockedUserInCollectiveChatEntity = BlockedUserInCollectiveChatDBEntity()
                                blockedUserInCollectiveChatEntity.adminId = adminIdInDB
                                blockedUserInCollectiveChatEntity.blockedUserId = blockedUserIdInDB
                                blockedUserInCollectiveChatEntity.blockedUntilInMillis = blockUntilInMillis
                                db.blockedUserInCollectiveChatDAO().insert(blockedUserInCollectiveChatEntity)
                                habApp.uiScope.launch {
                                    showToast(habApp, "Заблокирован на 1 час")
                                    editTextInput.isEnabled = false
                                }
                            }
                            BLOCKING_TIME_3_HOURS -> {
                                val currentTime = System.currentTimeMillis()
                                val blockUntilInMillis = currentTime + 3*3600*1000

                                val blockedUserInCollectiveChatEntity = BlockedUserInCollectiveChatDBEntity()
                                blockedUserInCollectiveChatEntity.adminId = adminIdInDB
                                blockedUserInCollectiveChatEntity.blockedUserId = blockedUserIdInDB
                                blockedUserInCollectiveChatEntity.blockedUntilInMillis = blockUntilInMillis
                                db.blockedUserInCollectiveChatDAO().insert(blockedUserInCollectiveChatEntity)
                                habApp.uiScope.launch {
                                    showToast(habApp, "Заблокирован на 3 часа")
                                    editTextInput.isEnabled = false
                                }
                            }
                            BLOCKING_TIME_5_HOURS -> {
                                val currentTime = System.currentTimeMillis()
                                val blockUntilInMillis = currentTime + 5*3600*1000

                                val blockedUserInCollectiveChatEntity = BlockedUserInCollectiveChatDBEntity()
                                blockedUserInCollectiveChatEntity.adminId = adminIdInDB
                                blockedUserInCollectiveChatEntity.blockedUserId = blockedUserIdInDB
                                blockedUserInCollectiveChatEntity.blockedUntilInMillis = blockUntilInMillis
                                db.blockedUserInCollectiveChatDAO().insert(blockedUserInCollectiveChatEntity)
                                habApp.uiScope.launch {
                                    showToast(habApp, "Заблокирован на 5 часов")
                                    editTextInput.isEnabled = false
                                }
                            }
                            BLOCKING_TIME_ALWAYS -> {
                                val blockUntilInMillis = Long.MAX_VALUE

                                val blockedUserInCollectiveChatEntity = BlockedUserInCollectiveChatDBEntity()
                                blockedUserInCollectiveChatEntity.adminId = adminIdInDB
                                blockedUserInCollectiveChatEntity.blockedUserId = blockedUserIdInDB
                                blockedUserInCollectiveChatEntity.blockedUntilInMillis = blockUntilInMillis
                                db.blockedUserInCollectiveChatDAO().insert(blockedUserInCollectiveChatEntity)
                                habApp.uiScope.launch {
                                    showToast(habApp, "Заблокирован навсегда")
                                    editTextInput.isEnabled = false
                                }
                            }
                        }
                    }
                }
            }.onEmpty {

            }.catch { e->
                //todo: process error
            }.collect()
        }
        HabApplication.ioScope.launch {
            clearCollectiveChatResponse = habApp.chatAPIService.clearGroupChat(userId = userId)
            clearCollectiveChatResponse.onEach {
                messageList.clear()
                habApp.uiScope.launch {
                    groupChatRecyclerViewAdapter.notifyDataSetChanged()
                    showToast(habApp, "Админ очистил чат")
                }
            }.onEmpty {

            }.catch { e->
                //todo: process error
            }.collect()
        }
        HabApplication.ioScope.launch {
            habApp.chatAPIService.getAdminStatus(userId,adminId).onEach {
                val isAdminOn = it.isAdminOn
                habApp.uiScope.launch {
                    if (isAdminOn) {
                        layoutChatOn.setVisibility(View.VISIBLE)
                        layoutChatOff.setVisibility(View.INVISIBLE)
                    } else {
                        layoutChatOn.setVisibility(View.INVISIBLE)
                        layoutChatOff.setVisibility(View.VISIBLE)
                    }
                }
            }.onEmpty {

            }.catch { e->
            // todo: process error
            }.collect()
        }
        buttonSendMsg.setOnClickListener { view: View? ->
            val messageText = editTextInput.text.toString()
            if (messageText != "") {
                editTextInput.setText("")
                val message = Message(messageText, false, userId, userName)
                //message.isFromPartner = false
                //message.text = messageText
                messageList.add(message)
                groupChatRecyclerViewAdapter.notifyDataSetChanged()
                recyclerViewChat.smoothScrollToPosition(groupChatRecyclerViewAdapter.itemCount)
                HabApplication.ioScope.launch {
                    habApp.chatAPIService.newGroupMessage(userId,messageText, adminId, userName, isAdmin = false)
                            .catch { e ->
                                // todo: process error
                            }.collect()
                }
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                HabApplication.ioScope.launch {
                    habApp.chatAPIService.groupChatClosed(userId,true)
                            .catch { e->
                                //todo: solve error
                            }.collect()
                    habApp.uiScope.launch {
                        finish()
                    }
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        HabApplication.ioScope.launch {
            habApp.chatAPIService.groupChatClosed(userId,true)
                    .catch { e->
                        //todo: solve error
                    }.collect()
            habApp.uiScope.launch {
                finish()
            }
        }
        super.onBackPressed()
    }
}