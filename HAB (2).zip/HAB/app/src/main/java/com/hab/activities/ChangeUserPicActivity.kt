package com.hab.activities

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.Intent.*
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.widget.Button
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.core.net.toFile
import com.canhub.cropper.CropImage
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageView
import com.canhub.cropper.options
import com.hab.BuildConfig
import com.hab.R
import com.hab.app.HabApplication
import com.hab.services.ChatService
import com.hab.utils.Utils
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_IMAGE
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.utils.Utils.copyFileFromCacheToInternalStorage
import com.hab.utils.Utils.showToast
//import com.theartofdev.edmodo.cropper.CropImage
//import com.theartofdev.edmodo.cropper.CropImageView
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt


class ChangeUserPicActivity : AppCompatActivity() {

    private lateinit var habApp : HabApplication
    private val PICK_IMAGE_FROM_GALLERY = 1
    private val PICK_IMAGE_FROM_CAMERA = 2
    private var userId: String = ""
    private val REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE = 56
    private val REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE_FOR_CAMERA = 57

    private val startCropActivityForResult = registerForActivityResult(StartActivityForResult(), ActivityResultCallback {
        val result = CropImage.getActivityResult(it.data)
        if (it.resultCode == RESULT_OK) {
            val cachedImageUri = result?.uriContent

            if (cachedImageUri != null) {
                val imageName = cachedImageUri.toString().substringAfterLast("/")

                HabApplication.ioScope.launch {
                    val resizedDownBitmap = Utils.resizeDownBitmap(cachedImageUri, habApp)
                    if (resizedDownBitmap != null) {
                        Utils.uploadImage(userId, imageName, resizedDownBitmap, habApp)
                        val imageUri = copyFileFromCacheToInternalStorage(habApp, imageName, cachedImageUri)
                        val sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
                        val sharedPreferencesUserInfoEditor = sharedPreferencesUserInfo.edit()
                        sharedPreferencesUserInfoEditor.putString(SHARED_PREFS_KEY_USER_IMAGE, imageUri.toString())
                        sharedPreferencesUserInfoEditor.apply()
                    } else {
                        habApp.uiScope.launch {
                            showToast(habApp, "Не удалось изменить размер изображения")
                        }
                    }

                    habApp.uiScope.launch {
                        val intent = Intent()
                        setResult(RESULT_OK, intent)
                        finish()
                    }
                }
            }
        } else if (it.resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
            //val error = result?.error
            showToast(this, "Ошибка обрезки изображения")
        }
    })

    private val startCameraActivityForResult = registerForActivityResult(StartActivityForResult(), ActivityResultCallback {
        if (it.resultCode == RESULT_OK) {
            val filePath = it.data?.getStringExtra("file_path")
            if (filePath != null) {
                val imageUri = FileProvider.getUriForFile(
                        this, BuildConfig.APPLICATION_ID + ".provider", File(filePath))
                //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                //contentResolver.takePersistableUriPermission(imageUri, imageReturnedIntent.flags)
                //}
                grantUriPermission(BuildConfig.APPLICATION_ID, imageUri, FLAG_GRANT_READ_URI_PERMISSION)

                if (imageUri != null) {
                    var displayMetrics = DisplayMetrics()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        this.display?.getRealMetrics(displayMetrics)
                    } else {
                        displayMetrics = this.getResources().getDisplayMetrics()
                    }
                    val imageViewUserPhotoWidth = displayMetrics.widthPixels

                    val sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
                    val defaultWidthInDP = 300
                    val defaultWidthInPx = (defaultWidthInDP * displayMetrics.density).roundToInt()
                    val imageViewUserPhotoHeight = sharedPreferencesUserInfo.getInt(Utils.SHARED_PREFS_KEY_IMAGE_VIEW_USER_PHOTO_HEIGHT, defaultWidthInPx)
                    HabApplication.ioScope.launch {
                        val resizedDownBitmap = Utils.resizeDownBitmap(imageUri, habApp, imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                        val byteArrayOutputStream = ByteArrayOutputStream()
                        resizedDownBitmap?.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
                        val resizedFile = File(habApp.cacheDir, "resized_photo_tmp_file123")
                        if (resizedFile.exists()) {
                            resizedFile.delete()
                        }
                        FileOutputStream(resizedFile).use { outputStream ->
                            byteArrayOutputStream.writeTo(outputStream)
                        }
                        val resizedImageUri = Uri.fromFile(resizedFile)
                        grantUriPermission(BuildConfig.APPLICATION_ID, resizedImageUri, FLAG_GRANT_READ_URI_PERMISSION)
                        habApp.uiScope.launch {
                            /*CropImage.activity(resizedImageUri)
                                    .setGuidelines(CropImageView.Guidelines.ON)
                                    .setMinCropResultSize(imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                                    .setMaxCropResultSize(imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                                    .start(this@ChangeUserPicActivity)*/
                            val intentCropImage = CropImage.activity(resizedImageUri)
                                    .setGuidelines(CropImageView.Guidelines.ON)
                                    .setMinCropResultSize(imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                                    .setMaxCropResultSize(imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                                    .getIntent(this@ChangeUserPicActivity)
                            startCropActivityForResult.launch(intentCropImage)
                        }
                    }
                }
            }
        }
    })

    private val startPickImageForResult = registerForActivityResult(StartActivityForResult(), ActivityResultCallback {
        if (it.resultCode == RESULT_OK) {
            val imageUri: Uri? = it.data?.data

            if (imageUri != null) {

                var displayMetrics = DisplayMetrics()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    this.display?.getRealMetrics(displayMetrics)
                } else {
                    //displayMetrics = this.getResources().getDisplayMetrics()
                    displayMetrics = Resources.getSystem().getDisplayMetrics()
                    //windowManager.defaultDisplay.getMetrics(displayMetrics)
                }
                val imageViewUserPhotoWidth = displayMetrics.widthPixels

                val sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
                val defaultHeightInDP = 300
                val defaultHeightInPx = (defaultHeightInDP * displayMetrics.density).toInt()
                val imageViewUserPhotoHeight = sharedPreferencesUserInfo.getInt(Utils.SHARED_PREFS_KEY_IMAGE_VIEW_USER_PHOTO_HEIGHT, defaultHeightInPx)
                HabApplication.ioScope.launch {
                    val resizedDownBitmap = Utils.resizeDownBitmap(imageUri, habApp, imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                    val byteArrayOutputStream = ByteArrayOutputStream()
                    resizedDownBitmap?.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
                    val resizedFile = File(habApp.cacheDir, "resized_tmp_file123")
                    if (resizedFile.exists()) {
                        resizedFile.delete()
                    }
                    FileOutputStream(resizedFile).use { outputStream ->
                        byteArrayOutputStream.writeTo(outputStream)
                    }
                    val resizedImageUri = Uri.fromFile(resizedFile)
                    grantUriPermission(BuildConfig.APPLICATION_ID, resizedImageUri, FLAG_GRANT_READ_URI_PERMISSION)
                    habApp.uiScope.launch {
                        /*CropImage.activity(resizedImageUri)
                                .setGuidelines(CropImageView.Guidelines.ON)
                                .setMinCropResultSize(imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                                .setMaxCropResultSize(imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                                .start(this@ChangeUserPicActivity)*/
                        val intentCropImage = CropImage.activity(resizedImageUri)
                                .setGuidelines(CropImageView.Guidelines.ON)
                                .setMinCropResultSize(imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                                .setMaxCropResultSize(imageViewUserPhotoWidth, imageViewUserPhotoHeight)
                                .getIntent(this@ChangeUserPicActivity)
                        startCropActivityForResult.launch(intentCropImage)
                    }
                }
            }
        }
    })

    private val requestReadExternalStoragePermissions = registerForActivityResult(ActivityResultContracts.RequestPermission(), ActivityResultCallback {
        isPermissionGranted ->
        if (isPermissionGranted) {
            var action = Intent.ACTION_PICK
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                action = Intent.ACTION_OPEN_DOCUMENT
            }
            val photoPickerIntent = Intent(action)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                photoPickerIntent.addFlags(FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            photoPickerIntent.type = resources.getString(R.string.MIME_Image)
            //startActivityForResult(photoPickerIntent, PICK_IMAGE_FROM_GALLERY)
            startPickImageForResult.launch(photoPickerIntent)
        }
    })

    private val requestReadExternalStoragePermissionsForCamera =  registerForActivityResult(ActivityResultContracts.RequestPermission(), ActivityResultCallback {
        isPermissionGranted ->
        if (isPermissionGranted) {
            val intentCameraActivity = Intent(this, CameraActivity::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                intentCameraActivity.addFlags(FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                intentCameraActivity.addFlags(FLAG_GRANT_READ_URI_PERMISSION)
                intentCameraActivity.addFlags(FLAG_GRANT_WRITE_URI_PERMISSION)
                //startActivityForResult(intentCameraActivity, PICK_IMAGE_FROM_CAMERA)
                startCameraActivityForResult.launch(intentCameraActivity)
            }
        }
    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_user_pic)
        habApp = application as HabApplication

        val sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        userId = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""

        val buttonCamera = findViewById<Button>(R.id.button_camera)
        val buttonGallery = findViewById<Button>(R.id.button_gallery)
        val buttonRemovePhoto = findViewById<Button>(R.id.button_remove_photo)
        val buttonCancel = findViewById<Button>(R.id.button_cancel)

        buttonCamera.setOnClickListener {
            if (ActivityCompat.checkSelfPermission(habApp, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                //ActivityCompat.requestPermissions(this@ChangeUserPicActivity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE_FOR_CAMERA)
                requestReadExternalStoragePermissionsForCamera.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    val intentCameraActivity = Intent(this, CameraActivity::class.java)
                    intentCameraActivity.addFlags(FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    intentCameraActivity.addFlags(FLAG_GRANT_READ_URI_PERMISSION)
                    intentCameraActivity.addFlags(FLAG_GRANT_WRITE_URI_PERMISSION)
                    //startActivityForResult(intentCameraActivity, PICK_IMAGE_FROM_CAMERA)
                    startCameraActivityForResult.launch(intentCameraActivity)
                }
            }
        }

        buttonGallery.setOnClickListener {
            if (ActivityCompat.checkSelfPermission(habApp, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                //ActivityCompat.requestPermissions(this@ChangeUserPicActivity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE)
                requestReadExternalStoragePermissions.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
            } else {
                var action = Intent.ACTION_PICK
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    action = Intent.ACTION_OPEN_DOCUMENT
                }
                val photoPickerIntent = Intent(action)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    photoPickerIntent.addFlags(FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                photoPickerIntent.type = resources.getString(R.string.MIME_Image)
                //startActivityForResult(photoPickerIntent, PICK_IMAGE_FROM_GALLERY)
                startPickImageForResult.launch(photoPickerIntent)
            }
        }

        buttonRemovePhoto.setOnClickListener {
            HabApplication.ioScope.launch {
                val userImageName = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_IMAGE, "")
                if (userImageName != "") {
                    val imageUri = Uri.parse(userImageName)
                    val imageFile = imageUri.toFile()

                    if (imageFile.exists()) {
                        imageFile.delete()
                    }
                    val sharedPreferencesUserInfoEditor = sharedPreferencesUserInfo.edit()
                    sharedPreferencesUserInfoEditor.putString(SHARED_PREFS_KEY_USER_IMAGE, "")
                    sharedPreferencesUserInfoEditor.apply()
                }
                try {
                    habApp.chatAPIService.removeImage(userId)
                }catch (e: io.grpc.StatusException) {
                    habApp.uiScope.launch {
                        Utils.showToast(applicationContext, e.message)
                    }
                }
            }
            val intent = Intent()
            setResult(RESULT_OK, intent)
            finish()
        }

        buttonCancel.setOnClickListener {
            finish()
        }
    }
}