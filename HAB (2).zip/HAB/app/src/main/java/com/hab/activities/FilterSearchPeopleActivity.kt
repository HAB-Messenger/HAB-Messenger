package com.hab.activities

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils.DEFAULT_MAX_AGE
import com.hab.utils.Utils.DEFAULT_MIN_AGE
import com.hab.utils.Utils.DEFAULT_SEARCHING_CITY
import com.hab.utils.Utils.GENDER_ALL
import com.hab.utils.Utils.GENDER_FEMALE
import com.hab.utils.Utils.GENDER_MALE
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE
import com.hab.utils.Utils.SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE
import java.util.*

class FilterSearchPeopleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter_people)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)

        val sharedPreferencesSearchSettings = getSharedPreferences(SHARED_PREFS_SEARCHING_SETTINGS, MODE_PRIVATE)

        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Фильтр"
        val rgGender = findViewById<RadioGroup>(R.id.rg_gender)
        val spinnerMinAge = findViewById<Spinner>(R.id.spinner_min_age)
        val spinnerMaxAge = findViewById<Spinner>(R.id.spinner_max_age)
        val spinnerCity = findViewById<Spinner>(R.id.spinner_city)
        val imageViewOpenSpinnerMinAge = findViewById<ImageView>(R.id.image_view_open_spinner_min_age)
        val imageViewOpenSpinnerMaxAge = findViewById<ImageView>(R.id.image_view_open_spinner_max_age)
        val imageViewOpenSpinnerCity = findViewById<ImageView>(R.id.image_view_open_spinner_city)
        val buttonSave = findViewById<Button>(R.id.button_save)
        val citiesList: MutableList<String> = ArrayList()
        citiesList.add("Все")
        citiesList.addAll(resources.getStringArray(R.array.cities))
        val spinnerCitiesArrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, citiesList)
        spinnerCity.adapter = spinnerCitiesArrayAdapter

        imageViewOpenSpinnerMinAge.setOnClickListener { view: View? -> spinnerMinAge.performClick() }
        imageViewOpenSpinnerMaxAge.setOnClickListener { view: View? -> spinnerMaxAge.performClick() }
        imageViewOpenSpinnerCity.setOnClickListener { view: View? -> spinnerCity.performClick() }
        val agesList: MutableList<Int> = ArrayList()
        for (i in 18..60) {
            agesList.add(i)
        }
        val spinnerArrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, agesList)
        spinnerMinAge.adapter = spinnerArrayAdapter
        spinnerMaxAge.adapter = spinnerArrayAdapter

        var gender = sharedPreferencesSearchSettings.getString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER, GENDER_ALL)?:GENDER_ALL
        when(gender) {
            GENDER_FEMALE -> {
                rgGender.check(R.id.rb_female)
            }
            GENDER_MALE -> {
                rgGender.check(R.id.rb_male)
            }
            GENDER_ALL -> {
                rgGender.check(R.id.rb_all)
            }
        }
        val minAge = sharedPreferencesSearchSettings.getInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE, DEFAULT_MIN_AGE)
        val maxAge = sharedPreferencesSearchSettings.getInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE, DEFAULT_MAX_AGE)

        agesList.forEachIndexed { index, item ->
            if (item == minAge) {
                spinnerMinAge.setSelection(index)
            }
            if (item == maxAge) {
                spinnerMaxAge.setSelection(index)
            }
        }

        var city = sharedPreferencesSearchSettings.getString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY, DEFAULT_SEARCHING_CITY)
        citiesList.forEachIndexed { index, item ->
            if (city == item) {
                spinnerCity.setSelection(index)
            }
        }

        buttonSave.setOnClickListener {
            val sharedPreferencesSearchSettingsEditor = sharedPreferencesSearchSettings.edit()
            val radioButtonID = rgGender.getCheckedRadioButtonId()
            val radioButton = rgGender.findViewById<RadioButton>(radioButtonID)
            val indexOfRadioButtonGender = rgGender.indexOfChild(radioButton)
            gender = GENDER_FEMALE
            when (indexOfRadioButtonGender) {
                1 -> {
                    gender = GENDER_MALE
                }
                2 -> {
                    gender = GENDER_ALL
                }
            }
            city = spinnerCity.selectedItem as String
            sharedPreferencesSearchSettingsEditor.putString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER, gender)
            sharedPreferencesSearchSettingsEditor.putInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE, spinnerMinAge.selectedItem as Int)
            sharedPreferencesSearchSettingsEditor.putInt(SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE, spinnerMaxAge.selectedItem as Int)
            sharedPreferencesSearchSettingsEditor.putString(SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY, city)
            sharedPreferencesSearchSettingsEditor.apply()
            finish()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}