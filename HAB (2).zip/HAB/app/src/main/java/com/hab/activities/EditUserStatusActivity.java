package com.hab.activities;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textview.MaterialTextView;
import com.hab.R;

import static com.hab.utils.Utils.SHARED_PREFS_USER_INFO;
import static com.hab.utils.Utils.SHARED_PREFS_KEY_USER_STATUS;
import static com.hab.utils.Utils.STATUS_CHARS_NUM;

public class EditUserStatusActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user_status);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_back);

        MaterialTextView textAppName = findViewById(R.id.text_app_name);

        textAppName.setText("Статус");

        EditText editTextStatus = findViewById(R.id.edit_text_status);
        TextView textViewNumberOfChars = findViewById(R.id.text_view_number_of_chars);
        SharedPreferences userPrefs = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE);
        String previousStatus = userPrefs.getString(SHARED_PREFS_KEY_USER_STATUS, "");

        editTextStatus.setHorizontallyScrolling(false);
        editTextStatus.setMaxLines(10);
        editTextStatus.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                int len = editTextStatus.getText().length();
                textViewNumberOfChars.setText(String.valueOf(len)+"/"+STATUS_CHARS_NUM);
            }
        });
        editTextStatus.setText(previousStatus);

        Button buttonSave = findViewById(R.id.button_save);
        buttonSave.setOnClickListener(view -> {
            String userStatus = editTextStatus.getText().toString();
            Intent resultIntent = new Intent();
            resultIntent.putExtra("text", userStatus);
            SharedPreferences.Editor userPrefsEditor = userPrefs.edit();
            userPrefsEditor.putString(SHARED_PREFS_KEY_USER_STATUS, userStatus);
            userPrefsEditor.apply();
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
