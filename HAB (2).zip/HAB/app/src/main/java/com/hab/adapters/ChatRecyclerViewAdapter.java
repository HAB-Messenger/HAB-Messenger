package com.hab.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.hab.R;
import com.hab.pojo.Message;

import java.util.List;

public class ChatRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    List<Message> messageList;


    public ChatRecyclerViewAdapter(Context context, List<Message> messageList) {
        this.context = context;
        this.messageList = messageList;
    }

    class CustomViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout layoutItemMessage;
        ConstraintLayout layoutMessageFromMe;
        ConstraintLayout layoutMessageFromPartner;
        TextView textViewMessageFromMe;
        TextView textViewMessageFromPartner;

        CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutItemMessage = itemView.findViewById(R.id.layout_item_message);
            layoutMessageFromMe = itemView.findViewById(R.id.layout_message_from_me);
            layoutMessageFromPartner = itemView.findViewById(R.id.layout_message_from_partner);
            textViewMessageFromMe = itemView.findViewById(R.id.text_view_message_from_me);
            textViewMessageFromPartner = itemView.findViewById(R.id.text_view_message_from_partner);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message, parent, false);
        CustomViewHolder customViewHolder = new CustomViewHolder(view);
        return customViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        CustomViewHolder customViewHolder = (CustomViewHolder) holder;
        Message message = messageList.get(position);
        if (message.isFromPartner()) {
            customViewHolder.layoutMessageFromPartner.setVisibility(View.VISIBLE);
            customViewHolder.layoutMessageFromMe.setVisibility(View.INVISIBLE);
            customViewHolder.textViewMessageFromPartner.setText(message.getText());
        } else {
            customViewHolder.layoutMessageFromMe.setVisibility(View.VISIBLE);
            customViewHolder.layoutMessageFromPartner.setVisibility(View.INVISIBLE);
            customViewHolder.textViewMessageFromMe.setText(message.getText());
        }
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }
}
