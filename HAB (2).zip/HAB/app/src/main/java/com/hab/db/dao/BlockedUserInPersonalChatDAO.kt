package com.hab.db.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.hab.db.entities.BlockedUserInPersonalChatDBEntity

@Dao
interface BlockedUserInPersonalChatDAO {
    @Insert
    fun insert(blockedUserInCollectiveChatDBEntity: BlockedUserInPersonalChatDBEntity?)

    @Query("SELECT * FROM blocked_users_in_personal_chat WHERE blocked_user_id = :userID AND admin_id = :adminId")
    fun getBlockedUserByUserId(userID: Int, adminId: Int): BlockedUserInPersonalChatDBEntity?

    @Delete
    fun delete(user: BlockedUserInPersonalChatDBEntity)
}