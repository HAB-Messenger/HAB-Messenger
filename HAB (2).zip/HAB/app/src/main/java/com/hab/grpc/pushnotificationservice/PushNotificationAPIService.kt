package com.hab.grpc.pushnotificationservice

import android.app.Application
import com.hab.utils.Utils.GRPC_PUSH_NOTIFICATION_SERVER_ADDRESS
import com.hab.utils.Utils.GRPC_PUSH_NOTIFICATION_SERVER_PORT
import com.hab.app.HabApplication
import com.hab.grpc.pushnotificationsservice.*
import io.grpc.ManagedChannel
import io.grpc.android.AndroidChannelBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor
import kotlinx.coroutines.flow.*
import java.io.Closeable
import java.util.concurrent.TimeUnit

class PushNotificationAPIService: Closeable {

    private val application: HabApplication
    private var channel: ManagedChannel
    private var pushNotificationCoroutineStub: PushNotificationsGrpcKt.PushNotificationsCoroutineStub


    constructor(application: Application) {
        this.application = application as HabApplication
        this.channel = AndroidChannelBuilder
                .forAddress(GRPC_PUSH_NOTIFICATION_SERVER_ADDRESS, GRPC_PUSH_NOTIFICATION_SERVER_PORT)
                .usePlaintext()
                .executor(Dispatchers.Default.asExecutor())
                .keepAliveWithoutCalls(true)
                .keepAliveTimeout(30, TimeUnit.SECONDS)
                .build()
        pushNotificationCoroutineStub = PushNotificationsGrpcKt.PushNotificationsCoroutineStub(channel)
    }

    private fun reconnectIfTerminated() {
        if (channel.isTerminated || channel.isShutdown) {
            this.channel = AndroidChannelBuilder
                    .forAddress(GRPC_PUSH_NOTIFICATION_SERVER_ADDRESS, GRPC_PUSH_NOTIFICATION_SERVER_PORT)
                    .usePlaintext()
                    .executor(Dispatchers.Default.asExecutor())
                    .keepAliveWithoutCalls(true)
                    .keepAliveTimeout(30, TimeUnit.SECONDS)
                    .build()
            pushNotificationCoroutineStub = PushNotificationsGrpcKt.PushNotificationsCoroutineStub(channel)
        }
    }

    fun subscribeToNotifications(userId: String): Flow<SubscribePushNotificationResponce> {
        reconnectIfTerminated()
        val subscribePushNotificationRequest = SubscribePushNotificationRequest.newBuilder()
                .setUserId(userId)
                .build()
        return pushNotificationCoroutineStub.subscribeToPushNotifications(subscribePushNotificationRequest)
    }

    suspend fun unsubscribeToNotifications(userId: String): UnSubscribePushNotificationResponce {
        reconnectIfTerminated()
        val unsubscribeToPushNotificationRequest = UnSubscribePushNotificationRequest.newBuilder()
                .setUserId(userId)
                .build()
        return pushNotificationCoroutineStub.unSubscribePushNotification(unsubscribeToPushNotificationRequest)
    }

    override fun close() {
        this.channel.shutdown().awaitTermination(2, TimeUnit.SECONDS)
    }
}