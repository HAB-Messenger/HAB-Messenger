package com.hab.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hab.R
import com.hab.app.HabApplication
import com.hab.pojo.PersonInRadius
import com.hab.pojo.RadiusAndListOfPeopleInRadius
import java.util.concurrent.CopyOnWriteArrayList

class AllPossibleRadiusesRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private var habApp: HabApplication
    private var radiusAndListOfPeopleInRadius: List<RadiusAndListOfPeopleInRadius>


    constructor(habApp: HabApplication, radiusAndListOfPeopleInRadius: List<RadiusAndListOfPeopleInRadius>): super() {
        this.habApp = habApp
        this.radiusAndListOfPeopleInRadius = radiusAndListOfPeopleInRadius
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_all_possible_radiuses_recyclerview, parent, false)
        return CustomViewHolder(view as ConstraintLayout)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val customViewHolder = holder as CustomViewHolder
        val textRadius = radiusAndListOfPeopleInRadius[position].textRadius
        customViewHolder.textViewRadiusInMeters.text = textRadius
        val linearLayoutManager = LinearLayoutManager(habApp)
        linearLayoutManager.orientation = RecyclerView.HORIZONTAL
        customViewHolder.recyclerViewPeopleInRadius.layoutManager = linearLayoutManager
        val peopleInRadiusRecyclerViewAdapter: PeopleInRadiusRecyclerViewAdapter
        val personInRadiusList = radiusAndListOfPeopleInRadius[position].personInRadiusList?: listOf()
        peopleInRadiusRecyclerViewAdapter = PeopleInRadiusRecyclerViewAdapter(habApp, personInRadiusList)
        customViewHolder.recyclerViewPeopleInRadius.adapter = peopleInRadiusRecyclerViewAdapter
        if (personInRadiusList.size > 0) {
            customViewHolder.layout.visibility = View.VISIBLE
        } else {
            customViewHolder.layout.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return radiusAndListOfPeopleInRadius.size
    }

    internal inner class CustomViewHolder : RecyclerView.ViewHolder {
        var layout: ConstraintLayout
        var textViewRadiusInMeters: TextView
        var recyclerViewPeopleInRadius: RecyclerView
        var viewDivider: View? = null

        constructor(layout: ConstraintLayout): super(layout) {
            this.layout = layout.findViewById(R.id.wrapper_constraint_layout)
            textViewRadiusInMeters = layout.findViewById(R.id.text_view_radius_in_meters)
            recyclerViewPeopleInRadius = layout.findViewById(R.id.recycler_view_people_in_radius)
        }
    }
}