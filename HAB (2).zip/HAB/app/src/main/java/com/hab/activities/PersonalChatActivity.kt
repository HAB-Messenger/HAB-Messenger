package com.hab.activities

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.BLOCKING_TIME_1_HOUR
import com.hab.utils.Utils.BLOCKING_TIME_3_HOURS
import com.hab.utils.Utils.BLOCKING_TIME_5_HOURS
import com.hab.utils.Utils.BLOCKING_TIME_ALWAYS
import com.hab.utils.Utils.NEW_MESSAGE_NOTIFICATION_ID
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.adapters.ChatRecyclerViewAdapter
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.db.dao.BlockedUserInPersonalChatDAO
import com.hab.db.dao.MessageDAO
import com.hab.db.dao.UserDAO
import com.hab.db.entities.BlockedUserInPersonalChatDBEntity
import com.hab.db.entities.MessageDBEntity
import com.hab.grpc.chatservice.*
import com.hab.pojo.Message
import com.hab.services.ChatService
import com.hab.services.PushNotificationsService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.util.*

class PersonalChatActivity : AppCompatActivity() {

    private lateinit var habApp: HabApplication
    private lateinit var newMessageResponse: Flow<NewMessageResponse>
    private lateinit var typingMessageResponse: Flow<TypingMessageResponse>
    private lateinit var chatClosedResponse: Flow<ChatClosedResponse>
    private lateinit var blockUserInPersonalChatResponse: Flow<BlockUserInPersonalChatResponse>
    private lateinit var clearPersonalChatResponse: Flow<ClearPersonalChatResponse>

    private var chatRecyclerViewAdapter: ChatRecyclerViewAdapter? = null

    private val messageList: MutableList<Message> = ArrayList()

    private var userId = ""
    private lateinit var peerId: String
    private lateinit var peerName: String

    private lateinit var userDAO: UserDAO
    private lateinit var messageDAO: MessageDAO
    private lateinit var blockedUserInPersonalChatDAO: BlockedUserInPersonalChatDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_personal_chat)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Сообщения"// set username

        if (Utils.isServiceRunning(this, ChatService::class.java) == false) {
            Utils.startChatServiceService(this)
        }
        if (Utils.isServiceRunning(this, PushNotificationsService::class.java) == false) {
            Utils.startPushNotificationsServiceService(this)
        }
        val userInfoSharedPreferences = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        userId = userInfoSharedPreferences.getString(SHARED_PREFS_KEY_USER_ID, "")?:""
        val intent = intent
        peerId = intent.getStringExtra("toUserId")?:""
        peerName = intent.getStringExtra("toUserName")?:""

        habApp = application as HabApplication
        val personalMessagesDB = HabDB.getDatabase(habApp)
        userDAO = personalMessagesDB.userDAO()
        messageDAO = personalMessagesDB.messageDAO()
        blockedUserInPersonalChatDAO = personalMessagesDB.blockedUserInPersonalChatDAO()

        //val manager: NotificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        //manager.cancel(1)
        NotificationManagerCompat.from(this).cancel(NEW_MESSAGE_NOTIFICATION_ID)

        val moreActions = findViewById<ImageView>(R.id.more_actions)
        val viewAnchor = findViewById<View>(R.id.view_anchor)
        val textViewUserName = findViewById<TextView>(R.id.text_view_user_name)
        textViewUserName.setText(peerName)
        val imageViewUserIcon = findViewById<ShapeableImageView>(R.id.image_view_user_icon)
        val recyclerViewChatMessages = findViewById<RecyclerView>(R.id.recycler_view_chat_messages)
        //val textViewTypingMsg = findViewById<TextView>(R.id.text_view_typing_msg)
        val animationViewTypingMsg = findViewById<LottieAnimationView>(R.id.animation_view_typing_msg)
        //val image_view_typing_msg = findViewById<ImageView>(R.id.image_view_typing_msg)
        val editTextInput = findViewById<EditText>(R.id.edit_text_input)
        val buttonSendMsg = findViewById<ImageButton>(R.id.button_send_msg)
        recyclerViewChatMessages.layoutManager = LinearLayoutManager(this)

        val imageFileName = "${habApp.filesDir.absolutePath}/${peerId}"
        val imageUri = Uri.parse(imageFileName)
        val imageDrawable = Drawable.createFromPath(imageUri.path)
        if (imageDrawable != null) {
            imageViewUserIcon.setImageDrawable(imageDrawable)
        } else {
            HabApplication.ioScope.launch {
                try {
                    var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                    val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(peerId)

                    downloadImageResponseFlow.onEach { downloadImageResponse ->
                        val responseCode = downloadImageResponse.responseCode
                        when (responseCode) {
                            1 -> {//keep reading file
                                val buffer = downloadImageResponse.fileChunk.toByteArray()
                                fileImageStream?.write(buffer)
                                Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                            }
                            2 -> {//End of file reached
                                fileImageStream?.flush()
                                fileImageStream?.close()
                                Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                                val imageUri = Uri.parse(imageFileName)
                                val imageDrawable = Drawable.createFromPath(imageUri.path)
                                if (imageDrawable != null) {
                                    habApp.uiScope.launch {
                                        imageViewUserIcon.setImageDrawable(imageDrawable)
                                    }
                                } else {
                                    habApp.uiScope.launch {
                                        val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                        imageViewUserIcon.setImageDrawable(userPhotoStub)
                                    }
                                }
                            }
                            -1 -> {//error
                                //todo: error
                                fileImageStream?.close()
                                fileImageStream = null
                                habApp.uiScope.launch {
                                    val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                    imageViewUserIcon.setImageDrawable(userPhotoStub)
                                }
                            }
                        }
                    }.onEmpty {
                        Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                    }.catch { e ->

                    }.collect()
                } catch (e: FileNotFoundException) {
                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
                }
            }
        }

        var popupWindow: PopupWindow? = null
        moreActions.setOnClickListener {
            val inflater =  this.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater

            // Inflate the custom layout/view
            val customView = inflater.inflate(R.layout.popup_window_personal_chat_more_actions, null)
            val layoutBlockUser = customView.findViewById<ConstraintLayout>(R.id.layout_block_user)
            layoutBlockUser.setOnClickListener{
                Utils.showToast(this, "Пользователь заблокирован")
                // block user
                HabApplication.ioScope.launch {
                    habApp.chatAPIService.blockUserInPersonalChat(peerId, userId, BLOCKING_TIME_1_HOUR)
                            .catch { e->
                                //todo: process error
                            }.collect()
                }
                popupWindow?.dismiss()
            }
            val layoutComplain = customView.findViewById<ConstraintLayout>(R.id.layout_complain)
            layoutComplain.setOnClickListener{
                // report user
                val intentReportUserActivity = Intent(this, ReportUserActivity::class.java)
                startActivity(intentReportUserActivity)
                popupWindow?.dismiss()
            }
            val layoutRemoveChat = customView.findViewById<ConstraintLayout>(R.id.layout_remove_chat)
            layoutRemoveChat.setOnClickListener{
                Utils.showToast(this, "Чат удалён")
                // remove chat
                HabApplication.ioScope.launch {
                    // remove messages from db.messages
                    val id = userDAO.getUserByUserId(userId).id
                    val to_id = userDAO.getUserByUserId(peerId)?.id?:-1
                    messageDAO.deleteAll(id, to_id)
                    messageDAO.deleteAll(to_id, id)

                    habApp.chatAPIService.clearPersonalChat(peerId, true, userId)
                            .catch { e->
                                //todo: process error
                            }.collect()
                }
                messageList.clear()
                chatRecyclerViewAdapter?.notifyDataSetChanged()
                //todo remove messages from db.messages
                popupWindow?.dismiss()
            }
            popupWindow = PopupWindow(customView,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT)
            popupWindow?.setOutsideTouchable(true)
            //popupWindow.setTouchable(true)
            popupWindow?.setFocusable(true)
            popupWindow?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));
            /*popupWindow.setTouchInterceptor((v, event) -> {
                popupWindow.dismiss()
                return true
            });*/
            popupWindow?.showAsDropDown(viewAnchor, 0, 0)
        }

        // load messages of personal chat from personal_messages_database via PersonalMessagesDB(messages table)
        HabApplication.ioScope.launch {
            val id = userDAO.getUserByUserId(userId).id
            val to_id = userDAO.getUserByUserId(peerId)?.id?:-1
            val listOfMessagesFromDB = messageDAO.getMessages(id, to_id)
            for (messageFromDB in listOfMessagesFromDB) {
                val message = Message(messageFromDB.message, userId="", userName="")
                if (messageFromDB.fromUserId == id) {
                    message.isFromPartner = false
                } else if (messageFromDB.fromUserId == to_id) {
                    message.isFromPartner = true
                }
                //message.text = messageFromDB.message
                messageList.add(message)
                messageFromDB.isRead = true
                messageDAO.update(messageFromDB)
            }
            habApp.uiScope.launch {
                chatRecyclerViewAdapter = ChatRecyclerViewAdapter(this@PersonalChatActivity, messageList)
                recyclerViewChatMessages.adapter = chatRecyclerViewAdapter
                val itemCount = chatRecyclerViewAdapter?.itemCount?:0
                recyclerViewChatMessages.smoothScrollToPosition(itemCount)
            }
        }
        /*for (i in 0..39) {
            val message = Message()
            if (i % 2 == 0) {
                message.isFromPartner = true
            } else {
                message.isFromPartner = false
            }
            message.text = "sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf"
            messageList.add(message)
        }*/
        editTextInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun afterTextChanged(editable: Editable) {
                if (editTextInput.text.toString() == "") {
                    buttonSendMsg.setBackgroundResource(R.drawable.shape_button_send_msg)
                } else {
                    buttonSendMsg.setBackgroundResource(R.drawable.shape_pressed_button_send_msg)
                    HabApplication.ioScope.launch {
                        habApp.chatAPIService.typingMessage(userId,peerId)
                                .catch { e ->
                                    //todo: solve error
                                }.collect()
                    }
                }
            }
        })
        //to init streaming send empty message to server via new_message grpc request
        HabApplication.ioScope.launch {
            newMessageResponse = habApp.chatAPIService.newMessage(userId, "", peerId)
            newMessageResponse.onEach {
                val responseCode = it.responseCode
                when(responseCode) {
                    1 -> {//1 == ok
                        habApp.uiScope.launch {
                            val message = Message(it.message, true, "", "")
                            //message.isFromPartner = true
                            //message.text = it.message
                            messageList.add(message)
                            chatRecyclerViewAdapter?.notifyDataSetChanged()
                            val itemCount = chatRecyclerViewAdapter?.itemCount ?: 0
                            recyclerViewChatMessages.smoothScrollToPosition(itemCount)
                        }
                        val toId = userDAO.getUserByUserId(userId).id
                        val fromId = userDAO.getUserByUserId(peerId).id
                        val msgEntity = MessageDBEntity()
                        msgEntity.fromUserId = fromId
                        msgEntity.toUserId = toId
                        msgEntity.message = it.message
                        msgEntity.isRead = true
                        HabApplication.ioScope.launch {
                            messageDAO.insert(msgEntity)
                        }
                        Log.d("ChatAPIService", "newMessage: success!")
                    }
                }
            }.onEmpty{
                Log.d("ChatAPIService", "newMessage: nothing")
            }.catch{ e ->
                Log.d("ChatAPIService", "newMessage error: ${e.message}")
            }.collect()
        }
        HabApplication.ioScope.launch {
            typingMessageResponse = habApp.chatAPIService.typingMessage(userId,peerId)
            typingMessageResponse.onEach {
                val responseCode = it.responseCode
                when(responseCode) {
                    1 -> {
                        habApp.uiScope.launch {
                            animationViewTypingMsg.visibility = View.VISIBLE
                            animationViewTypingMsg.playAnimation()
                            //textViewTypingMsg.visibility = View.VISIBLE
                            /*image_view_typing_msg.visibility = View.VISIBLE
                            val drawable = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                image_view_typing_msg.drawable as AnimatedVectorDrawable
                            } else {
                                image_view_typing_msg.drawable
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                if (drawable is AnimatedVectorDrawable) {
                                    drawable.start()
                                }
                            }*/
                            Handler(Looper.getMainLooper()).postDelayed({
                                animationViewTypingMsg.cancelAnimation()
                                animationViewTypingMsg.visibility = View.INVISIBLE
                                //textViewTypingMsg.visibility = View.INVISIBLE
                                //image_view_typing_msg.visibility = View.INVISIBLE
                            }, 2000)
                        }
                        Log.d("ChatAPIService", "typingMessage: success!")
                    }
                }

            }.onEmpty {
                Log.d("ChatAPIService", "typingMessage: nothing")
            }.catch { e ->
                Log.d("ChatAPIService", "typingMessage error: ${e.message}")
            }.collect()
        }
        HabApplication.ioScope.launch {
            chatClosedResponse = habApp.chatAPIService.chatClosed(userId, false, peerId)
            chatClosedResponse.onEach {
                habApp.uiScope.launch {
                    Utils.showToast(this@PersonalChatActivity, "Собеседник вышел из чата")
                    //finish()
                }
            }.onEmpty {

            }.catch { e->
                Log.d("ChatAPIService", "chatClosed error: ${e.message}")
            }.collect()
        }

        HabApplication.ioScope.launch {
            blockUserInPersonalChatResponse = habApp.chatAPIService.blockUserInPersonalChat(userId = userId)
            blockUserInPersonalChatResponse.onEach {
                when(it.responseCode) {
                    1-> {
                        val blockingUserId = it.userId
                        val blockingTime = it.blockingTime

                        val blockingUserIdInDB = userDAO.getUserByUserId(blockingUserId).id
                        val blockedUserIdInDB = userDAO.getUserByUserId(userId).id

                        when(blockingTime) {
                            BLOCKING_TIME_1_HOUR -> {
                                val currentTime = System.currentTimeMillis()
                                val blockUntilInMillis = currentTime + 1*3600*1000

                                val blockedUserInPersonalChatEntity = BlockedUserInPersonalChatDBEntity()
                                blockedUserInPersonalChatEntity.adminId = blockingUserIdInDB
                                blockedUserInPersonalChatEntity.blockedUserId = blockedUserIdInDB
                                blockedUserInPersonalChatEntity.blockedUntilInMillis = blockUntilInMillis
                                blockedUserInPersonalChatDAO.insert(blockedUserInPersonalChatEntity)
                            }
                            BLOCKING_TIME_3_HOURS -> {
                                val currentTime = System.currentTimeMillis()
                                val blockUntilInMillis = currentTime + 3*3600*1000

                                val blockedUserInPersonalChatEntity = BlockedUserInPersonalChatDBEntity()
                                blockedUserInPersonalChatEntity.adminId = blockingUserIdInDB
                                blockedUserInPersonalChatEntity.blockedUserId = blockedUserIdInDB
                                blockedUserInPersonalChatEntity.blockedUntilInMillis = blockUntilInMillis
                                blockedUserInPersonalChatDAO.insert(blockedUserInPersonalChatEntity)
                            }
                            BLOCKING_TIME_5_HOURS -> {
                                val currentTime = System.currentTimeMillis()
                                val blockUntilInMillis = currentTime + 5*3600*1000

                                val blockedUserInPersonalChatEntity = BlockedUserInPersonalChatDBEntity()
                                blockedUserInPersonalChatEntity.adminId = blockingUserIdInDB
                                blockedUserInPersonalChatEntity.blockedUserId = blockedUserIdInDB
                                blockedUserInPersonalChatEntity.blockedUntilInMillis = blockUntilInMillis
                                blockedUserInPersonalChatDAO.insert(blockedUserInPersonalChatEntity)
                            }
                            BLOCKING_TIME_ALWAYS -> {
                                val blockUntilInMillis = Long.MAX_VALUE

                                val blockedUserInPersonalChatEntity = BlockedUserInPersonalChatDBEntity()
                                blockedUserInPersonalChatEntity.adminId = blockingUserIdInDB
                                blockedUserInPersonalChatEntity.blockedUserId = blockedUserIdInDB
                                blockedUserInPersonalChatEntity.blockedUntilInMillis = blockUntilInMillis
                                blockedUserInPersonalChatDAO.insert(blockedUserInPersonalChatEntity)
                            }
                        }
                        habApp.uiScope.launch {
                            Utils.showToast(this@PersonalChatActivity, "Вы заблокированы!")
                            editTextInput.isEnabled = false
                        }
                    }
                }
            }.onEmpty {

            }.catch { e->

            }.collect()
        }

        HabApplication.ioScope.launch {
            clearPersonalChatResponse = habApp.chatAPIService.clearPersonalChat(peerId, false, userId)
            clearPersonalChatResponse.onEach {
                when(it.responseCode) {
                    1 -> {
                        // remove messages from db.messages
                        val id = userDAO.getUserByUserId(userId).id
                        val to_id = userDAO.getUserByUserId(peerId).id
                        messageDAO.deleteAll(id, to_id)
                        messageDAO.deleteAll(to_id, id)

                        habApp.uiScope.launch {
                            messageList.clear()
                            chatRecyclerViewAdapter?.notifyDataSetChanged()
                            Utils.showToast(this@PersonalChatActivity, "Собеседник удалил сообщения")
                        }
                    }
                    -1 -> {

                    }
                }
            }.onEmpty {

            }.catch { e->

            }.collect()
        }

        buttonSendMsg.setOnClickListener { view: View? ->
            val messageText = editTextInput.text.toString()
            if (messageText != "") {
                editTextInput.setText("")
                val message = Message(messageText)
                //message.isFromPartner = false
                //message.text = messageText
                messageList.add(message)
                chatRecyclerViewAdapter?.notifyDataSetChanged()
                val itemCount = chatRecyclerViewAdapter?.itemCount?:0
                recyclerViewChatMessages.smoothScrollToPosition(itemCount)
                HabApplication.ioScope.launch {
                    habApp.chatAPIService.newMessage(userId, messageText, peerId)
                            .catch { e->
                                //todo: process error
                            }.collect()
                }
                HabApplication.ioScope.launch {
                    val fromId = userDAO.getUserByUserId(userId).id
                    val toId = userDAO.getUserByUserId(peerId)?.id?:-1
                    val msgEntity = MessageDBEntity()
                    msgEntity.fromUserId = fromId
                    msgEntity.toUserId = toId
                    msgEntity.message = messageText
                    msgEntity.isRead = true
                    messageDAO.insert(msgEntity)
                }
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                HabApplication.ioScope.launch {
                    habApp.chatAPIService.chatClosed(userId, true, peerId)
                            .catch { e ->
                                //todo: solve error
                            }.collect()
                    habApp.uiScope.launch {
                        finish()
                    }
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        HabApplication.ioScope.launch {
            habApp.chatAPIService.chatClosed(userId, true, peerId)
                    .catch { e ->
                        //todo: solve error
                    }.collect()
            habApp.uiScope.launch {
                finish()
            }
        }
        super.onBackPressed()
    }
}