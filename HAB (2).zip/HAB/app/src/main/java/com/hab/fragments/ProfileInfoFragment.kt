package com.hab.fragments

import android.app.Activity
import android.widget.TextView
import android.view.LayoutInflater
import android.view.ViewGroup
import android.os.Bundle
import com.hab.R
import androidx.constraintlayout.widget.ConstraintLayout
import android.content.Intent
import android.view.View
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.hab.activities.EditUserStatusActivity
import com.hab.fragments.ProfileInfoFragment
import com.hab.activities.SelectRadiusActivity

class ProfileInfoFragment : Fragment() {
    var textViewStatusText: TextView? = null
    var textViewDescriptionText: TextView? = null
    var textViewRadiusText: TextView? = null
    var radiusInMeters = 1000

    val activityResultEditUserStatusActivity = registerForActivityResult(ActivityResultContracts.StartActivityForResult(), ActivityResultCallback {
        result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val statusText = result.data?.getStringExtra("text")?:""
            if (statusText != "") {
                textViewStatusText?.text = statusText
            }
        }
    })
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.fragment_profile_info, container, false)
        textViewStatusText = rootView.findViewById(R.id.text_view_status_text)
        textViewDescriptionText = rootView.findViewById(R.id.text_view_description_text)
        textViewRadiusText = rootView.findViewById(R.id.text_view_radius_text)
        val layoutStatus: ConstraintLayout = rootView.findViewById(R.id.layout_status)
        layoutStatus.setOnClickListener { view: View? ->
            val intentStartUserStatusActivity = Intent(context, EditUserStatusActivity::class.java)
            intentStartUserStatusActivity.putExtra("activity_title", "Статус")
            //startActivityForResult(intentStartUserStatusActivity, EDIT_USER_STATUS_INFO_REQUEST_CODE)
            activityResultEditUserStatusActivity.launch(intentStartUserStatusActivity)
        }
        val layoutDescription: ConstraintLayout = rootView.findViewById(R.id.layout_description)
        layoutDescription.setOnClickListener { view: View? ->
            val intentStartUserStatusActivity = Intent(context, EditUserStatusActivity::class.java)
            intentStartUserStatusActivity.putExtra("activity_title", "Описание")
            startActivityForResult(intentStartUserStatusActivity, EDIT_USER_DESCRIPTION_INFO_REQUEST_CODE)
        }
        val layoutRadius: ConstraintLayout = rootView.findViewById(R.id.layout_radius)
        layoutRadius.setOnClickListener { view: View? ->
            val intentStartUserStatusActivity = Intent(context, SelectRadiusActivity::class.java)
            intentStartUserStatusActivity.putExtra("current_radius", radiusInMeters)
            startActivityForResult(intentStartUserStatusActivity, SELECT_RADIUS_REQUEST_CODE)
        }
        return rootView
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (data == null) {
            return
        }
        if (requestCode == EDIT_USER_STATUS_INFO_REQUEST_CODE) {
            val statusText = data.getStringExtra("text")
            if (statusText != "") {
                textViewStatusText?.text = statusText
            }
        } else if (requestCode == EDIT_USER_DESCRIPTION_INFO_REQUEST_CODE) {
            val descriptionText = data.getStringExtra("text")
            if (descriptionText != "") {
                textViewDescriptionText?.text = descriptionText
            }
        } else if (requestCode == SELECT_RADIUS_REQUEST_CODE) {
            radiusInMeters = data.getIntExtra("radius_in_meters", 1000)
            val textRadiusInMeters = data.getStringExtra("text_radius_in_meters")
            textViewRadiusText?.text = textRadiusInMeters
        }
    }

    companion object {
        const val EDIT_USER_STATUS_INFO_REQUEST_CODE = 456
        const val EDIT_USER_DESCRIPTION_INFO_REQUEST_CODE = 829
        const val SELECT_RADIUS_REQUEST_CODE = 173
    }
}