package com.hab.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import com.hab.R
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textview.MaterialTextView
import android.widget.RadioButton
import android.widget.CompoundButton
import com.hab.utils.Utils
import com.hab.utils.Utils.SHARED_PREFS_ENABLE_PRIVATE_MESSAGES

class PrivacyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)

        val sharedPreferencesPrivacySettings = getSharedPreferences(Utils.SHARED_PREFS_PRIVACY_SETTINGS, MODE_PRIVATE)
        val editor = sharedPreferencesPrivacySettings.edit()
        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Конфиденциальность"
        val rbAll = findViewById<RadioButton>(R.id.rb_all)
        val rbNobody = findViewById<RadioButton>(R.id.rb_nobody)
        val buttonSave = findViewById<Button>(R.id.button_save)
        val enablePrivateMessages = sharedPreferencesPrivacySettings.getBoolean(SHARED_PREFS_ENABLE_PRIVATE_MESSAGES, true)
        if (enablePrivateMessages) {
            rbAll.isChecked = true
            rbNobody.isChecked = false
        } else {
            rbAll.isChecked = false
            rbNobody.isChecked = true
        }
        rbAll.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                rbNobody.isChecked = false
                editor.putBoolean(SHARED_PREFS_ENABLE_PRIVATE_MESSAGES, true)
            }
        }
        rbNobody.setOnCheckedChangeListener { compoundButton: CompoundButton?, b: Boolean ->
            if (b == true) {
                rbAll.isChecked = false
                editor.putBoolean(SHARED_PREFS_ENABLE_PRIVATE_MESSAGES, false)
            }
        }
        buttonSave.setOnClickListener {
            editor.apply()
            finish()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}