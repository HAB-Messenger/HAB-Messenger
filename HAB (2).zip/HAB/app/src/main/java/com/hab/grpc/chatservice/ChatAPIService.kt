package com.hab.grpc.chatservice

import android.app.Application
import android.util.Log
import com.hab.utils.Utils.GRPC_CHAT_SERVER_ADDRESS
import com.hab.utils.Utils.GRPC_CHAT_SERVER_PORT
import com.hab.app.HabApplication
import io.grpc.*
import io.grpc.android.AndroidChannelBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor
import kotlinx.coroutines.flow.*
import java.io.Closeable
import java.util.concurrent.TimeUnit

class ChatAPIService : Closeable {

    //private val application: HabApplication
    private var channel: ManagedChannel
    private var chatCoroutineStub: ChatGrpcKt.ChatCoroutineStub

    constructor() {
        this.channel = object: ManagedChannel(){
            override fun <RequestT : Any?, ResponseT : Any?>
            newCall(methodDescriptor: MethodDescriptor<RequestT, ResponseT>?, callOptions: CallOptions?): ClientCall<RequestT, ResponseT>?
            {
                return null
            }

            override fun authority(): String {
                return ""
            }

            override fun shutdown(): ManagedChannel? {
                return null
            }

            override fun isShutdown(): Boolean {
                return false
            }

            override fun isTerminated(): Boolean {
                return false
            }

            override fun shutdownNow(): ManagedChannel? {
                return null
            }

            override fun awaitTermination(timeout: Long, unit: TimeUnit?): Boolean {
                return false
            }
        }

        this.chatCoroutineStub = ChatGrpcKt.ChatCoroutineStub(channel)
    }

    constructor(application: Application) {
        //this.application = application as HabApplication
        this.channel = AndroidChannelBuilder
                .forAddress(GRPC_CHAT_SERVER_ADDRESS, GRPC_CHAT_SERVER_PORT)
                .usePlaintext()
                .executor(Dispatchers.Default.asExecutor())
                .keepAliveWithoutCalls(true)
                .keepAliveTimeout(30, TimeUnit.SECONDS)
                .build()
        this.chatCoroutineStub = ChatGrpcKt.ChatCoroutineStub(channel)
    }

    private fun reconnectIfTerminated() {
        if (channel.isTerminated || channel.isShutdown) {
            this.channel = AndroidChannelBuilder
                    .forAddress(GRPC_CHAT_SERVER_ADDRESS, GRPC_CHAT_SERVER_PORT)
                    .usePlaintext()
                    .executor(Dispatchers.Default.asExecutor())
                    .keepAliveWithoutCalls(true)
                    .keepAliveTimeout(30, TimeUnit.SECONDS)
                    .build()
            this.chatCoroutineStub = ChatGrpcKt.ChatCoroutineStub(this.channel)
        }
    }

    private fun reconnectNewPeerIfTerminated(userId: String) {
        if (channel.isTerminated || channel.isShutdown) {
            newPeer(userId)
        }
    }

    fun newPeer(userId: String): Flow<NewPeerResponse> {
        reconnectIfTerminated()
        val newPeerRequest = NewPeerRequest.newBuilder()
                .setUserId(userId)
                .build()
        val newPeerResponse = chatCoroutineStub.newPeer(newPeerRequest)
        return newPeerResponse
    }

    fun searchingPeer(userId: String, lat: Double, lng: Double, visibleInRadius: Int,
                      status: String, statusColorId: Int, userName: String, description: String,
                      isSearching: Boolean, gender: String, age: Int, searchingGender: String,
                    searchingMinAge: Int, searchingMaxAge: Int,
                      city: String, searchingCity: String): Flow<SearchingPeerResponse>
    {
        //val chatCoroutineStub = ChatGrpcKt.ChatCoroutineStub(channel)
        val searchingPeerRequest = SearchingPeerRequest.newBuilder()
                .setUserId(userId)
                .setVisibleInRadiusInMeters(visibleInRadius)
                .setLatitude(lat)
                .setLongitude(lng)
                .setStatus(status)
                .setStatusColorId(statusColorId)
                .setUserName(userName)
                .setDescription(description)
                .setIsSearching(isSearching)
                .setGender(gender)
                .setAge(age)
                .setSearchingGender(searchingGender)
                .setSearchingMinAge(searchingMinAge)
                .setSearchingMaxAge(searchingMaxAge)
                .setCity(city)
                .setSearchingCity(searchingCity)
                .build()
        return chatCoroutineStub.searchingPeer(searchingPeerRequest)
    }

    suspend fun newCoordinates(userId: String, lat: Double, lng: Double) {
        val newCoordinatesRequest = NewCoordinatesRequest.newBuilder()
                .setUserId(userId)
                .setLatitude(lat)
                .setLongitude(lng)
                .build()
        chatCoroutineStub.newCoordinates(newCoordinatesRequest)
    }

    fun newMessage(userId: String, messageText: String, toUserId: String): Flow<NewMessageResponse> {
        //val chatCoroutineStub = ChatGrpcKt.ChatCoroutineStub(channel)
        val newMessageRequest = NewMessageRequest.newBuilder()
                .setMessage(messageText)
                .setUserId(userId)
                .setToUserId(toUserId)
                .build()
        return chatCoroutineStub.newMessage(newMessageRequest)
    }

    fun newGroupMessage(userId: String, messageText: String, adminId: String = "", userName: String = "", isAdmin: Boolean): Flow<NewCollectiveMessageResponse> {
        //val chatCoroutineStub = ChatGrpcKt.ChatCoroutineStub(channel)
        val newMessageRequest = NewCollectiveMessageRequest.newBuilder()
                .setMessage(messageText)
                .setUserId(userId)
                .setAdminId(adminId)
                .setUserName(userName)
                .setIsAdmin(isAdmin)
                .build()
        return chatCoroutineStub.newGroupMessage(newMessageRequest)
    }

    fun typingMessage(userId: String, toUserId: String = ""): Flow<TypingMessageResponse> {
        val typingMessageRequest = TypingMessageRequest.newBuilder()
                .setUserId(userId)
                .setToUserId(toUserId)
                .build()
        return chatCoroutineStub.typingMessage(typingMessageRequest)
    }

    fun typingGroupMessage(userId: String, toUserId: String = ""): Flow<TypingMessageResponse> {
        val typingMessageRequest = TypingMessageRequest.newBuilder()
                .setUserId(userId)
                .setToUserId(toUserId)
                .build()
        return chatCoroutineStub.typingGroupMessage(typingMessageRequest)
    }

    fun chatClosed(userId: String, isClosed: Boolean, toUserId: String): Flow<ChatClosedResponse> {
        val chatClosedRequest = ChatClosedRequest.newBuilder()
                .setUserId(userId)
                .setIsClosed(isClosed)
                .setToUserId(toUserId)
                .build()
        return chatCoroutineStub.chatClosed(chatClosedRequest)
    }

    fun groupChatClosed(userId: String, isClosed: Boolean): Flow<CollectiveChatClosedResponse> {
        val collectiveChatClosedRequest = CollectiveChatClosedRequest.newBuilder()
                .setUserId(userId)
                .setIsClosed(isClosed)
                .build()
        return chatCoroutineStub.groupChatClosed(collectiveChatClosedRequest)
    }

    suspend fun peerCLosed(userId: String):Int {
        val peerClosedRequest = PeerClosedRequest.newBuilder()
                .setUserId(userId)
                .build()

        val peerClosedResponse = chatCoroutineStub.peerClosed(peerClosedRequest)
        val responseCode = peerClosedResponse.responseCode
        return responseCode
    }

    suspend fun adminStatus(userId: String, isAdminOn: Boolean):Int {
        val adminStatusRequest = AdminStatusRequest.newBuilder()
                .setUserId(userId)
                .setIsAdminOn(isAdminOn)
                .build()

        val adminStatusResponse = chatCoroutineStub.adminStatus(adminStatusRequest)
        val responseCode = adminStatusResponse.responseCode
        return responseCode
    }

    fun getAdminStatus(userId: String, adminId: String): Flow<GetAdminStatusResponse> {
        val getAdminStatusRequest = GetAdminStatusRequest.newBuilder()
                .setUserId(userId)
                .setAdminId(adminId)
                .build()
        val getAdminStatusResponse = chatCoroutineStub.getAdminStatus(getAdminStatusRequest)
        return getAdminStatusResponse
    }

    fun blockUserInGroupChat(userIdToBlock: String = "", blockingTime: String = "", adminId: String = ""): Flow<BlockUserInCollectiveChatResponse> {
        val blockUserRequest = BlockUserInCollectiveChatRequest.newBuilder()
                .setBlockedUserId(userIdToBlock)
                .setBlockingTime(blockingTime)
                .setAdminId(adminId)
                .build()
        return chatCoroutineStub.blockUserInGroupChat(blockUserRequest)
    }

    fun clearGroupChat(adminId: String = "", clearChat: Boolean = false, userId: String): Flow<ClearCollectiveChatResponse> {
        val clearCollectiveChatRequest = ClearCollectiveChatRequest.newBuilder()
                .setAdminId(adminId)
                .setClearChat(clearChat)
                .setUserId(userId)
                .build()
        return chatCoroutineStub.clearGroupChat(clearCollectiveChatRequest)
    }

    fun blockUserInPersonalChat(userIdToBlock: String = "", userId: String = "", blockingTime: String = ""): Flow<BlockUserInPersonalChatResponse> {
        val blockUserInPersonalChatRequest = BlockUserInPersonalChatRequest.newBuilder()
                .setBlockedUserId(userIdToBlock)
                .setUserId(userId)
                .setBlockingTime(blockingTime)
                .build()
        return chatCoroutineStub.blockUserInPersonalChat(blockUserInPersonalChatRequest)
    }

    fun clearPersonalChat(toUserId: String = "", clearChat: Boolean = false, adminId: String): Flow<ClearPersonalChatResponse> {
        val clearPersonalChatRequest = ClearPersonalChatRequest.newBuilder()
                .setUserId(toUserId)
                .setClearChat(clearChat)
                .setAdminId(adminId)
                .build()
        return chatCoroutineStub.clearPersonalChat(clearPersonalChatRequest)
    }

    suspend fun reportUser(userId: String = "", reportedUserId: String = "", reportUser: Boolean = false, message: String = ""): ReportUserResponse {
        val reportUserRequest = ReportUserRequest.newBuilder()
                .setUserId(userId)
                .setReportedUserId(reportedUserId)
                .setReportUser(reportUser)
                .setMessage(message)
                .build()
        return chatCoroutineStub.reportUser(reportUserRequest)
    }

    suspend fun uploadImage(uploadImageRequest: Flow<UploadImageRequest>): UploadImageResponse {
        return chatCoroutineStub.uploadImage(uploadImageRequest)
    }

    fun downloadImage(userId: String): Flow<DownloadImageResponse> {
        val downloadImageRequest = DownloadImageRequest.newBuilder()
                .setUserId(userId)
                .build()
        return chatCoroutineStub.downloadImage(downloadImageRequest)
    }

    suspend fun removeImage(userId: String): RemoveImageResponse {
        val removeImageRequest = RemoveImageRequest.newBuilder()
                .setUserId(userId)
                .build()
        return chatCoroutineStub.removeImage(removeImageRequest)
    }

    override fun close() {
        this.channel.shutdown().awaitTermination(2, TimeUnit.SECONDS)
    }
}