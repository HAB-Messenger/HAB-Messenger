package com.hab.activities

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView
import com.hab.BuildConfig
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_AGE
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_GENDER
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_NAME
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_SURNAME
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.db.entities.UserDBEntity
import com.hab.services.ChatService
import com.hab.utils.Utils.DEFAULT_CITY
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_CITY
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class PersonalInfoActivity : AppCompatActivity() {

    private var month: Int = 1

    private lateinit var spinnerDay: Spinner
    private lateinit var spinnerMonth: Spinner
    private lateinit var spinnerYear: Spinner
    private lateinit var spinnerCity: Spinner
    private lateinit var imageViewPhoto: ShapeableImageView

    private lateinit var habApp: HabApplication
    private lateinit var sharedPreferencesUserInfo: SharedPreferences

    private val CHANGE_USER_PIC = 23
    private val REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE = 56

    private val requestReadExternalStoragePermissions =  registerForActivityResult(ActivityResultContracts.RequestPermission(), ActivityResultCallback {
        isGranted ->
        if (isGranted) {
            HabApplication.defaultScope.launch {
                val userImageName = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_IMAGE, "")?: ""
                if (userImageName != "") {
                    val imageUri = Uri.parse(userImageName)
                    val imageStream = contentResolver.openInputStream(imageUri)
                    val selectedImage = BitmapFactory.decodeStream(imageStream)
                    imageStream?.close()

                    //val resizedImage = Bitmap.createScaledBitmap(selectedImage, 200, 200, false)
                    //val resizedImage = Bitmap.createBitmap(selectedImage, 0,0,width, height)
                    habApp.uiScope.launch {
                        imageViewPhoto.setImageBitmap(selectedImage)
                    }
                }
            }
        } else {
            Utils.showToast(this, "у приложения нет доступа к файлам!")
        }
    })

    private val startChangeUserPicActivityForResult = registerForActivityResult(StartActivityForResult(), ActivityResultCallback {
        if (it.resultCode == RESULT_OK) {
            HabApplication.defaultScope.launch {
                val userImageName = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_IMAGE, "")
                if (userImageName != "") {
                    val imageUri = Uri.parse(userImageName)
                    if (ActivityCompat.checkSelfPermission(habApp, Manifest.permission.READ_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED) {
                        //ActivityCompat.requestPermissions(this@PersonalInfoActivity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE)
                        requestReadExternalStoragePermissions.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                    } else {
                        grantUriPermission(BuildConfig.APPLICATION_ID, imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        val imageStream = contentResolver.openInputStream(imageUri)
                        val selectedImage = BitmapFactory.decodeStream(imageStream)
                        //val resizedImage = Bitmap.createScaledBitmap(selectedImage, 200, 200, true)
                        habApp.uiScope.launch {
                            imageViewPhoto.setImageBitmap(selectedImage)
                        }
                    }
                } else {
                    habApp.uiScope.launch {
                        imageViewPhoto.setImageResource(R.drawable.photo_stub)
                    }
                }
            }
        }
    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_personal_info)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Учётные данные"
        imageViewPhoto = findViewById(R.id.image_view_photo)

        habApp = application as HabApplication
        sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        val userId = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""
        val db = HabDB.getDatabase(habApp)
        val userDAO = db.userDAO()

        val editTextName = findViewById<EditText>(R.id.edit_text_name)
        val editTextSurname = findViewById<EditText>(R.id.edit_text_surname)
        val rgGender = findViewById<RadioGroup>(R.id.rg_gender)
        spinnerDay = findViewById(R.id.spinner_day)
        spinnerMonth = findViewById(R.id.spinner_month)
        spinnerYear = findViewById(R.id.spinner_year)
        spinnerCity = findViewById(R.id.spinner_city)
        val imageViewOpenSpinnerDay = findViewById<ImageView>(R.id.image_view_open_spinner_day)
        val imageViewOpenSpinnerMonth = findViewById<ImageView>(R.id.image_view_open_spinner_month)
        val imageViewOpenSpinnerYear = findViewById<ImageView>(R.id.image_view_open_spinner_year)
        val imageViewOpenSpinnerCity = findViewById<ImageView>(R.id.image_view_open_spinner_city)
        val buttonSave = findViewById<Button>(R.id.button_save)
        imageViewPhoto.setOnClickListener { view: View? ->
            val intentChangeUserPicActivity = Intent(this, ChangeUserPicActivity::class.java)
            //startActivityForResult(intentChangeUserPicActivity, CHANGE_USER_PIC)
            startChangeUserPicActivityForResult.launch(intentChangeUserPicActivity)
        }
        imageViewOpenSpinnerDay.setOnClickListener { view: View? -> spinnerDay.performClick() }
        imageViewOpenSpinnerMonth.setOnClickListener { view: View? -> spinnerMonth.performClick() }
        imageViewOpenSpinnerYear.setOnClickListener { view: View? -> spinnerYear.performClick() }
        imageViewOpenSpinnerCity.setOnClickListener { view: View? -> spinnerCity.performClick() }
        val daysList: MutableList<Int> = ArrayList()
        for (i in 1..31) {
            daysList.add(i)
        }
        val spinnerDayArrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, daysList)
        spinnerDay.setAdapter(spinnerDayArrayAdapter)
        val yearsList: MutableList<Int> = ArrayList()
        for (i in 1970..2003) {
            yearsList.add(i)
        }
        spinnerMonth.setOnItemSelectedListener(object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                month = position+1
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
        val spinnerArrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, yearsList)
        spinnerYear.setAdapter(spinnerArrayAdapter)

        val citiesList: MutableList<String> = ArrayList()
        citiesList.addAll(resources.getStringArray(R.array.cities))
        val spinnerCitiesArrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, citiesList)
        spinnerCity.adapter = spinnerCitiesArrayAdapter

        var name = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_NAME, "")?:""
        var surname = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_SURNAME, "")
        var gender = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_GENDER, "")
        var city = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_CITY, DEFAULT_CITY)
        citiesList.forEachIndexed { index, item ->
            if (city == item) {
                spinnerCity.setSelection(index)
            }
        }

        editTextName.setText(name)
        editTextSurname.setText(surname)
        when(gender) {
            Utils.GENDER_FEMALE -> {
                rgGender.check(R.id.rb_female)
            }
            Utils.GENDER_MALE -> {
                rgGender.check(R.id.rb_male)
            }
        }

        HabApplication.ioScope.launch {
            val userInfo = userDAO.getUserByUserId(userId)
            val day = userInfo?.userBirthDay?:1
            val month = (userInfo?.userBirthMonth?:1)-1
            val year = (userInfo?.userBirthYear?:1970)

            habApp.uiScope.launch {
                daysList.forEachIndexed { index, item ->
                    if (day == item) {
                        spinnerDay.setSelection(index)
                    }
                }
                spinnerMonth.setSelection(month)

                yearsList.forEachIndexed { index, item ->
                    if (item == year) {
                        spinnerYear.setSelection(index)
                    }
                }
            }
        }

        buttonSave.setOnClickListener { view: View? ->
            name = editTextName.text.toString()
            surname = editTextSurname.text.toString()
            gender = Utils.GENDER_MALE
            val radioButtonID = rgGender.getCheckedRadioButtonId()
            val radioButton = rgGender.findViewById<RadioButton>(radioButtonID)
            val indexOfRadioButtonGender = rgGender.indexOfChild(radioButton)
            if (indexOfRadioButtonGender == 1) {
                gender = Utils.GENDER_FEMALE
            }
            val birthDate = "${spinnerDay.selectedItem}/${month}/${spinnerYear.selectedItem}"
            val year = spinnerYear.selectedItem as Int
            val day = spinnerDay.selectedItem as Int
            //val age = Period.between(LocalDate.of(year, month, day), LocalDate.now()).getYears()
            val dateFormat = SimpleDateFormat("dd/MM/yyyy")
            val currentCalendar = Calendar.getInstance()
            currentCalendar.timeInMillis = System.currentTimeMillis()
            val birthCalendar = Calendar.getInstance()
            birthCalendar.setTime(dateFormat.parse(birthDate))
            val age = currentCalendar.get(Calendar.YEAR) - birthCalendar.get(Calendar.YEAR)

            city = spinnerCity.selectedItem as String

            if (name != "") {
                if (indexOfRadioButtonGender != -1) {

                    HabApplication.ioScope.launch {
                        val userPrefsEditor = sharedPreferencesUserInfo.edit()
                        userPrefsEditor.putString(SHARED_PREFS_KEY_USER_NAME, name)
                        userPrefsEditor.putString(SHARED_PREFS_KEY_USER_SURNAME, surname)
                        userPrefsEditor.putString(SHARED_PREFS_KEY_USER_GENDER, gender)
                        userPrefsEditor.putInt(SHARED_PREFS_KEY_USER_AGE, age)
                        userPrefsEditor.putString(SHARED_PREFS_KEY_USER_CITY, city)
                        userPrefsEditor.apply()

                        var userEntity = userDAO.getUserByUserId(userId)
                        if (userEntity == null) {
                            userEntity = UserDBEntity()
                        }

                        userEntity.userId = userId
                        userEntity.userName = name
                        userEntity.userSurname = surname
                        userEntity.userGender = gender
                        userEntity.userBirthDate = birthDate
                        userEntity.userBirthDay = day
                        userEntity.userBirthMonth = month
                        userEntity.userBirthYear = year

                        userDAO.insert(userEntity)
                        habApp.uiScope.launch {
                            finish()
                        }
                    }
                }
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    /*@SuppressLint("MissingPermission")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when(requestCode) {
            REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE -> {
                if (Utils.hasAllPermissionsGranted(grantResults)) {
                    HabApplication.defaultScope.launch {
                        val userImageName = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_IMAGE, "")?: ""
                        if (userImageName != "") {
                            val imageUri = Uri.parse(userImageName)
                            val imageStream = contentResolver.openInputStream(imageUri)
                            val selectedImage = BitmapFactory.decodeStream(imageStream)
                            imageStream?.close()

                            //val resizedImage = Bitmap.createScaledBitmap(selectedImage, 200, 200, false)
                            //val resizedImage = Bitmap.createBitmap(selectedImage, 0,0,width, height)
                            habApp.uiScope.launch {
                                imageViewPhoto.setImageBitmap(selectedImage)
                            }
                        }
                    }
                } else {
                    Utils.showToast(this, "Приложение нет доступа к файлам!")
                }
            }
            else -> {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }
    }*/

    /*override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        when (requestCode) {
            CHANGE_USER_PIC -> {
                if (resultCode == RESULT_OK) {
                    HabApplication.defaultScope.launch {
                        val userImageName = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_IMAGE, "")
                        if (userImageName != "") {
                            val imageUri = Uri.parse(userImageName)
                            if (ActivityCompat.checkSelfPermission(habApp, Manifest.permission.READ_EXTERNAL_STORAGE)
                                    != PackageManager.PERMISSION_GRANTED) {
                                ActivityCompat.requestPermissions(this@PersonalInfoActivity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                                        REQUEST_PERMISSIONS_READ_EXTERNAL_STORAGE)
                            } else {
                                grantUriPermission(BuildConfig.APPLICATION_ID, imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                val imageStream = contentResolver.openInputStream(imageUri)
                                val selectedImage = BitmapFactory.decodeStream(imageStream)
                                //val resizedImage = Bitmap.createScaledBitmap(selectedImage, 200, 200, true)
                                habApp.uiScope.launch {
                                    imageViewPhoto.setImageBitmap(selectedImage)
                                }
                            }
                        } else {
                            habApp.uiScope.launch {
                                imageViewPhoto.setImageResource(R.drawable.photo_stub)
                            }
                        }
                    }
                }
            }
            else -> {
                super.onActivityResult(requestCode, resultCode, data)
            }
        }
    }*/
}