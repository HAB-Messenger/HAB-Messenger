package com.hab.activities

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils
import com.hab.app.HabApplication
import com.hab.services.ChatService
import kotlinx.coroutines.launch

class ReportUserActivity : AppCompatActivity() {
    lateinit var habApp: HabApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report_user)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        val editTextProblem = findViewById<EditText>(R.id.edit_text_problem)
        val textViewNumberOfChars = findViewById<TextView>(R.id.text_view_number_of_chars)
        val buttonSend = findViewById<Button>(R.id.button_send)

        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)

        habApp = application as HabApplication

        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Опишите проблему"

        editTextProblem.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}
            override fun afterTextChanged(editable: Editable) {
                val len = editTextProblem.text.length
                textViewNumberOfChars.text = "$len/150"
            }
        })

        buttonSend.setOnClickListener { view: View? ->
            val textProblem = editTextProblem.text.toString()
            HabApplication.ioScope.launch {
                habApp.chatAPIService.reportUser("userId", "reportedUserId", true, textProblem)
                habApp.uiScope.launch {
                    Utils.showToast(habApp, "Жалоба отправлена")
                }
            }
            finish()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}