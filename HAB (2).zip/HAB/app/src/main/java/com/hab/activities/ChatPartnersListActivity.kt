package com.hab.activities

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.textview.MaterialTextView
import com.hab.R
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.adapters.ChatPartnersRecyclerViewAdapter
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.db.HabDB.Companion.getDatabase
import com.hab.db.dao.MessageDAO
import com.hab.db.dao.UserDAO
import com.hab.listeners.RemovePersonalChatListener
import com.hab.pojo.ChatPartner
import com.hab.services.ChatService
import com.hab.services.PushNotificationsService
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*

class ChatPartnersListActivity : AppCompatActivity() {

    private lateinit var habApp: HabApplication
    private val chatPartnerList: MutableList<ChatPartner> = ArrayList()
    private var chatPartnersRecyclerViewAdapter: ChatPartnersRecyclerViewAdapter? = null
    private lateinit var newMessagesInBottomNav: RelativeLayout
    private lateinit var itemsCountLabelInBottomNav: TextView
    private lateinit var userDAO: UserDAO
    private lateinit var messageDAO: MessageDAO
    private var userId = ""
    private var pushnotificationJob: Job? = null
    private lateinit var recyclerViewChatPartners:RecyclerView
    private var removePersonalChatListener: RemovePersonalChatListener = object: RemovePersonalChatListener {
        override fun removePersonalChat(positionIndexInChatPartnerList: Int) {
            val peer = chatPartnerList[positionIndexInChatPartnerList]
            chatPartnerList.removeAt(positionIndexInChatPartnerList)
            chatPartnersRecyclerViewAdapter?.notifyDataSetChanged()

            var totalCountUnreadMessages = itemsCountLabelInBottomNav.text.toString().toInt()
            totalCountUnreadMessages -= peer.unreadMessagesCount
            itemsCountLabelInBottomNav.text = "${totalCountUnreadMessages}"
            if (totalCountUnreadMessages == 0) {
                newMessagesInBottomNav.visibility = View.GONE
            }
            // remove messages from db
            val peerId = peer.id
            HabApplication.ioScope.launch {
                // remove messages from db.messages
                val id = userDAO.getUserByUserId(userId).id
                val to_id = userDAO.getUserByUserId(peerId).id
                messageDAO.deleteAll(id, to_id)
                messageDAO.deleteAll(to_id, id)

                habApp.chatAPIService.clearPersonalChat(peerId, true, userId)
                        .catch { e->
                            //todo: process error
                        }.collect()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_partners_list)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setHomeAsUpIndicator(R.drawable.ic_back)

        habApp = application as HabApplication

        val sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        userId = sharedPreferencesUserInfo.getString(SHARED_PREFS_KEY_USER_ID, "")?:""

        val textAppName = findViewById<MaterialTextView>(R.id.text_app_name)
        textAppName.text = "Сообщения"
        recyclerViewChatPartners = findViewById<RecyclerView>(R.id.recycler_view_chat_partners)
        val imageViewProfile = findViewById<ImageView>(R.id.image_view_profile)
        val imageViewInRadius = findViewById<ImageView>(R.id.image_view_in_radius)
        val imageViewChat = findViewById<ImageView>(R.id.image_view_chat)
        val imageViewSettings = findViewById<ImageView>(R.id.image_view_settings)
        newMessagesInBottomNav = findViewById(R.id.new_messages_in_bottom_nav)
        itemsCountLabelInBottomNav = findViewById(R.id.items_count_label_in_bottom_nav)

        imageViewProfile.setImageResource(R.drawable.ic_profile_not_selected)
        imageViewChat.setImageResource(R.drawable.ic_chat_selected)
        recyclerViewChatPartners.layoutManager = LinearLayoutManager(this)
        val db = getDatabase(applicationContext)
        userDAO = db.userDAO()
        messageDAO = db.messageDAO()

        /*for (int i=0; i<25;i++) {
            ChatPartner chatPartner = new ChatPartner();
            chatPartner.setName("User"+ i);
            chatPartner.setLastMessage("This is the "+ i +" last msg");
            chatPartnerList.add(chatPartner);
        }*/
        imageViewProfile.setOnClickListener { view: View? ->
            val intentProfileActivity = Intent(this@ChatPartnersListActivity, ProfileActivity::class.java)
            startActivity(intentProfileActivity)
            finish()
        }
        imageViewInRadius.setOnClickListener { view: View? ->
            val intentSearchInRadiusActivityActivity = Intent(this@ChatPartnersListActivity, SearchInRadiusActivity::class.java)
            startActivity(intentSearchInRadiusActivityActivity)
            finish()
        }
        imageViewSettings.setOnClickListener { view: View? ->
            val intentSettingsActivity = Intent(this@ChatPartnersListActivity, SettingsActivity::class.java)
            startActivity(intentSettingsActivity)
        }
    }

    override fun onStart() {
        super.onStart()

        // for total count of unread messages from all users
        HabApplication.ioScope.launch {
            //val db = HabDB.getDatabase(applicationContext)
            //val usersDAO = db.userDAO()
            //val messagesDAO = db.messageDAO()
            val id = userDAO.getUserByUserId(userId).id
            val unreadMessages = messageDAO.getUnreadMessages(id)
            val messageCount: Int = unreadMessages.size
            habApp.uiScope.launch {
                if (messageCount > 0) {
                    newMessagesInBottomNav.visibility = View.VISIBLE
                    itemsCountLabelInBottomNav.setText("$messageCount")
                } else {
                    itemsCountLabelInBottomNav.setText("0")
                    newMessagesInBottomNav.visibility = View.GONE
                }
            }
        }

        HabApplication.ioScope.launch {
            updateChatPartnerList()
            habApp.uiScope.launch {
                chatPartnersRecyclerViewAdapter = ChatPartnersRecyclerViewAdapter(habApp, chatPartnerList, removePersonalChatListener)
                recyclerViewChatPartners.adapter = chatPartnersRecyclerViewAdapter
            }
        }

        pushnotificationJob = HabApplication.defaultScope.launch {
            PushNotificationsService.pushNotificationsFlow.onEach {
                for (chatPartner in chatPartnerList) {
                    if (chatPartner.id == it.fromUserId) {
                        chatPartner.lastMessage = it.message
                        chatPartner.unreadMessagesCount += 1
                        break
                    }
                }
                updateChatPartnerList()
                habApp.uiScope.launch {
                    chatPartnersRecyclerViewAdapter?.notifyDataSetChanged()
                }

                // for total count of unread messages from all users
                val db = HabDB.getDatabase(applicationContext)
                val usersDAO = db.userDAO()
                val messagesDAO = db.messageDAO()
                val id = usersDAO.getUserByUserId(userId).id
                val unreadMessages = messagesDAO.getUnreadMessages(id)
                val messageCount: Int = unreadMessages.size
                //val messageCount: Int = PushNotificationsService.messageCounter.get()
                habApp.uiScope.launch {
                    if (messageCount > 0) {
                        newMessagesInBottomNav.visibility = View.VISIBLE
                        itemsCountLabelInBottomNav.setText("$messageCount")
                    } else {
                        itemsCountLabelInBottomNav.setText("0")
                        newMessagesInBottomNav.visibility = View.GONE
                    }
                }
            }.onEmpty {

            }.catch { e ->
                //todo:
            }.collect()
        }
    }

    fun updateChatPartnerList() {
        val id = userDAO.getUserByUserId(userId).id
        for (userEntity in userDAO.users) {
            if (userEntity.userId != userId) {
                val unreadMessages = messageDAO.getUnreadMessages(id, userEntity.id)
                val unreadMessagesCount = unreadMessages.size
                if (unreadMessagesCount > 0) {
                    val lastMessage = unreadMessages[unreadMessagesCount-1].message
                    var chatPartnerExists = false
                    chatPartnerList.forEach { chatPartner ->
                        if (chatPartner.id == userEntity.userId) {
                            chatPartnerExists = true
                            chatPartner.lastMessage = lastMessage
                            chatPartner.unreadMessagesCount = unreadMessagesCount
                        }
                    }
                    if (chatPartnerExists == false) {
                        val newChatPartner = ChatPartner(userEntity.userId, userEntity.userName, lastMessage, unreadMessagesCount)
                        chatPartnerList.add(newChatPartner)
                    }
                } else {
                    val lastMessageEntity = messageDAO.getLastMessage(userEntity.id)
                    if (lastMessageEntity != null) {
                        val lastMessage = lastMessageEntity.message
                        var chatPartnerExists = false
                        chatPartnerList.forEach { chatPartner ->
                            if (chatPartner.id == userEntity.userId) {
                                chatPartnerExists = true
                                chatPartner.lastMessage = lastMessage
                                chatPartner.unreadMessagesCount = unreadMessagesCount
                            }
                        }
                        if (chatPartnerExists == false) {
                            val newChatPartner = ChatPartner(userEntity.userId, userEntity.userName, lastMessage, unreadMessagesCount)
                            chatPartnerList.add(newChatPartner)
                        }
                    }
                }
            }
        }
    }

    override fun onStop() {
        pushnotificationJob?.cancel("")
        super.onStop()
    }

    override fun onResume() {
        super.onResume()

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}