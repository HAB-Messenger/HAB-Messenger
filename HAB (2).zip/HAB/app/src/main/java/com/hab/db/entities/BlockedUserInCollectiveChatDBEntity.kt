package com.hab.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "blocked_users_in_collective_chat")
class BlockedUserInCollectiveChatDBEntity {
    @PrimaryKey(autoGenerate = true)
    var id = 0

    @ColumnInfo(name = "blocked_user_id")
    var blockedUserId = 0 //id from users table

    @ColumnInfo(name = "admin_id")
    var adminId = 0 //id from users table

    @ColumnInfo(name = "blocked_until")
    var blockedUntilInMillis:Long = 0// unix timestamp in milliseconds
}