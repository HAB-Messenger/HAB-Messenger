/**
 * Copyright (C) 2018 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hab.activities

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hab.R
import com.hab.adapters.play_billing.SkuDetailsAdapter
import com.hab.db.entities.play_billing.AugmentedSkuDetails
import com.hab.viewmodels.BillingViewModel

class MakePurchaseActivity : AppCompatActivity() {

    private lateinit var billingViewModel: BillingViewModel
    private lateinit var subsInventoryRecyclerView: RecyclerView
    private var entitled: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_make_purchase)

        val view = findViewById<View>(R.id.make_purchase_layout)
        subsInventoryRecyclerView = findViewById(R.id.subs_inventory)

        val subsAdapter = object : SkuDetailsAdapter() {
            override fun onSkuDetailsClicked(item: AugmentedSkuDetails) {
                onPurchase(view, item)
            }
        }

        attachAdapterToRecyclerView(subsInventoryRecyclerView, subsAdapter)

        billingViewModel = ViewModelProvider(this).get(BillingViewModel::class.java)
        billingViewModel.subsSkuDetailsListLiveData.observe(this, Observer {
            it?.let { subsAdapter.setSkuDetailsList(it) }
        })

        billingViewModel.statusColorLiveData.observe(this, Observer {
            it?.apply {
                this@MakePurchaseActivity.entitled = entitled
                checkStatusColorSubscription()
            }
        })
    }

    private fun checkStatusColorSubscription() {
        if (entitled) {
            finish()
        }
    }

    private fun attachAdapterToRecyclerView(recyclerView: RecyclerView, skuAdapter: SkuDetailsAdapter) {
        with(recyclerView) {
            layoutManager = LinearLayoutManager(context)
            adapter = skuAdapter
        }
    }

    private fun onPurchase(view: View, item: AugmentedSkuDetails) {
        billingViewModel.makePurchase(this, item)
        //Log.d(LOG_TAG, "starting purchase flow for SkuDetail:\n ${item}")
    }
}