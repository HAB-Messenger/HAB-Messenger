package com.hab.pojo

data class Message (var text: String, var isFromPartner:Boolean = false, var userId: String="", var userName: String="")