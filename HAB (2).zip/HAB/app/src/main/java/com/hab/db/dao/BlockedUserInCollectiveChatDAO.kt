package com.hab.db.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.hab.db.entities.BlockedUserInCollectiveChatDBEntity

@Dao
interface BlockedUserInCollectiveChatDAO {
    @Insert
    fun insert(blockedUserInCollectiveChatDBEntity: BlockedUserInCollectiveChatDBEntity?)

    @Query("SELECT * FROM blocked_users_in_collective_chat WHERE blocked_user_id = :userID AND admin_id = :adminId")
    fun getBlockedUserByUserId(userID: Int, adminId: Int): BlockedUserInCollectiveChatDBEntity?

    @Delete
    fun delete(user: BlockedUserInCollectiveChatDBEntity)
}