package com.hab.pojo

import com.hab.utils.Utils.STATUS_COLOR_WHITE

class PersonInRadius {
    var id: String? = null
    var name: String? = null
    var imageName: String? = null
    var status: String? = null
    var description: String? = null
    var radiusDistanceInMeters = 0
    var isOnline = false
    var isAdminOn = false
    var statusColorId = STATUS_COLOR_WHITE
    var city: String = ""
}