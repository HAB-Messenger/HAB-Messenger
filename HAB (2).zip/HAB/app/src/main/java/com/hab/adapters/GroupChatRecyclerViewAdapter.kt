package com.hab.adapters

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView
import com.hab.R
import com.hab.utils.Utils
import com.hab.app.HabApplication
import com.hab.pojo.Message
import com.hab.services.ChatService
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.io.FileOutputStream

class GroupChatRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private var habApp: HabApplication
    private var messageList: List<Message>

    constructor(habApp: HabApplication, messageList: List<Message>): super() {
        this.habApp = habApp
        this.messageList = messageList
    }

    internal inner class CustomViewHolder : RecyclerView.ViewHolder {
        var imageViewPartnerPhoto: ShapeableImageView
        var imageViewMyPhoto: ShapeableImageView
        var layoutMessageFromMe: ConstraintLayout
        var layoutMessageFromPartner: ConstraintLayout
        var textViewMessageFromMe: TextView
        var textViewMessageFromPartner: TextView
        var textViewPartnerName: TextView

        constructor(itemView: View): super(itemView) {
            imageViewPartnerPhoto = itemView.findViewById(R.id.image_view_partner_photo)
            imageViewMyPhoto = itemView.findViewById(R.id.image_view_my_photo)
            layoutMessageFromMe = itemView.findViewById(R.id.layout_message_from_me)
            layoutMessageFromPartner = itemView.findViewById(R.id.layout_message_from_partner)
            textViewMessageFromMe = itemView.findViewById(R.id.text_view_message_from_me)
            textViewMessageFromPartner = itemView.findViewById(R.id.text_view_message_from_partner)
            textViewPartnerName = itemView.findViewById(R.id.text_view_partner_name)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message_search_in_radius_chat,
                parent, false)
        return CustomViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val customViewHolder = holder as CustomViewHolder
        val message = messageList[position]
        if (message.isFromPartner) {
            customViewHolder.layoutMessageFromPartner.visibility = View.VISIBLE
            customViewHolder.layoutMessageFromMe.visibility = View.INVISIBLE
            customViewHolder.textViewMessageFromPartner.text = message.text
            customViewHolder.textViewPartnerName.text = message.userName

            val imageFileName = "${habApp.filesDir.absolutePath}/${message.userId}"
            val imageUri = Uri.parse(imageFileName)
            val imageDrawable = Drawable.createFromPath(imageUri.path)
            if (imageDrawable != null) {
                customViewHolder.imageViewPartnerPhoto.setImageDrawable(imageDrawable)
            } else {
                HabApplication.ioScope.launch {
                    try {
                        var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                        val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(message.userId)

                        downloadImageResponseFlow.onEach { downloadImageResponse ->
                            val responseCode = downloadImageResponse.responseCode
                            when (responseCode) {
                                1 -> {//keep reading file
                                    val buffer = downloadImageResponse.fileChunk.toByteArray()
                                    fileImageStream?.write(buffer)
                                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                                }
                                2 -> {//End of file reached
                                    fileImageStream?.flush()
                                    fileImageStream?.close()
                                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                                    val imageUri = Uri.parse(imageFileName)
                                    val imageDrawable = Drawable.createFromPath(imageUri.path)
                                    if (imageDrawable != null) {
                                        habApp.uiScope.launch {
                                            customViewHolder.imageViewPartnerPhoto.setImageDrawable(imageDrawable)
                                        }
                                    } else {
                                        habApp.uiScope.launch {
                                            val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                            customViewHolder.imageViewPartnerPhoto.setImageDrawable(userPhotoStub)
                                        }
                                    }
                                }
                                -1 -> {//error
                                    //todo: error
                                    fileImageStream?.close()
                                    fileImageStream = null
                                    habApp.uiScope.launch {
                                        val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                                        customViewHolder.imageViewPartnerPhoto.setImageDrawable(userPhotoStub)
                                    }
                                }
                            }
                        }.onEmpty {
                            Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                        }.catch { e ->

                        }.collect()
                    } catch (e: FileNotFoundException) {
                        Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
                    }
                }
            }

        } else {
            customViewHolder.layoutMessageFromMe.visibility = View.VISIBLE
            customViewHolder.layoutMessageFromPartner.visibility = View.INVISIBLE
            customViewHolder.textViewMessageFromMe.text = message.text

            val imageFileName = "${habApp.filesDir.absolutePath}/${message.userId}"
            val imageUri = Uri.parse(imageFileName)
            val imageDrawable = Drawable.createFromPath(imageUri.path)
            if (imageDrawable != null) {
                customViewHolder.imageViewMyPhoto.setImageDrawable(imageDrawable)
            } else {
                val sharedPreferencesUserInfo = habApp.getSharedPreferences(Utils.SHARED_PREFS_USER_INFO, AppCompatActivity.MODE_PRIVATE)
                val userImageName = sharedPreferencesUserInfo.getString(Utils.SHARED_PREFS_KEY_USER_IMAGE, "")?: ""
                if (userImageName != "") {
                    val imageUri = Uri.parse(userImageName)
                    val imageStream = habApp.contentResolver.openInputStream(imageUri)
                    val selectedImage = BitmapFactory.decodeStream(imageStream)
                    imageStream?.close()

                    val resizedImage = Bitmap.createScaledBitmap(selectedImage, 200, 200, false)
                    //val resizedImage = Bitmap.createBitmap(selectedImage, 0,0,width, height)

                    customViewHolder.imageViewMyPhoto.setImageBitmap(resizedImage)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return messageList.size
    }
}