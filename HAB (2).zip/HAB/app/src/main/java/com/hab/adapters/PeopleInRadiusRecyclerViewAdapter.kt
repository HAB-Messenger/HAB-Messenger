package com.hab.adapters

import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.shape.CornerFamily
import com.hab.R
import com.hab.activities.ProfileFromSearchInRadiusActivity
import com.hab.activities.ReportUserActivity
import com.hab.app.HabApplication
import com.hab.pojo.PersonInRadius
import com.hab.services.ChatService
import com.hab.utils.Utils
import com.hab.utils.Utils.STATUS_COLOR_BLUE
import com.hab.utils.Utils.STATUS_COLOR_GRAY
import com.hab.utils.Utils.STATUS_COLOR_GREEN
import com.hab.utils.Utils.STATUS_COLOR_LILAC
import com.hab.utils.Utils.STATUS_COLOR_ORANGE
import com.hab.utils.Utils.STATUS_COLOR_RED
import com.hab.utils.Utils.STATUS_COLOR_WHITE
import com.hab.utils.Utils.STATUS_COLOR_YELLOW
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.launch
import java.io.FileNotFoundException
import java.io.FileOutputStream

class PeopleInRadiusRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private var habApp: HabApplication
    private var personInRadiusList: List<PersonInRadius>

    constructor(habApp: HabApplication, personInRadiusList: List<PersonInRadius>): super() {
        this.habApp = habApp
        this.personInRadiusList = personInRadiusList
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_person_in_radius, parent, false)
        return CustomViewHolder(view as ConstraintLayout)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val customViewHolder = holder as CustomViewHolder

        if (personInRadiusList.size > 0) {
            val personInRadius = personInRadiusList[position]
            customViewHolder.textViewStatus.text = personInRadius.status
            customViewHolder.toUserId = personInRadius.id
            customViewHolder.toUserName = personInRadius.name
            customViewHolder.toUserStatus = personInRadius.status
            customViewHolder.toUserDescription = personInRadius.description
            customViewHolder.toUserRadiusSearchDistance = personInRadius.radiusDistanceInMeters
            customViewHolder.isAdminOn = personInRadius.isAdminOn
            customViewHolder.city = personInRadius.city

            if (personInRadius.imageName != null) {
                var imageUri = Uri.parse(personInRadius.imageName)
                val imagePath = imageUri.path
                var imageDrawable = Drawable.createFromPath(imagePath)
                /*if (imagePath == "/drawable/launcher_icon") {
                    imageDrawable = ContextCompat.getDrawable(habApp, R.drawable.launcher_icon)
                }*/
                if (imageDrawable != null) {
                    customViewHolder.imageViewPersonPhoto.setImageDrawable(imageDrawable)
                } else {
                    //val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                    //customViewHolder.imageViewPersonPhoto.setImageDrawable(userPhotoStub)
                    val userId = personInRadius.id?:""
                    if (userId != "") {
                        val imageFileName = "${habApp.filesDir.absolutePath}/${userId}"
                        imageUri = Uri.parse(imageFileName)
                        imageDrawable = Drawable.createFromPath(imageUri.path)
                        if (imageDrawable != null) {
                            customViewHolder.imageViewPersonPhoto.setImageDrawable(imageDrawable)
                        } else {
                            downloadImage(userId, imageFileName, customViewHolder.imageViewPersonPhoto)
                        }
                    }
                }
            } else {
                //val userPhotoStub = ResourcesCompat.getDrawable(habApp.resources, R.drawable.user_photo_stub, null)
                //customViewHolder.imageViewPersonPhoto.setImageDrawable(userPhotoStub)
                val userId = personInRadius.id?:""
                if (userId != "") {
                    val imageFileName = "${habApp.filesDir.absolutePath}/${userId}"
                    val imageUri = Uri.parse(imageFileName)
                    val imageDrawable = Drawable.createFromPath(imageUri.path)
                    if (imageDrawable != null) {
                        customViewHolder.imageViewPersonPhoto.setImageDrawable(imageDrawable)
                    } else {
                        downloadImage(userId, imageFileName, customViewHolder.imageViewPersonPhoto)
                    }
                }
            }
            when (personInRadius.statusColorId) {
                STATUS_COLOR_GREEN -> {
                    customViewHolder.statusBackgroundLayout.setBackgroundResource(R.drawable.ic_person_status_online_green)
                }
                STATUS_COLOR_RED -> {
                    customViewHolder.statusBackgroundLayout.setBackgroundResource(R.drawable.ic_person_status_online_red)
                }
                STATUS_COLOR_ORANGE -> {
                    customViewHolder.statusBackgroundLayout.setBackgroundResource(R.drawable.ic_person_status_online_orange)
                }
                STATUS_COLOR_LILAC -> {
                    customViewHolder.statusBackgroundLayout.setBackgroundResource(R.drawable.ic_person_status_online_lilac)
                }
                STATUS_COLOR_BLUE -> {
                    customViewHolder.statusBackgroundLayout.setBackgroundResource(R.drawable.ic_person_status_online_blue)
                }
                STATUS_COLOR_YELLOW -> {
                    customViewHolder.statusBackgroundLayout.setBackgroundResource(R.drawable.ic_person_status_online_yellow)
                }
                STATUS_COLOR_GRAY -> {
                    customViewHolder.statusBackgroundLayout.setBackgroundResource(R.drawable.ic_person_status_online_gray)
                }
                STATUS_COLOR_WHITE -> {
                    customViewHolder.statusBackgroundLayout.setBackgroundResource(R.drawable.ic_person_status_online_white)
                }
            }
            if (personInRadius.statusColorId == STATUS_COLOR_WHITE) {
                customViewHolder.textViewStatus.setTextColor(Color.BLACK)
            } else {
                customViewHolder.textViewStatus.setTextColor(Color.WHITE)
            }
            /*try {
                val imageStream: InputStream? = contentResolver.openInputStream(imageUri)
                val selectedImage = BitmapFactory.decodeStream(imageStream)
                customViewHolder.imageViewPersonPhoto.setImageBitmap(selectedImage)
            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            }*/

            customViewHolder.layout.visibility = View.VISIBLE
        } else {
            customViewHolder.layout.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return personInRadiusList.size
    }

    private fun downloadImage(userId: String, imageFileName: String, imageViewPersonPhoto: ImageView) {

        HabApplication.ioScope.launch {
            // download image of searching peer
            try {
                var fileImageStream: FileOutputStream? = FileOutputStream(imageFileName)
                val downloadImageResponseFlow = habApp.chatAPIService.downloadImage(userId)

                downloadImageResponseFlow.onEach { downloadImageResponse ->
                    val responseCode = downloadImageResponse.responseCode
                    when (responseCode) {
                        1 -> {//keep reading file
                            val buffer = downloadImageResponse.fileChunk.toByteArray()
                            fileImageStream?.write(buffer)
                            //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /keep reading file")
                        }
                        2 -> {//End of file reached
                            fileImageStream?.flush()
                            fileImageStream?.close()
                            //Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow /End of file reached")
                            val imageUri = Uri.parse(imageFileName)
                            val imageDrawable = Drawable.createFromPath(imageUri.path)
                            if (imageDrawable != null) {
                                habApp.uiScope.launch {
                                    imageViewPersonPhoto.setImageDrawable(imageDrawable)
                                }
                            }
                        }
                        -1 -> {//error
                            //todo: error
                            fileImageStream?.close()
                            fileImageStream = null
                        }
                    }
                }.onEmpty {
                    Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow empty")
                }.catch { e ->

                }.collect()
            } catch (e: FileNotFoundException) {
                Log.d("InRadiusVisibleFragment", "downloadImageResponseFlow FileNotFoundException")
            }
        }
    }

    internal inner class CustomViewHolder : RecyclerView.ViewHolder {
        var layout: ConstraintLayout
        var imageViewPersonPhoto: ShapeableImageView
        var statusBackgroundLayout: ConstraintLayout
        var imageViewMoreActions: ImageView
        var textViewStatus: TextView
        var toUserId: String? = null
        var toUserName: String? = null
        var toUserStatus: String? = null
        var toUserDescription: String? = null
        var toUserRadiusSearchDistance = 0
        var isAdminOn = false
        var city = ""

        constructor(layout: ConstraintLayout):super(layout) {
            this.layout = layout
            statusBackgroundLayout = layout.findViewById(R.id.status_background_layout)
            imageViewPersonPhoto = layout.findViewById(R.id.image_view_person_photo)
            imageViewMoreActions = layout.findViewById(R.id.image_view_more_actions)
            textViewStatus = layout.findViewById(R.id.text_view_status)
            imageViewPersonPhoto.shapeAppearanceModel = imageViewPersonPhoto.shapeAppearanceModel
                    .toBuilder()
                    .setTopLeftCorner(CornerFamily.ROUNDED, 15f)
                    .setTopRightCorner(CornerFamily.ROUNDED, 15f)
                    .build()
            layout.setOnClickListener { view: View? ->
                if (toUserId != "SelfProfile") {
                    val intentProfileFromSearchInRadiusActivity = Intent(habApp, ProfileFromSearchInRadiusActivity::class.java)
                    intentProfileFromSearchInRadiusActivity.putExtra("toUserId", toUserId)
                    intentProfileFromSearchInRadiusActivity.putExtra("toUserName", toUserName)
                    intentProfileFromSearchInRadiusActivity.putExtra("toUserStatus", toUserStatus)
                    intentProfileFromSearchInRadiusActivity.putExtra("toUserDescription", toUserDescription)
                    intentProfileFromSearchInRadiusActivity.putExtra("toUserRadiusSearchDistance", toUserRadiusSearchDistance)
                    intentProfileFromSearchInRadiusActivity.putExtra("is_admin_on", isAdminOn)
                    intentProfileFromSearchInRadiusActivity.putExtra("city", city)
                    intentProfileFromSearchInRadiusActivity.addFlags(FLAG_ACTIVITY_NEW_TASK)
                    habApp.startActivity(intentProfileFromSearchInRadiusActivity)
                }
            }
            imageViewMoreActions.setOnClickListener {
                val intentReportUserActivity = Intent(habApp, ReportUserActivity::class.java)
                intentReportUserActivity.addFlags(FLAG_ACTIVITY_NEW_TASK)
                habApp.startActivity(intentReportUserActivity)
            }
        }
    }
}