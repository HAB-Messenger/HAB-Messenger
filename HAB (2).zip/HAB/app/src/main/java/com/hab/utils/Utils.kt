package com.hab.utils

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.Gravity
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toFile
import com.google.protobuf.ByteString
import com.hab.app.HabApplication
import com.hab.grpc.chatservice.UploadImageRequest
import com.hab.services.ChatService
import com.hab.services.PushNotificationsService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt


object Utils {
    const val SHARED_PREFS = "SHARED_PREFS"
    const val SHARED_PREFS_KEY_IS_SEARCHING = "SHARED_PREFS_KEY_IS_SEARCHING"
    const val SHARED_PREFS_KEY_IS_ADMIN_ON = "SHARED_PREFS_KEY_IS_ADMIN_ON"
    const val SHARED_PREFS_KEY_IS_LOCATION_ENABLED = "SHARED_PREFS_KEY_IS_LOCATION_ENABLED"

    const val SHARED_PREFS_KEY_FIRST_TIME_OPEN_APP = "SHARED_PREFS_KEY_FIRST_TIME_OPEN_APP"

    const val SHARED_PREFS_USER_INFO = "SHARED_PREFS_USER_INFO"
    const val SHARED_PREFS_KEY_USER_ID = "SHARED_PREFS_KEY_USER_ID"
    const val SHARED_PREFS_KEY_USER_NAME = "SHARED_PREFS_USER_NAME"
    const val SHARED_PREFS_KEY_USER_SURNAME = "SHARED_PREFS_USER_SURNAME"
    const val SHARED_PREFS_KEY_USER_GENDER = "SHARED_PREFS_USER_GENDER"
    const val SHARED_PREFS_KEY_USER_AGE = "SHARED_PREFS_KEY_USER_AGE"
    const val SHARED_PREFS_KEY_USER_STATUS = "SHARED_PREFS_USER_STATUS"
    const val SHARED_PREFS_KEY_USER_DESCRIPTION = "SHARED_PREFS_USER_DESCRIPTION"
    const val SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS = "SHARED_PREFS_KEY_USER_VISIBLE_IN_RADIUS"
    const val SHARED_PREFS_KEY_USER_STATUS_COLOR = "SHARED_PREFS_USER_STATUS_COLOR"
    const val SHARED_PREFS_KEY_USER_IMAGE = "SHARED_PREFS_KEY_USER_IMAGE"
    const val SHARED_PREFS_KEY_IMAGE_VIEW_USER_PHOTO_HEIGHT = "SHARED_PREFS_KEY_IMAGE_VIEW_USER_PHOTO_HEIGHT"
    const val SHARED_PREFS_KEY_USER_CITY = "SHARED_PREFS_KEY_USER_CITY"

    const val SHARED_PREFS_SEARCHING_SETTINGS = "SHARED_PREFS_SEARCHING_SETTINGS"
    const val SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER = "SHARED_PREFS_SEARCHING_SETTINGS_KEY_GENDER"
    const val SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE = "SHARED_PREFS_SEARCHING_SETTINGS_KEY_MIN_AGE"
    const val SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE = "SHARED_PREFS_SEARCHING_SETTINGS_KEY_MAX_AGE"
    const val SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY = "SHARED_PREFS_SEARCHING_SETTINGS_KEY_CITY"

    const val SHARED_PREFS_CURRENT_COORDINATES = "SHARED_PREFS_CURRENT_COORDINATES"
    const val SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT = "SHARED_PREFS_CURRENT_COORDINATES_KEY_LAT"
    const val SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG = "SHARED_PREFS_CURRENT_COORDINATES_KEY_LNG"

    const val SHARED_PREFS_NOTIFICATION_SETTINGS = "SHARED_PREFS_NOTIFICATION_SETTINGS"
    const val SHARED_PREFS_SHOW_PUSH_NOTIFICATION = "SHARED_PREFS_SHOW_PUSH_NOTIFICATION"
    const val SHARED_PREFS_NOTIFICATION_VIBRATION = "SHARED_PREFS_NOTIFICATION_VIBRATION"
    const val SHARED_PREFS_NOTIFICATION_SOUND = "SHARED_PREFS_NOTIFICATION_SOUND"

    const val SHARED_PREFS_PRIVACY_SETTINGS = "SHARED_PREFS_PRIVACY_SETTINGS"
    const val SHARED_PREFS_ENABLE_PRIVATE_MESSAGES = "SHARED_PREFS_ENABLE_PRIVATE_MESSAGES"

    const val GRPC_CHAT_SERVER_ADDRESS = "194.87.99.104"//"192.168.0.100"
    const val GRPC_CHAT_SERVER_PORT = 50051
    const val GRPC_PUSH_NOTIFICATION_SERVER_ADDRESS = "194.87.99.104"//"192.168.0.100"
    const val GRPC_PUSH_NOTIFICATION_SERVER_PORT = 50052

    const val CRASH_REPORTS_SERVER_ADDRESS = "194.87.99.104"//"192.168.0.100"
    const val CRASH_REPORTS_SERVER_URL = "$CRASH_REPORTS_SERVER_ADDRESS/crash_reports.php"

    const val SEARCHING_PEER_RESPONSE_CODE_SUCCESS = 1
    const val SEARCHING_PEER_RESPONSE_CODE_NO_PEER = 2
    const val SEARCHING_PEER_RESPONSE_CODE_PEER_CLOSED = 3
    const val SEARCHING_PEER_RESPONSE_CODE_PEER_OUT_OF_RADIUS = 4
    const val SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_OFF = 5
    const val SEARCHING_PEER_RESPONSE_CODE_PEER_SEARCHING_CITY_NOT_FOUND = 6

    const val RADIUS_10_METERS = 10
    const val RADIUS_50_METERS = 50
    const val RADIUS_100_METERS = 100
    const val RADIUS_250_METERS = 250
    const val RADIUS_500_METERS = 500
    const val RADIUS_1000_METERS = 1000
    const val RADIUS_5000_METERS = 5000
    const val RADIUS_15000_METERS = 15000
    const val RADIUS_30000_METERS = 30000
    const val RADIUS_ALL_METERS = Int.MAX_VALUE
    const val DEFAULT_VISIBILITY_RADIUS_IN_METERS = RADIUS_ALL_METERS

    const val DEFAULT_AGE = 18
    const val DEFAULT_MIN_AGE = 18
    const val DEFAULT_MAX_AGE = 60
    const val DEFAULT_CITY = "Москва"
    const val DEFAULT_SEARCHING_CITY = "Все"

    const val HAB_DATABASE = "HAB_database"

    const val GENDER_MALE = "Male"
    const val GENDER_FEMALE = "Female"
    const val GENDER_ALL = "gender_all"

    const val BLOCKING_TIME_1_HOUR = "1h"
    const val BLOCKING_TIME_3_HOURS = "3h"
    const val BLOCKING_TIME_5_HOURS = "5h"
    const val BLOCKING_TIME_ALWAYS = "always"

    const val PUSH_SERVICE_NOTIFICATION_ID = 1
    const val CHAT_SERVICE_NOTIFICATION_ID = 2
    const val NEW_MESSAGE_NOTIFICATION_ID = 3

    const val STATUS_COLOR_WHITE = 0
    const val STATUS_COLOR_GREEN = 1
    const val STATUS_COLOR_RED = 2
    const val STATUS_COLOR_ORANGE = 3
    const val STATUS_COLOR_LILAC = 4
    const val STATUS_COLOR_BLUE = 5
    const val STATUS_COLOR_YELLOW = 6
    const val STATUS_COLOR_GRAY = 7

    const val STATUS_CHARS_NUM = 39

    @JvmStatic
    fun showToast(context: Context?, msg: String?) {
        val toast = Toast.makeText(context, msg, Toast.LENGTH_LONG)
        toast.setGravity(Gravity.CENTER, 0, 0)
        toast.show()
    }

    @JvmStatic
    fun hasAllPermissionsGranted(grantResults: IntArray): Boolean {
        for (grantResult in grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                return false
            }
        }
        return true
    }

    suspend fun resizeDownBitmap(imageUri: Uri, habApp: HabApplication): Bitmap? {
        var imgOriginalBitmap: Bitmap? = null
        withContext(HabApplication.ioScope.coroutineContext) {
            //val imgInputStream: InputStream? = habApp.getContentResolver().openInputStream(imageUri)
            //imgOriginalBitmap = BitmapFactory.decodeStream(imgInputStream)
            //imgInputStream?.close()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try {
                    imgOriginalBitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(habApp.getContentResolver(), imageUri))
                } catch (e: Exception) {
                    //todo
                }
            }
            if (imgOriginalBitmap == null) {
                val options = BitmapFactory.Options()
                options.inSampleSize = 2
                options.inJustDecodeBounds = false

                imgOriginalBitmap = BitmapFactory.decodeFile(imageUri.getPath(), options)
            }
            if (imgOriginalBitmap == null) {
                val parcelFileDescriptor = habApp.getContentResolver().openFileDescriptor(imageUri, "r")
                val fileDescriptor = parcelFileDescriptor?.getFileDescriptor()
                imgOriginalBitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor)

                parcelFileDescriptor?.close()
            }
        }

        if (imgOriginalBitmap != null) {
            val originalWidth = imgOriginalBitmap?.getWidth()?:0
            val originalHeight = imgOriginalBitmap?.getHeight()?:0

            var halfWidth = originalWidth
            var halfHeight = originalHeight
            while (halfWidth > 1000 && halfHeight > 1000) {
                halfWidth = halfWidth / 2
                halfHeight = halfHeight / 2
            }
            var imgResizedBitmap: Bitmap? = null
            withContext(HabApplication.defaultScope.coroutineContext) {
                imgOriginalBitmap?.let {
                    imgResizedBitmap = Bitmap.createScaledBitmap(it, halfWidth, halfHeight, false)
                }
            }

            return imgResizedBitmap
        } else {
            return null
        }
    }

    suspend fun resizeDownBitmap(imageUri: Uri, habApp: HabApplication, toWidth: Int, toHeight: Int): Bitmap? {
        var imgOriginalBitmap: Bitmap? = null
        withContext(HabApplication.ioScope.coroutineContext) {
            //val imgInputStream: InputStream? = habApp.getContentResolver().openInputStream(imageUri)
            //imgOriginalBitmap = BitmapFactory.decodeStream(imgInputStream)
            //imgInputStream?.close()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                try {
                    imgOriginalBitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(habApp.getContentResolver(), imageUri))
                } catch (e: Exception) {
                    //todo
                }
            } else {
                //requireContext().contentResolver
                imgOriginalBitmap = MediaStore.Images.Media.getBitmap(habApp.getContentResolver(), imageUri)
            }
            if (imgOriginalBitmap == null) {
                val options = BitmapFactory.Options()
                options.inSampleSize = 2
                options.inJustDecodeBounds = false

                imgOriginalBitmap = BitmapFactory.decodeFile(imageUri.getPath(), options)
            }
            if (imgOriginalBitmap == null) {
                val parcelFileDescriptor = habApp.getContentResolver().openFileDescriptor(imageUri, "r")
                val fileDescriptor = parcelFileDescriptor?.getFileDescriptor()
                imgOriginalBitmap = BitmapFactory.decodeFileDescriptor(fileDescriptor)

                parcelFileDescriptor?.close()
            }
        }

        if (imgOriginalBitmap != null) {
            val originalWidth = imgOriginalBitmap?.getWidth()?:0
            val originalHeight = imgOriginalBitmap?.getHeight()?:0

            var halfWidth = originalWidth
            var halfHeight = originalHeight
            while (halfWidth > 700 && halfHeight > 700) {
                halfWidth = (halfWidth.toFloat() / 1.1).toInt()
                halfHeight = (halfHeight.toFloat() / 1.1).toInt()
            }
            var imgResizedBitmap: Bitmap? = null
            withContext(HabApplication.defaultScope.coroutineContext) {
                imgOriginalBitmap?.let {
                    imgResizedBitmap = Bitmap.createScaledBitmap(it, halfWidth, halfHeight, false)
                }
            }

            return imgResizedBitmap
        } else {
            return null
        }
    }

    suspend fun uploadImage(userId: String, imageName: String, imageBitmap: Bitmap, habApp: HabApplication) {
        val channel = Channel<UploadImageRequest>()
        val uploadImageRequestFlow: Flow<UploadImageRequest> = channel.consumeAsFlow()

        HabApplication.ioScope.launch {
            val byteArrayOutputStream = ByteArrayOutputStream()
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteArrayOutputStream)
            val inputStream = ByteArrayInputStream(byteArrayOutputStream.toByteArray())
            inputStream.buffered().use { input ->
                val buff = ByteArray(1024)
                var size = input.read(buff)
                while(size != -1) {
                    val uploadImageRequest = UploadImageRequest.newBuilder()
                            .setUserId(userId)
                            .setFileChunk(ByteString.copyFrom(buff))
                            .setImageName(imageName)
                            .build()
                    channel.send(uploadImageRequest)
                    size = input.read(buff)
                }
                channel.close()
            }
        }
        try {
            habApp.chatAPIService.uploadImage(uploadImageRequestFlow)
        } catch (e: io.grpc.StatusException) {
            habApp.uiScope.launch {
                showToast(habApp, "${e.message}")
            }
        } catch (e: CancellationException) {
            throw e
        }
    }

    fun copyFileFromCacheToInternalStorage(context: Context, fileName: String, cachedImageUri: Uri): Uri {
        val internalStorageFile = File(context.getFilesDir(), fileName)
        if (internalStorageFile.exists()) {
            internalStorageFile.delete()
        }
        if (cachedImageUri.getScheme().equals("file")) {
            val cachedFile = cachedImageUri.toFile()
            cachedFile.copyTo(internalStorageFile)
        } else if (cachedImageUri.getScheme().equals("content")) {
            val inputStream = context.getContentResolver().openInputStream(cachedImageUri)
            val outputStream = FileOutputStream(internalStorageFile)
            inputStream?.copyTo(outputStream)
            outputStream.flush()
            outputStream.close()
            inputStream?.close()
        }
        return Uri.fromFile(internalStorageFile)
    }

    /*@JvmStatic
    fun uploadImage(userId: String, imageUri: Uri, habApp: HabApplication) {
        val channel = Channel<UploadImageRequest>()
        val uploadImageRequestFlow: Flow<UploadImageRequest> = channel.consumeAsFlow()

        ChatService.ioScope.launch {
            habApp.contentResolver.openInputStream(imageUri)!!.buffered().use { input ->
                val buff = ByteArray(1024)
                var size = input.read(buff)
                while(size != -1) {
                    val uploadImageRequest = UploadImageRequest.newBuilder()
                            .setUserId(userId)
                            .setFileChunk(ByteString.copyFrom(buff))
                            .setImageName(imageUri.toString().substringAfterLast("/"))
                            .build()
                    channel.send(uploadImageRequest)
                    size = input.read(buff)
                }
                channel.close()
            }
        }
        ChatService.ioScope.launch {
            try {
                habApp.chatAPIService.uploadImage(uploadImageRequestFlow)
            }catch (e: io.grpc.StatusException) {
                habApp.uiScope.launch {
                    showToast(habApp, "${e.message}")
                }
            }
        }
    }*/

    /*@JvmStatic
    fun uploadImage(userId: String, absoluteFileName: String, habApp: HabApplication) {
        val channel = Channel<UploadImageRequest>()
        val uploadImageRequestFlow: Flow<UploadImageRequest> = channel.consumeAsFlow()

        ChatService.ioScope.launch {
            habApp.chatAPIService.uploadImage(uploadImageRequestFlow)
            if (File(absoluteFileName).exists()) {
                File(absoluteFileName).inputStream().buffered().use { input ->
                    val buff = ByteArray(1024)
                    var size = input.read(buff)
                    while(size != -1) {
                        val uploadImageRequest = UploadImageRequest.newBuilder()
                                .setUserId(userId)
                                .setFileChunk(ByteString.copyFrom(buff))
                                .setImageName(absoluteFileName.substringAfterLast("/"))
                                .build()
                        channel.send(uploadImageRequest)
                        size = input.read(buff)
                    }
                }
            } else {
                habApp.uiScope.launch {
                    showToast(habApp, "No file")
                }
            }
        }
    }*/

    fun isServiceRunning(context: Context, serviceClass: Class<*>): Boolean {
        val manager = context.getSystemService(AppCompatActivity.ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Int.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                return true
            }
        }
        return false
    }

    /*fun startServices(context: Context) {
        val intentPushNotificationsService = Intent(context, PushNotificationsService::class.java)
        val intentChatService = Intent(context, ChatService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intentPushNotificationsService)
            context.startForegroundService(intentChatService)
        } else {
            context.startService(intentPushNotificationsService)
            context.startService(intentChatService)
        }
    }*/

    fun startChatServiceService(context: Context) {
        val intentChatService = Intent(context, ChatService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intentChatService)
        } else {
            context.startService(intentChatService)
        }
    }

    fun startPushNotificationsServiceService(context: Context) {
        val intentPushNotificationsService = Intent(context, PushNotificationsService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intentPushNotificationsService)
        } else {
            context.startService(intentPushNotificationsService)
        }
    }
}
