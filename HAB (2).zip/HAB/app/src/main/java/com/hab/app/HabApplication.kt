package com.hab.app

import android.util.Log
import androidx.multidex.MultiDexApplication
//import com.google.android.gms.ads.MobileAds
import com.hab.R
import com.hab.utils.Utils
import com.hab.utils.Utils.CRASH_REPORTS_SERVER_URL
import com.hab.grpc.chatservice.ChatAPIService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.acra.ACRA
import org.acra.annotation.AcraHttpSender
import org.acra.annotation.AcraToast
import org.acra.sender.HttpSender
import kotlin.coroutines.cancellation.CancellationException


@AcraToast(resText = R.string.acra_report_toast)
@AcraHttpSender(uri = "http://${CRASH_REPORTS_SERVER_URL}", httpMethod = HttpSender.Method.POST)
class HabApplication : MultiDexApplication {

    val uiScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    lateinit var chatAPIService: ChatAPIService

    constructor() : super() {

    }

    override fun onCreate() {
        super.onCreate()
        ACRA.init(this)

        chatAPIService = ChatAPIService()

        //MobileAds.initialize(this) {}
    }

    companion object {
        val defaultScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
        val ioScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    }
}