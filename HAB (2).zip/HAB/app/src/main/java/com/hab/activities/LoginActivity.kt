package com.hab.activities

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.text.method.LinkMovementMethod
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.hab.R
import com.hab.app.HabApplication
import com.hab.db.HabDB
import com.hab.utils.Utils.SHARED_PREFS
import com.hab.utils.Utils.SHARED_PREFS_KEY_FIRST_TIME_OPEN_APP
import com.hab.utils.Utils.SHARED_PREFS_KEY_USER_ID
import com.hab.utils.Utils.SHARED_PREFS_USER_INFO
import com.hab.utils.Utils.showToast
import com.hab.utils.Utils.startChatServiceService
import com.hab.utils.Utils.startPushNotificationsServiceService
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d("HAB_", "LoginActivity.onCreate")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val privacyPolicyTextView = findViewById<TextView>(R.id.privacy_policy_text_view)
        privacyPolicyTextView.setClickable(true)
        privacyPolicyTextView.setMovementMethod(LinkMovementMethod.getInstance())
        val privacyPolicyLink = "<a href='https://drive.google.com/file/d/1eA_J6GAXs4WB7VYTHsWFCqWW3wz_l2_F/view'>и политикой конфидециальности</a>"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            privacyPolicyTextView.setText(Html.fromHtml(privacyPolicyLink, Html.FROM_HTML_MODE_COMPACT))
        } else {
            privacyPolicyTextView.setText(Html.fromHtml(privacyPolicyLink))
        }

        val sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE)
        val isAppOpenedFirstTime = sharedPreferences.getBoolean(SHARED_PREFS_KEY_FIRST_TIME_OPEN_APP, true)
        val sharedPreferencesEditor = sharedPreferences.edit()

        val habApp = application as HabApplication
        //todo: replace below code
        var serialNumber = Build.SERIAL
        if (serialNumber.equals("unknown")) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    serialNumber = Build.getSerial()
                }
            } catch (e: SecurityException) {
                e.printStackTrace()
                Log.d("ChatService", "onStartCommand: "+e.message.toString())
            }
        }
        val userId = "user_id_${serialNumber}_${Build.VERSION.SDK_INT}"
        val sharedPreferencesUserInfo = getSharedPreferences(SHARED_PREFS_USER_INFO, MODE_PRIVATE)
        val sharedPreferencesUserInfoEditor = sharedPreferencesUserInfo.edit()
        sharedPreferencesUserInfoEditor.putString(SHARED_PREFS_KEY_USER_ID, userId)
        sharedPreferencesUserInfoEditor.apply()
        if (isAppOpenedFirstTime == true) {
            sharedPreferencesEditor.putBoolean(SHARED_PREFS_KEY_FIRST_TIME_OPEN_APP, false)
            sharedPreferencesEditor.apply()
        } else {
            HabApplication.ioScope.launch {
                val db = HabDB.getDatabase(applicationContext)
                val usersDAO = db.userDAO()
                val user = usersDAO.getUserByUserId(userId)
                if (user!=null) {
                    habApp.uiScope.launch {
                        val intentProfileActivity = Intent(this@LoginActivity, ProfileActivity::class.java)
                        startActivity(intentProfileActivity)
                        //startServices(this)
                        startChatServiceService(this@LoginActivity)
                        startPushNotificationsServiceService(this@LoginActivity)
                        finish()
                    }
                }
            }
        }

        val buttonVKlogin = findViewById<Button>(R.id.button_vk_login)
        val buttonFBlogin = findViewById<Button>(R.id.button_fb_login)
        buttonVKlogin.setOnClickListener { view: View? ->
            //todo: save userID in SHARED_PREFS_KEY_USER_ID
            //if (isAppOpenedFirstTime == true) {
                val intentInitialSettingsActivity = Intent(this, InitialSettingsActivity::class.java)
                startActivity(intentInitialSettingsActivity)
            //}
            //startServices(this)
            startChatServiceService(this)
            startPushNotificationsServiceService(this)
            finish()
        }
        buttonFBlogin.setOnClickListener { view: View? ->
            //todo: save userID in SHARED_PREFS_KEY_USER_ID
            showToast(this@LoginActivity, "FBLOGIn")
        }
    }

    /*private fun startServices() {
        val intentPushNotificationsService = Intent(this, PushNotificationsService::class.java)
        val intentChatService = Intent(this, ChatService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intentPushNotificationsService)
            startForegroundService(intentChatService)
        } else {
            startService(intentPushNotificationsService)
            startService(intentChatService)
        }
    }*/
}