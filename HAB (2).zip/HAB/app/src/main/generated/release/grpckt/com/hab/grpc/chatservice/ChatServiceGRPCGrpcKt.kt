package com.hab.grpc.chatservice

import com.hab.grpc.chatservice.ChatGrpc.getServiceDescriptor
import io.grpc.CallOptions
import io.grpc.CallOptions.DEFAULT
import io.grpc.Channel
import io.grpc.Metadata
import io.grpc.MethodDescriptor
import io.grpc.ServerServiceDefinition
import io.grpc.ServerServiceDefinition.builder
import io.grpc.ServiceDescriptor
import io.grpc.Status
import io.grpc.Status.UNIMPLEMENTED
import io.grpc.StatusException
import io.grpc.kotlin.AbstractCoroutineServerImpl
import io.grpc.kotlin.AbstractCoroutineStub
import io.grpc.kotlin.ClientCalls
import io.grpc.kotlin.ClientCalls.clientStreamingRpc
import io.grpc.kotlin.ClientCalls.serverStreamingRpc
import io.grpc.kotlin.ClientCalls.unaryRpc
import io.grpc.kotlin.ServerCalls
import io.grpc.kotlin.ServerCalls.clientStreamingServerMethodDefinition
import io.grpc.kotlin.ServerCalls.serverStreamingServerMethodDefinition
import io.grpc.kotlin.ServerCalls.unaryServerMethodDefinition
import io.grpc.kotlin.StubFor
import kotlin.String
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.jvm.JvmOverloads
import kotlin.jvm.JvmStatic
import kotlinx.coroutines.flow.Flow

/**
 * Holder for Kotlin coroutine-based client and server APIs for chatservice.Chat.
 */
object ChatGrpcKt {
  const val SERVICE_NAME: String = ChatGrpc.SERVICE_NAME

  @JvmStatic
  val serviceDescriptor: ServiceDescriptor
    get() = ChatGrpc.getServiceDescriptor()

  val newPeerMethod: MethodDescriptor<NewPeerRequest, NewPeerResponse>
    @JvmStatic
    get() = ChatGrpc.getNewPeerMethod()

  val searchingPeerMethod: MethodDescriptor<SearchingPeerRequest, SearchingPeerResponse>
    @JvmStatic
    get() = ChatGrpc.getSearchingPeerMethod()

  val newCoordinatesMethod: MethodDescriptor<NewCoordinatesRequest, NewCoordinatesResponse>
    @JvmStatic
    get() = ChatGrpc.getNewCoordinatesMethod()

  val newMessageMethod: MethodDescriptor<NewMessageRequest, NewMessageResponse>
    @JvmStatic
    get() = ChatGrpc.getNewMessageMethod()

  val newGroupMessageMethod: MethodDescriptor<NewCollectiveMessageRequest,
      NewCollectiveMessageResponse>
    @JvmStatic
    get() = ChatGrpc.getNewGroupMessageMethod()

  val typingMessageMethod: MethodDescriptor<TypingMessageRequest, TypingMessageResponse>
    @JvmStatic
    get() = ChatGrpc.getTypingMessageMethod()

  val typingGroupMessageMethod: MethodDescriptor<TypingMessageRequest, TypingMessageResponse>
    @JvmStatic
    get() = ChatGrpc.getTypingGroupMessageMethod()

  val chatClosedMethod: MethodDescriptor<ChatClosedRequest, ChatClosedResponse>
    @JvmStatic
    get() = ChatGrpc.getChatClosedMethod()

  val groupChatClosedMethod: MethodDescriptor<CollectiveChatClosedRequest,
      CollectiveChatClosedResponse>
    @JvmStatic
    get() = ChatGrpc.getGroupChatClosedMethod()

  val peerClosedMethod: MethodDescriptor<PeerClosedRequest, PeerClosedResponse>
    @JvmStatic
    get() = ChatGrpc.getPeerClosedMethod()

  val adminStatusMethod: MethodDescriptor<AdminStatusRequest, AdminStatusResponse>
    @JvmStatic
    get() = ChatGrpc.getAdminStatusMethod()

  val getAdminStatusMethod: MethodDescriptor<GetAdminStatusRequest, GetAdminStatusResponse>
    @JvmStatic
    get() = ChatGrpc.getGetAdminStatusMethod()

  val blockUserInGroupChatMethod: MethodDescriptor<BlockUserInCollectiveChatRequest,
      BlockUserInCollectiveChatResponse>
    @JvmStatic
    get() = ChatGrpc.getBlockUserInGroupChatMethod()

  val clearGroupChatMethod: MethodDescriptor<ClearCollectiveChatRequest,
      ClearCollectiveChatResponse>
    @JvmStatic
    get() = ChatGrpc.getClearGroupChatMethod()

  val blockUserInPersonalChatMethod: MethodDescriptor<BlockUserInPersonalChatRequest,
      BlockUserInPersonalChatResponse>
    @JvmStatic
    get() = ChatGrpc.getBlockUserInPersonalChatMethod()

  val clearPersonalChatMethod: MethodDescriptor<ClearPersonalChatRequest, ClearPersonalChatResponse>
    @JvmStatic
    get() = ChatGrpc.getClearPersonalChatMethod()

  val reportUserMethod: MethodDescriptor<ReportUserRequest, ReportUserResponse>
    @JvmStatic
    get() = ChatGrpc.getReportUserMethod()

  val uploadImageMethod: MethodDescriptor<UploadImageRequest, UploadImageResponse>
    @JvmStatic
    get() = ChatGrpc.getUploadImageMethod()

  val downloadImageMethod: MethodDescriptor<DownloadImageRequest, DownloadImageResponse>
    @JvmStatic
    get() = ChatGrpc.getDownloadImageMethod()

  val removeImageMethod: MethodDescriptor<RemoveImageRequest, RemoveImageResponse>
    @JvmStatic
    get() = ChatGrpc.getRemoveImageMethod()

  /**
   * A stub for issuing RPCs to a(n) chatservice.Chat service as suspending coroutines.
   */
  @StubFor(ChatGrpc::class)
  class ChatCoroutineStub @JvmOverloads constructor(
    channel: Channel,
    callOptions: CallOptions = DEFAULT
  ) : AbstractCoroutineStub<ChatCoroutineStub>(channel, callOptions) {
    override fun build(channel: Channel, callOptions: CallOptions): ChatCoroutineStub =
        ChatCoroutineStub(channel, callOptions)

    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun newPeer(request: NewPeerRequest): Flow<NewPeerResponse> = serverStreamingRpc(
      channel,
      ChatGrpc.getNewPeerMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun searchingPeer(request: SearchingPeerRequest): Flow<SearchingPeerResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getSearchingPeerMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Executes this RPC and returns the response message, suspending until the RPC completes
     * with [`Status.OK`][Status].  If the RPC completes with another status, a corresponding
     * [StatusException] is thrown.  If this coroutine is cancelled, the RPC is also cancelled
     * with the corresponding exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return The single response from the server.
     */
    suspend fun newCoordinates(request: NewCoordinatesRequest): NewCoordinatesResponse = unaryRpc(
      channel,
      ChatGrpc.getNewCoordinatesMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun newMessage(request: NewMessageRequest): Flow<NewMessageResponse> = serverStreamingRpc(
      channel,
      ChatGrpc.getNewMessageMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun newGroupMessage(request: NewCollectiveMessageRequest): Flow<NewCollectiveMessageResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getNewGroupMessageMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun typingMessage(request: TypingMessageRequest): Flow<TypingMessageResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getTypingMessageMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun typingGroupMessage(request: TypingMessageRequest): Flow<TypingMessageResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getTypingGroupMessageMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun chatClosed(request: ChatClosedRequest): Flow<ChatClosedResponse> = serverStreamingRpc(
      channel,
      ChatGrpc.getChatClosedMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun groupChatClosed(request: CollectiveChatClosedRequest): Flow<CollectiveChatClosedResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getGroupChatClosedMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Executes this RPC and returns the response message, suspending until the RPC completes
     * with [`Status.OK`][Status].  If the RPC completes with another status, a corresponding
     * [StatusException] is thrown.  If this coroutine is cancelled, the RPC is also cancelled
     * with the corresponding exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return The single response from the server.
     */
    suspend fun peerClosed(request: PeerClosedRequest): PeerClosedResponse = unaryRpc(
      channel,
      ChatGrpc.getPeerClosedMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Executes this RPC and returns the response message, suspending until the RPC completes
     * with [`Status.OK`][Status].  If the RPC completes with another status, a corresponding
     * [StatusException] is thrown.  If this coroutine is cancelled, the RPC is also cancelled
     * with the corresponding exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return The single response from the server.
     */
    suspend fun adminStatus(request: AdminStatusRequest): AdminStatusResponse = unaryRpc(
      channel,
      ChatGrpc.getAdminStatusMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun getAdminStatus(request: GetAdminStatusRequest): Flow<GetAdminStatusResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getGetAdminStatusMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun blockUserInGroupChat(request: BlockUserInCollectiveChatRequest):
        Flow<BlockUserInCollectiveChatResponse> = serverStreamingRpc(
      channel,
      ChatGrpc.getBlockUserInGroupChatMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun clearGroupChat(request: ClearCollectiveChatRequest): Flow<ClearCollectiveChatResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getClearGroupChatMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun blockUserInPersonalChat(request: BlockUserInPersonalChatRequest):
        Flow<BlockUserInPersonalChatResponse> = serverStreamingRpc(
      channel,
      ChatGrpc.getBlockUserInPersonalChatMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun clearPersonalChat(request: ClearPersonalChatRequest): Flow<ClearPersonalChatResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getClearPersonalChatMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Executes this RPC and returns the response message, suspending until the RPC completes
     * with [`Status.OK`][Status].  If the RPC completes with another status, a corresponding
     * [StatusException] is thrown.  If this coroutine is cancelled, the RPC is also cancelled
     * with the corresponding exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return The single response from the server.
     */
    suspend fun reportUser(request: ReportUserRequest): ReportUserResponse = unaryRpc(
      channel,
      ChatGrpc.getReportUserMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Executes this RPC and returns the response message, suspending until the RPC completes
     * with [`Status.OK`][Status].  If the RPC completes with another status, a corresponding
     * [StatusException] is thrown.  If this coroutine is cancelled, the RPC is also cancelled
     * with the corresponding exception as a cause.
     *
     * This function collects the [Flow] of requests.  If the server terminates the RPC
     * for any reason before collection of requests is complete, the collection of requests
     * will be cancelled.  If the collection of requests completes exceptionally for any other
     * reason, the RPC will be cancelled for that reason and this method will throw that
     * exception.
     *
     * @param requests A [Flow] of request messages.
     *
     * @return The single response from the server.
     */
    suspend fun uploadImage(requests: Flow<UploadImageRequest>): UploadImageResponse =
        clientStreamingRpc(
      channel,
      ChatGrpc.getUploadImageMethod(),
      requests,
      callOptions,
      Metadata()
    )
    /**
     * Returns a [Flow] that, when collected, executes this RPC and emits responses from the
     * server as they arrive.  That flow finishes normally if the server closes its response with
     * [`Status.OK`][Status], and fails by throwing a [StatusException] otherwise.  If
     * collecting the flow downstream fails exceptionally (including via cancellation), the RPC
     * is cancelled with that exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return A flow that, when collected, emits the responses from the server.
     */
    fun downloadImage(request: DownloadImageRequest): Flow<DownloadImageResponse> =
        serverStreamingRpc(
      channel,
      ChatGrpc.getDownloadImageMethod(),
      request,
      callOptions,
      Metadata()
    )
    /**
     * Executes this RPC and returns the response message, suspending until the RPC completes
     * with [`Status.OK`][Status].  If the RPC completes with another status, a corresponding
     * [StatusException] is thrown.  If this coroutine is cancelled, the RPC is also cancelled
     * with the corresponding exception as a cause.
     *
     * @param request The request message to send to the server.
     *
     * @return The single response from the server.
     */
    suspend fun removeImage(request: RemoveImageRequest): RemoveImageResponse = unaryRpc(
      channel,
      ChatGrpc.getRemoveImageMethod(),
      request,
      callOptions,
      Metadata()
    )}

  /**
   * Skeletal implementation of the chatservice.Chat service based on Kotlin coroutines.
   */
  abstract class ChatCoroutineImplBase(
    coroutineContext: CoroutineContext = EmptyCoroutineContext
  ) : AbstractCoroutineServerImpl(coroutineContext) {
    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.NewPeer.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun newPeer(request: NewPeerRequest): Flow<NewPeerResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.NewPeer is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.SearchingPeer.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun searchingPeer(request: SearchingPeerRequest): Flow<SearchingPeerResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.SearchingPeer is unimplemented"))

    /**
     * Returns the response to an RPC for chatservice.Chat.NewCoordinates.
     *
     * If this method fails with a [StatusException], the RPC will fail with the corresponding
     * [Status].  If this method fails with a [java.util.concurrent.CancellationException], the RPC
     * will fail
     * with status `Status.CANCELLED`.  If this method fails for any other reason, the RPC will
     * fail with `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open suspend fun newCoordinates(request: NewCoordinatesRequest): NewCoordinatesResponse = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.NewCoordinates is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.NewMessage.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun newMessage(request: NewMessageRequest): Flow<NewMessageResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.NewMessage is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.NewGroupMessage.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun newGroupMessage(request: NewCollectiveMessageRequest):
        Flow<NewCollectiveMessageResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.NewGroupMessage is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.TypingMessage.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun typingMessage(request: TypingMessageRequest): Flow<TypingMessageResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.TypingMessage is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.TypingGroupMessage.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun typingGroupMessage(request: TypingMessageRequest): Flow<TypingMessageResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.TypingGroupMessage is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.ChatClosed.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun chatClosed(request: ChatClosedRequest): Flow<ChatClosedResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.ChatClosed is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.GroupChatClosed.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun groupChatClosed(request: CollectiveChatClosedRequest):
        Flow<CollectiveChatClosedResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.GroupChatClosed is unimplemented"))

    /**
     * Returns the response to an RPC for chatservice.Chat.PeerClosed.
     *
     * If this method fails with a [StatusException], the RPC will fail with the corresponding
     * [Status].  If this method fails with a [java.util.concurrent.CancellationException], the RPC
     * will fail
     * with status `Status.CANCELLED`.  If this method fails for any other reason, the RPC will
     * fail with `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open suspend fun peerClosed(request: PeerClosedRequest): PeerClosedResponse = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.PeerClosed is unimplemented"))

    /**
     * Returns the response to an RPC for chatservice.Chat.AdminStatus.
     *
     * If this method fails with a [StatusException], the RPC will fail with the corresponding
     * [Status].  If this method fails with a [java.util.concurrent.CancellationException], the RPC
     * will fail
     * with status `Status.CANCELLED`.  If this method fails for any other reason, the RPC will
     * fail with `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open suspend fun adminStatus(request: AdminStatusRequest): AdminStatusResponse = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.AdminStatus is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.GetAdminStatus.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun getAdminStatus(request: GetAdminStatusRequest): Flow<GetAdminStatusResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.GetAdminStatus is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.BlockUserInGroupChat.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun blockUserInGroupChat(request: BlockUserInCollectiveChatRequest):
        Flow<BlockUserInCollectiveChatResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.BlockUserInGroupChat is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.ClearGroupChat.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun clearGroupChat(request: ClearCollectiveChatRequest): Flow<ClearCollectiveChatResponse>
        = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.ClearGroupChat is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.BlockUserInPersonalChat.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun blockUserInPersonalChat(request: BlockUserInPersonalChatRequest):
        Flow<BlockUserInPersonalChatResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.BlockUserInPersonalChat is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.ClearPersonalChat.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun clearPersonalChat(request: ClearPersonalChatRequest): Flow<ClearPersonalChatResponse> =
        throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.ClearPersonalChat is unimplemented"))

    /**
     * Returns the response to an RPC for chatservice.Chat.ReportUser.
     *
     * If this method fails with a [StatusException], the RPC will fail with the corresponding
     * [Status].  If this method fails with a [java.util.concurrent.CancellationException], the RPC
     * will fail
     * with status `Status.CANCELLED`.  If this method fails for any other reason, the RPC will
     * fail with `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open suspend fun reportUser(request: ReportUserRequest): ReportUserResponse = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.ReportUser is unimplemented"))

    /**
     * Returns the response to an RPC for chatservice.Chat.UploadImage.
     *
     * If this method fails with a [StatusException], the RPC will fail with the corresponding
     * [Status].  If this method fails with a [java.util.concurrent.CancellationException], the RPC
     * will fail
     * with status `Status.CANCELLED`.  If this method fails for any other reason, the RPC will
     * fail with `Status.UNKNOWN` with the exception as a cause.
     *
     * @param requests A [Flow] of requests from the client.  This flow can be
     *        collected only once and throws [java.lang.IllegalStateException] on attempts to
     * collect
     *        it more than once.
     */
    open suspend fun uploadImage(requests: Flow<UploadImageRequest>): UploadImageResponse = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.UploadImage is unimplemented"))

    /**
     * Returns a [Flow] of responses to an RPC for chatservice.Chat.DownloadImage.
     *
     * If creating or collecting the returned flow fails with a [StatusException], the RPC
     * will fail with the corresponding [Status].  If it fails with a
     * [java.util.concurrent.CancellationException], the RPC will fail with status
     * `Status.CANCELLED`.  If creating
     * or collecting the returned flow fails for any other reason, the RPC will fail with
     * `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open fun downloadImage(request: DownloadImageRequest): Flow<DownloadImageResponse> = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.DownloadImage is unimplemented"))

    /**
     * Returns the response to an RPC for chatservice.Chat.RemoveImage.
     *
     * If this method fails with a [StatusException], the RPC will fail with the corresponding
     * [Status].  If this method fails with a [java.util.concurrent.CancellationException], the RPC
     * will fail
     * with status `Status.CANCELLED`.  If this method fails for any other reason, the RPC will
     * fail with `Status.UNKNOWN` with the exception as a cause.
     *
     * @param request The request from the client.
     */
    open suspend fun removeImage(request: RemoveImageRequest): RemoveImageResponse = throw
        StatusException(UNIMPLEMENTED.withDescription("Method chatservice.Chat.RemoveImage is unimplemented"))

    final override fun bindService(): ServerServiceDefinition = builder(getServiceDescriptor())
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getNewPeerMethod(),
      implementation = ::newPeer
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getSearchingPeerMethod(),
      implementation = ::searchingPeer
    ))
      .addMethod(unaryServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getNewCoordinatesMethod(),
      implementation = ::newCoordinates
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getNewMessageMethod(),
      implementation = ::newMessage
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getNewGroupMessageMethod(),
      implementation = ::newGroupMessage
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getTypingMessageMethod(),
      implementation = ::typingMessage
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getTypingGroupMessageMethod(),
      implementation = ::typingGroupMessage
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getChatClosedMethod(),
      implementation = ::chatClosed
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getGroupChatClosedMethod(),
      implementation = ::groupChatClosed
    ))
      .addMethod(unaryServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getPeerClosedMethod(),
      implementation = ::peerClosed
    ))
      .addMethod(unaryServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getAdminStatusMethod(),
      implementation = ::adminStatus
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getGetAdminStatusMethod(),
      implementation = ::getAdminStatus
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getBlockUserInGroupChatMethod(),
      implementation = ::blockUserInGroupChat
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getClearGroupChatMethod(),
      implementation = ::clearGroupChat
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getBlockUserInPersonalChatMethod(),
      implementation = ::blockUserInPersonalChat
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getClearPersonalChatMethod(),
      implementation = ::clearPersonalChat
    ))
      .addMethod(unaryServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getReportUserMethod(),
      implementation = ::reportUser
    ))
      .addMethod(clientStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getUploadImageMethod(),
      implementation = ::uploadImage
    ))
      .addMethod(serverStreamingServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getDownloadImageMethod(),
      implementation = ::downloadImage
    ))
      .addMethod(unaryServerMethodDefinition(
      context = this.context,
      descriptor = ChatGrpc.getRemoveImageMethod(),
      implementation = ::removeImage
    )).build()
  }
}
