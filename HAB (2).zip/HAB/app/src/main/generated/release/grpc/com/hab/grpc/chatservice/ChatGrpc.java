package com.hab.grpc.chatservice;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.37.1)",
    comments = "Source: chat.proto")
public final class ChatGrpc {

  private ChatGrpc() {}

  public static final String SERVICE_NAME = "chatservice.Chat";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewPeerRequest,
      com.hab.grpc.chatservice.NewPeerResponse> getNewPeerMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "NewPeer",
      requestType = com.hab.grpc.chatservice.NewPeerRequest.class,
      responseType = com.hab.grpc.chatservice.NewPeerResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewPeerRequest,
      com.hab.grpc.chatservice.NewPeerResponse> getNewPeerMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewPeerRequest, com.hab.grpc.chatservice.NewPeerResponse> getNewPeerMethod;
    if ((getNewPeerMethod = ChatGrpc.getNewPeerMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getNewPeerMethod = ChatGrpc.getNewPeerMethod) == null) {
          ChatGrpc.getNewPeerMethod = getNewPeerMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.NewPeerRequest, com.hab.grpc.chatservice.NewPeerResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "NewPeer"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.NewPeerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.NewPeerResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getNewPeerMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.SearchingPeerRequest,
      com.hab.grpc.chatservice.SearchingPeerResponse> getSearchingPeerMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SearchingPeer",
      requestType = com.hab.grpc.chatservice.SearchingPeerRequest.class,
      responseType = com.hab.grpc.chatservice.SearchingPeerResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.SearchingPeerRequest,
      com.hab.grpc.chatservice.SearchingPeerResponse> getSearchingPeerMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.SearchingPeerRequest, com.hab.grpc.chatservice.SearchingPeerResponse> getSearchingPeerMethod;
    if ((getSearchingPeerMethod = ChatGrpc.getSearchingPeerMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getSearchingPeerMethod = ChatGrpc.getSearchingPeerMethod) == null) {
          ChatGrpc.getSearchingPeerMethod = getSearchingPeerMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.SearchingPeerRequest, com.hab.grpc.chatservice.SearchingPeerResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SearchingPeer"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.SearchingPeerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.SearchingPeerResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getSearchingPeerMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewCoordinatesRequest,
      com.hab.grpc.chatservice.NewCoordinatesResponse> getNewCoordinatesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "NewCoordinates",
      requestType = com.hab.grpc.chatservice.NewCoordinatesRequest.class,
      responseType = com.hab.grpc.chatservice.NewCoordinatesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewCoordinatesRequest,
      com.hab.grpc.chatservice.NewCoordinatesResponse> getNewCoordinatesMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewCoordinatesRequest, com.hab.grpc.chatservice.NewCoordinatesResponse> getNewCoordinatesMethod;
    if ((getNewCoordinatesMethod = ChatGrpc.getNewCoordinatesMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getNewCoordinatesMethod = ChatGrpc.getNewCoordinatesMethod) == null) {
          ChatGrpc.getNewCoordinatesMethod = getNewCoordinatesMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.NewCoordinatesRequest, com.hab.grpc.chatservice.NewCoordinatesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "NewCoordinates"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.NewCoordinatesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.NewCoordinatesResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getNewCoordinatesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewMessageRequest,
      com.hab.grpc.chatservice.NewMessageResponse> getNewMessageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "NewMessage",
      requestType = com.hab.grpc.chatservice.NewMessageRequest.class,
      responseType = com.hab.grpc.chatservice.NewMessageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewMessageRequest,
      com.hab.grpc.chatservice.NewMessageResponse> getNewMessageMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewMessageRequest, com.hab.grpc.chatservice.NewMessageResponse> getNewMessageMethod;
    if ((getNewMessageMethod = ChatGrpc.getNewMessageMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getNewMessageMethod = ChatGrpc.getNewMessageMethod) == null) {
          ChatGrpc.getNewMessageMethod = getNewMessageMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.NewMessageRequest, com.hab.grpc.chatservice.NewMessageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "NewMessage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.NewMessageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.NewMessageResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getNewMessageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewCollectiveMessageRequest,
      com.hab.grpc.chatservice.NewCollectiveMessageResponse> getNewGroupMessageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "NewGroupMessage",
      requestType = com.hab.grpc.chatservice.NewCollectiveMessageRequest.class,
      responseType = com.hab.grpc.chatservice.NewCollectiveMessageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewCollectiveMessageRequest,
      com.hab.grpc.chatservice.NewCollectiveMessageResponse> getNewGroupMessageMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.NewCollectiveMessageRequest, com.hab.grpc.chatservice.NewCollectiveMessageResponse> getNewGroupMessageMethod;
    if ((getNewGroupMessageMethod = ChatGrpc.getNewGroupMessageMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getNewGroupMessageMethod = ChatGrpc.getNewGroupMessageMethod) == null) {
          ChatGrpc.getNewGroupMessageMethod = getNewGroupMessageMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.NewCollectiveMessageRequest, com.hab.grpc.chatservice.NewCollectiveMessageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "NewGroupMessage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.NewCollectiveMessageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.NewCollectiveMessageResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getNewGroupMessageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.TypingMessageRequest,
      com.hab.grpc.chatservice.TypingMessageResponse> getTypingMessageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TypingMessage",
      requestType = com.hab.grpc.chatservice.TypingMessageRequest.class,
      responseType = com.hab.grpc.chatservice.TypingMessageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.TypingMessageRequest,
      com.hab.grpc.chatservice.TypingMessageResponse> getTypingMessageMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.TypingMessageRequest, com.hab.grpc.chatservice.TypingMessageResponse> getTypingMessageMethod;
    if ((getTypingMessageMethod = ChatGrpc.getTypingMessageMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getTypingMessageMethod = ChatGrpc.getTypingMessageMethod) == null) {
          ChatGrpc.getTypingMessageMethod = getTypingMessageMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.TypingMessageRequest, com.hab.grpc.chatservice.TypingMessageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "TypingMessage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.TypingMessageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.TypingMessageResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getTypingMessageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.TypingMessageRequest,
      com.hab.grpc.chatservice.TypingMessageResponse> getTypingGroupMessageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TypingGroupMessage",
      requestType = com.hab.grpc.chatservice.TypingMessageRequest.class,
      responseType = com.hab.grpc.chatservice.TypingMessageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.TypingMessageRequest,
      com.hab.grpc.chatservice.TypingMessageResponse> getTypingGroupMessageMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.TypingMessageRequest, com.hab.grpc.chatservice.TypingMessageResponse> getTypingGroupMessageMethod;
    if ((getTypingGroupMessageMethod = ChatGrpc.getTypingGroupMessageMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getTypingGroupMessageMethod = ChatGrpc.getTypingGroupMessageMethod) == null) {
          ChatGrpc.getTypingGroupMessageMethod = getTypingGroupMessageMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.TypingMessageRequest, com.hab.grpc.chatservice.TypingMessageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "TypingGroupMessage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.TypingMessageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.TypingMessageResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getTypingGroupMessageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ChatClosedRequest,
      com.hab.grpc.chatservice.ChatClosedResponse> getChatClosedMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ChatClosed",
      requestType = com.hab.grpc.chatservice.ChatClosedRequest.class,
      responseType = com.hab.grpc.chatservice.ChatClosedResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ChatClosedRequest,
      com.hab.grpc.chatservice.ChatClosedResponse> getChatClosedMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ChatClosedRequest, com.hab.grpc.chatservice.ChatClosedResponse> getChatClosedMethod;
    if ((getChatClosedMethod = ChatGrpc.getChatClosedMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getChatClosedMethod = ChatGrpc.getChatClosedMethod) == null) {
          ChatGrpc.getChatClosedMethod = getChatClosedMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.ChatClosedRequest, com.hab.grpc.chatservice.ChatClosedResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ChatClosed"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.ChatClosedRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.ChatClosedResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getChatClosedMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.CollectiveChatClosedRequest,
      com.hab.grpc.chatservice.CollectiveChatClosedResponse> getGroupChatClosedMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GroupChatClosed",
      requestType = com.hab.grpc.chatservice.CollectiveChatClosedRequest.class,
      responseType = com.hab.grpc.chatservice.CollectiveChatClosedResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.CollectiveChatClosedRequest,
      com.hab.grpc.chatservice.CollectiveChatClosedResponse> getGroupChatClosedMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.CollectiveChatClosedRequest, com.hab.grpc.chatservice.CollectiveChatClosedResponse> getGroupChatClosedMethod;
    if ((getGroupChatClosedMethod = ChatGrpc.getGroupChatClosedMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getGroupChatClosedMethod = ChatGrpc.getGroupChatClosedMethod) == null) {
          ChatGrpc.getGroupChatClosedMethod = getGroupChatClosedMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.CollectiveChatClosedRequest, com.hab.grpc.chatservice.CollectiveChatClosedResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GroupChatClosed"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.CollectiveChatClosedRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.CollectiveChatClosedResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getGroupChatClosedMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.PeerClosedRequest,
      com.hab.grpc.chatservice.PeerClosedResponse> getPeerClosedMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PeerClosed",
      requestType = com.hab.grpc.chatservice.PeerClosedRequest.class,
      responseType = com.hab.grpc.chatservice.PeerClosedResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.PeerClosedRequest,
      com.hab.grpc.chatservice.PeerClosedResponse> getPeerClosedMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.PeerClosedRequest, com.hab.grpc.chatservice.PeerClosedResponse> getPeerClosedMethod;
    if ((getPeerClosedMethod = ChatGrpc.getPeerClosedMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getPeerClosedMethod = ChatGrpc.getPeerClosedMethod) == null) {
          ChatGrpc.getPeerClosedMethod = getPeerClosedMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.PeerClosedRequest, com.hab.grpc.chatservice.PeerClosedResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "PeerClosed"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.PeerClosedRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.PeerClosedResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getPeerClosedMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.AdminStatusRequest,
      com.hab.grpc.chatservice.AdminStatusResponse> getAdminStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AdminStatus",
      requestType = com.hab.grpc.chatservice.AdminStatusRequest.class,
      responseType = com.hab.grpc.chatservice.AdminStatusResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.AdminStatusRequest,
      com.hab.grpc.chatservice.AdminStatusResponse> getAdminStatusMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.AdminStatusRequest, com.hab.grpc.chatservice.AdminStatusResponse> getAdminStatusMethod;
    if ((getAdminStatusMethod = ChatGrpc.getAdminStatusMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getAdminStatusMethod = ChatGrpc.getAdminStatusMethod) == null) {
          ChatGrpc.getAdminStatusMethod = getAdminStatusMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.AdminStatusRequest, com.hab.grpc.chatservice.AdminStatusResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AdminStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.AdminStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.AdminStatusResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getAdminStatusMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.GetAdminStatusRequest,
      com.hab.grpc.chatservice.GetAdminStatusResponse> getGetAdminStatusMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetAdminStatus",
      requestType = com.hab.grpc.chatservice.GetAdminStatusRequest.class,
      responseType = com.hab.grpc.chatservice.GetAdminStatusResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.GetAdminStatusRequest,
      com.hab.grpc.chatservice.GetAdminStatusResponse> getGetAdminStatusMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.GetAdminStatusRequest, com.hab.grpc.chatservice.GetAdminStatusResponse> getGetAdminStatusMethod;
    if ((getGetAdminStatusMethod = ChatGrpc.getGetAdminStatusMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getGetAdminStatusMethod = ChatGrpc.getGetAdminStatusMethod) == null) {
          ChatGrpc.getGetAdminStatusMethod = getGetAdminStatusMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.GetAdminStatusRequest, com.hab.grpc.chatservice.GetAdminStatusResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetAdminStatus"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.GetAdminStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.GetAdminStatusResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getGetAdminStatusMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest,
      com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse> getBlockUserInGroupChatMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BlockUserInGroupChat",
      requestType = com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest.class,
      responseType = com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest,
      com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse> getBlockUserInGroupChatMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest, com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse> getBlockUserInGroupChatMethod;
    if ((getBlockUserInGroupChatMethod = ChatGrpc.getBlockUserInGroupChatMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getBlockUserInGroupChatMethod = ChatGrpc.getBlockUserInGroupChatMethod) == null) {
          ChatGrpc.getBlockUserInGroupChatMethod = getBlockUserInGroupChatMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest, com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BlockUserInGroupChat"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getBlockUserInGroupChatMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ClearCollectiveChatRequest,
      com.hab.grpc.chatservice.ClearCollectiveChatResponse> getClearGroupChatMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ClearGroupChat",
      requestType = com.hab.grpc.chatservice.ClearCollectiveChatRequest.class,
      responseType = com.hab.grpc.chatservice.ClearCollectiveChatResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ClearCollectiveChatRequest,
      com.hab.grpc.chatservice.ClearCollectiveChatResponse> getClearGroupChatMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ClearCollectiveChatRequest, com.hab.grpc.chatservice.ClearCollectiveChatResponse> getClearGroupChatMethod;
    if ((getClearGroupChatMethod = ChatGrpc.getClearGroupChatMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getClearGroupChatMethod = ChatGrpc.getClearGroupChatMethod) == null) {
          ChatGrpc.getClearGroupChatMethod = getClearGroupChatMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.ClearCollectiveChatRequest, com.hab.grpc.chatservice.ClearCollectiveChatResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ClearGroupChat"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.ClearCollectiveChatRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.ClearCollectiveChatResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getClearGroupChatMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.BlockUserInPersonalChatRequest,
      com.hab.grpc.chatservice.BlockUserInPersonalChatResponse> getBlockUserInPersonalChatMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BlockUserInPersonalChat",
      requestType = com.hab.grpc.chatservice.BlockUserInPersonalChatRequest.class,
      responseType = com.hab.grpc.chatservice.BlockUserInPersonalChatResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.BlockUserInPersonalChatRequest,
      com.hab.grpc.chatservice.BlockUserInPersonalChatResponse> getBlockUserInPersonalChatMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.BlockUserInPersonalChatRequest, com.hab.grpc.chatservice.BlockUserInPersonalChatResponse> getBlockUserInPersonalChatMethod;
    if ((getBlockUserInPersonalChatMethod = ChatGrpc.getBlockUserInPersonalChatMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getBlockUserInPersonalChatMethod = ChatGrpc.getBlockUserInPersonalChatMethod) == null) {
          ChatGrpc.getBlockUserInPersonalChatMethod = getBlockUserInPersonalChatMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.BlockUserInPersonalChatRequest, com.hab.grpc.chatservice.BlockUserInPersonalChatResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BlockUserInPersonalChat"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.BlockUserInPersonalChatRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.BlockUserInPersonalChatResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getBlockUserInPersonalChatMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ClearPersonalChatRequest,
      com.hab.grpc.chatservice.ClearPersonalChatResponse> getClearPersonalChatMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ClearPersonalChat",
      requestType = com.hab.grpc.chatservice.ClearPersonalChatRequest.class,
      responseType = com.hab.grpc.chatservice.ClearPersonalChatResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ClearPersonalChatRequest,
      com.hab.grpc.chatservice.ClearPersonalChatResponse> getClearPersonalChatMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ClearPersonalChatRequest, com.hab.grpc.chatservice.ClearPersonalChatResponse> getClearPersonalChatMethod;
    if ((getClearPersonalChatMethod = ChatGrpc.getClearPersonalChatMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getClearPersonalChatMethod = ChatGrpc.getClearPersonalChatMethod) == null) {
          ChatGrpc.getClearPersonalChatMethod = getClearPersonalChatMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.ClearPersonalChatRequest, com.hab.grpc.chatservice.ClearPersonalChatResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ClearPersonalChat"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.ClearPersonalChatRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.ClearPersonalChatResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getClearPersonalChatMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ReportUserRequest,
      com.hab.grpc.chatservice.ReportUserResponse> getReportUserMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ReportUser",
      requestType = com.hab.grpc.chatservice.ReportUserRequest.class,
      responseType = com.hab.grpc.chatservice.ReportUserResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ReportUserRequest,
      com.hab.grpc.chatservice.ReportUserResponse> getReportUserMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.ReportUserRequest, com.hab.grpc.chatservice.ReportUserResponse> getReportUserMethod;
    if ((getReportUserMethod = ChatGrpc.getReportUserMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getReportUserMethod = ChatGrpc.getReportUserMethod) == null) {
          ChatGrpc.getReportUserMethod = getReportUserMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.ReportUserRequest, com.hab.grpc.chatservice.ReportUserResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ReportUser"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.ReportUserRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.ReportUserResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getReportUserMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.UploadImageRequest,
      com.hab.grpc.chatservice.UploadImageResponse> getUploadImageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UploadImage",
      requestType = com.hab.grpc.chatservice.UploadImageRequest.class,
      responseType = com.hab.grpc.chatservice.UploadImageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.CLIENT_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.UploadImageRequest,
      com.hab.grpc.chatservice.UploadImageResponse> getUploadImageMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.UploadImageRequest, com.hab.grpc.chatservice.UploadImageResponse> getUploadImageMethod;
    if ((getUploadImageMethod = ChatGrpc.getUploadImageMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getUploadImageMethod = ChatGrpc.getUploadImageMethod) == null) {
          ChatGrpc.getUploadImageMethod = getUploadImageMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.UploadImageRequest, com.hab.grpc.chatservice.UploadImageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.CLIENT_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UploadImage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.UploadImageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.UploadImageResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getUploadImageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.DownloadImageRequest,
      com.hab.grpc.chatservice.DownloadImageResponse> getDownloadImageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DownloadImage",
      requestType = com.hab.grpc.chatservice.DownloadImageRequest.class,
      responseType = com.hab.grpc.chatservice.DownloadImageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.DownloadImageRequest,
      com.hab.grpc.chatservice.DownloadImageResponse> getDownloadImageMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.DownloadImageRequest, com.hab.grpc.chatservice.DownloadImageResponse> getDownloadImageMethod;
    if ((getDownloadImageMethod = ChatGrpc.getDownloadImageMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getDownloadImageMethod = ChatGrpc.getDownloadImageMethod) == null) {
          ChatGrpc.getDownloadImageMethod = getDownloadImageMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.DownloadImageRequest, com.hab.grpc.chatservice.DownloadImageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DownloadImage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.DownloadImageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.DownloadImageResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getDownloadImageMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.hab.grpc.chatservice.RemoveImageRequest,
      com.hab.grpc.chatservice.RemoveImageResponse> getRemoveImageMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RemoveImage",
      requestType = com.hab.grpc.chatservice.RemoveImageRequest.class,
      responseType = com.hab.grpc.chatservice.RemoveImageResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.hab.grpc.chatservice.RemoveImageRequest,
      com.hab.grpc.chatservice.RemoveImageResponse> getRemoveImageMethod() {
    io.grpc.MethodDescriptor<com.hab.grpc.chatservice.RemoveImageRequest, com.hab.grpc.chatservice.RemoveImageResponse> getRemoveImageMethod;
    if ((getRemoveImageMethod = ChatGrpc.getRemoveImageMethod) == null) {
      synchronized (ChatGrpc.class) {
        if ((getRemoveImageMethod = ChatGrpc.getRemoveImageMethod) == null) {
          ChatGrpc.getRemoveImageMethod = getRemoveImageMethod =
              io.grpc.MethodDescriptor.<com.hab.grpc.chatservice.RemoveImageRequest, com.hab.grpc.chatservice.RemoveImageResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RemoveImage"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.RemoveImageRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.lite.ProtoLiteUtils.marshaller(
                  com.hab.grpc.chatservice.RemoveImageResponse.getDefaultInstance()))
              .build();
        }
      }
    }
    return getRemoveImageMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ChatStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ChatStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ChatStub>() {
        @java.lang.Override
        public ChatStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ChatStub(channel, callOptions);
        }
      };
    return ChatStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ChatBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ChatBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ChatBlockingStub>() {
        @java.lang.Override
        public ChatBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ChatBlockingStub(channel, callOptions);
        }
      };
    return ChatBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ChatFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ChatFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ChatFutureStub>() {
        @java.lang.Override
        public ChatFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ChatFutureStub(channel, callOptions);
        }
      };
    return ChatFutureStub.newStub(factory, channel);
  }

  /**
   */
  public static abstract class ChatImplBase implements io.grpc.BindableService {

    /**
     */
    public void newPeer(com.hab.grpc.chatservice.NewPeerRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewPeerResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getNewPeerMethod(), responseObserver);
    }

    /**
     */
    public void searchingPeer(com.hab.grpc.chatservice.SearchingPeerRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.SearchingPeerResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSearchingPeerMethod(), responseObserver);
    }

    /**
     */
    public void newCoordinates(com.hab.grpc.chatservice.NewCoordinatesRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewCoordinatesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getNewCoordinatesMethod(), responseObserver);
    }

    /**
     */
    public void newMessage(com.hab.grpc.chatservice.NewMessageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewMessageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getNewMessageMethod(), responseObserver);
    }

    /**
     */
    public void newGroupMessage(com.hab.grpc.chatservice.NewCollectiveMessageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewCollectiveMessageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getNewGroupMessageMethod(), responseObserver);
    }

    /**
     */
    public void typingMessage(com.hab.grpc.chatservice.TypingMessageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.TypingMessageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getTypingMessageMethod(), responseObserver);
    }

    /**
     */
    public void typingGroupMessage(com.hab.grpc.chatservice.TypingMessageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.TypingMessageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getTypingGroupMessageMethod(), responseObserver);
    }

    /**
     */
    public void chatClosed(com.hab.grpc.chatservice.ChatClosedRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ChatClosedResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getChatClosedMethod(), responseObserver);
    }

    /**
     */
    public void groupChatClosed(com.hab.grpc.chatservice.CollectiveChatClosedRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.CollectiveChatClosedResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGroupChatClosedMethod(), responseObserver);
    }

    /**
     */
    public void peerClosed(com.hab.grpc.chatservice.PeerClosedRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.PeerClosedResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPeerClosedMethod(), responseObserver);
    }

    /**
     */
    public void adminStatus(com.hab.grpc.chatservice.AdminStatusRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.AdminStatusResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAdminStatusMethod(), responseObserver);
    }

    /**
     */
    public void getAdminStatus(com.hab.grpc.chatservice.GetAdminStatusRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.GetAdminStatusResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetAdminStatusMethod(), responseObserver);
    }

    /**
     */
    public void blockUserInGroupChat(com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBlockUserInGroupChatMethod(), responseObserver);
    }

    /**
     */
    public void clearGroupChat(com.hab.grpc.chatservice.ClearCollectiveChatRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ClearCollectiveChatResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getClearGroupChatMethod(), responseObserver);
    }

    /**
     */
    public void blockUserInPersonalChat(com.hab.grpc.chatservice.BlockUserInPersonalChatRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.BlockUserInPersonalChatResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBlockUserInPersonalChatMethod(), responseObserver);
    }

    /**
     */
    public void clearPersonalChat(com.hab.grpc.chatservice.ClearPersonalChatRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ClearPersonalChatResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getClearPersonalChatMethod(), responseObserver);
    }

    /**
     */
    public void reportUser(com.hab.grpc.chatservice.ReportUserRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ReportUserResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getReportUserMethod(), responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.UploadImageRequest> uploadImage(
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.UploadImageResponse> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getUploadImageMethod(), responseObserver);
    }

    /**
     */
    public void downloadImage(com.hab.grpc.chatservice.DownloadImageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.DownloadImageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDownloadImageMethod(), responseObserver);
    }

    /**
     */
    public void removeImage(com.hab.grpc.chatservice.RemoveImageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.RemoveImageResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRemoveImageMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getNewPeerMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.NewPeerRequest,
                com.hab.grpc.chatservice.NewPeerResponse>(
                  this, METHODID_NEW_PEER)))
          .addMethod(
            getSearchingPeerMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.SearchingPeerRequest,
                com.hab.grpc.chatservice.SearchingPeerResponse>(
                  this, METHODID_SEARCHING_PEER)))
          .addMethod(
            getNewCoordinatesMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.NewCoordinatesRequest,
                com.hab.grpc.chatservice.NewCoordinatesResponse>(
                  this, METHODID_NEW_COORDINATES)))
          .addMethod(
            getNewMessageMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.NewMessageRequest,
                com.hab.grpc.chatservice.NewMessageResponse>(
                  this, METHODID_NEW_MESSAGE)))
          .addMethod(
            getNewGroupMessageMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.NewCollectiveMessageRequest,
                com.hab.grpc.chatservice.NewCollectiveMessageResponse>(
                  this, METHODID_NEW_GROUP_MESSAGE)))
          .addMethod(
            getTypingMessageMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.TypingMessageRequest,
                com.hab.grpc.chatservice.TypingMessageResponse>(
                  this, METHODID_TYPING_MESSAGE)))
          .addMethod(
            getTypingGroupMessageMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.TypingMessageRequest,
                com.hab.grpc.chatservice.TypingMessageResponse>(
                  this, METHODID_TYPING_GROUP_MESSAGE)))
          .addMethod(
            getChatClosedMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.ChatClosedRequest,
                com.hab.grpc.chatservice.ChatClosedResponse>(
                  this, METHODID_CHAT_CLOSED)))
          .addMethod(
            getGroupChatClosedMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.CollectiveChatClosedRequest,
                com.hab.grpc.chatservice.CollectiveChatClosedResponse>(
                  this, METHODID_GROUP_CHAT_CLOSED)))
          .addMethod(
            getPeerClosedMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.PeerClosedRequest,
                com.hab.grpc.chatservice.PeerClosedResponse>(
                  this, METHODID_PEER_CLOSED)))
          .addMethod(
            getAdminStatusMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.AdminStatusRequest,
                com.hab.grpc.chatservice.AdminStatusResponse>(
                  this, METHODID_ADMIN_STATUS)))
          .addMethod(
            getGetAdminStatusMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.GetAdminStatusRequest,
                com.hab.grpc.chatservice.GetAdminStatusResponse>(
                  this, METHODID_GET_ADMIN_STATUS)))
          .addMethod(
            getBlockUserInGroupChatMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest,
                com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse>(
                  this, METHODID_BLOCK_USER_IN_GROUP_CHAT)))
          .addMethod(
            getClearGroupChatMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.ClearCollectiveChatRequest,
                com.hab.grpc.chatservice.ClearCollectiveChatResponse>(
                  this, METHODID_CLEAR_GROUP_CHAT)))
          .addMethod(
            getBlockUserInPersonalChatMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.BlockUserInPersonalChatRequest,
                com.hab.grpc.chatservice.BlockUserInPersonalChatResponse>(
                  this, METHODID_BLOCK_USER_IN_PERSONAL_CHAT)))
          .addMethod(
            getClearPersonalChatMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.ClearPersonalChatRequest,
                com.hab.grpc.chatservice.ClearPersonalChatResponse>(
                  this, METHODID_CLEAR_PERSONAL_CHAT)))
          .addMethod(
            getReportUserMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.ReportUserRequest,
                com.hab.grpc.chatservice.ReportUserResponse>(
                  this, METHODID_REPORT_USER)))
          .addMethod(
            getUploadImageMethod(),
            io.grpc.stub.ServerCalls.asyncClientStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.UploadImageRequest,
                com.hab.grpc.chatservice.UploadImageResponse>(
                  this, METHODID_UPLOAD_IMAGE)))
          .addMethod(
            getDownloadImageMethod(),
            io.grpc.stub.ServerCalls.asyncServerStreamingCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.DownloadImageRequest,
                com.hab.grpc.chatservice.DownloadImageResponse>(
                  this, METHODID_DOWNLOAD_IMAGE)))
          .addMethod(
            getRemoveImageMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                com.hab.grpc.chatservice.RemoveImageRequest,
                com.hab.grpc.chatservice.RemoveImageResponse>(
                  this, METHODID_REMOVE_IMAGE)))
          .build();
    }
  }

  /**
   */
  public static final class ChatStub extends io.grpc.stub.AbstractAsyncStub<ChatStub> {
    private ChatStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChatStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ChatStub(channel, callOptions);
    }

    /**
     */
    public void newPeer(com.hab.grpc.chatservice.NewPeerRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewPeerResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getNewPeerMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void searchingPeer(com.hab.grpc.chatservice.SearchingPeerRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.SearchingPeerResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getSearchingPeerMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void newCoordinates(com.hab.grpc.chatservice.NewCoordinatesRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewCoordinatesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getNewCoordinatesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void newMessage(com.hab.grpc.chatservice.NewMessageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewMessageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getNewMessageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void newGroupMessage(com.hab.grpc.chatservice.NewCollectiveMessageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewCollectiveMessageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getNewGroupMessageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void typingMessage(com.hab.grpc.chatservice.TypingMessageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.TypingMessageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getTypingMessageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void typingGroupMessage(com.hab.grpc.chatservice.TypingMessageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.TypingMessageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getTypingGroupMessageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void chatClosed(com.hab.grpc.chatservice.ChatClosedRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ChatClosedResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getChatClosedMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void groupChatClosed(com.hab.grpc.chatservice.CollectiveChatClosedRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.CollectiveChatClosedResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGroupChatClosedMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void peerClosed(com.hab.grpc.chatservice.PeerClosedRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.PeerClosedResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPeerClosedMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void adminStatus(com.hab.grpc.chatservice.AdminStatusRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.AdminStatusResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAdminStatusMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getAdminStatus(com.hab.grpc.chatservice.GetAdminStatusRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.GetAdminStatusResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getGetAdminStatusMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void blockUserInGroupChat(com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getBlockUserInGroupChatMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void clearGroupChat(com.hab.grpc.chatservice.ClearCollectiveChatRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ClearCollectiveChatResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getClearGroupChatMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void blockUserInPersonalChat(com.hab.grpc.chatservice.BlockUserInPersonalChatRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.BlockUserInPersonalChatResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getBlockUserInPersonalChatMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void clearPersonalChat(com.hab.grpc.chatservice.ClearPersonalChatRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ClearPersonalChatResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getClearPersonalChatMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void reportUser(com.hab.grpc.chatservice.ReportUserRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ReportUserResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getReportUserMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.UploadImageRequest> uploadImage(
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.UploadImageResponse> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncClientStreamingCall(
          getChannel().newCall(getUploadImageMethod(), getCallOptions()), responseObserver);
    }

    /**
     */
    public void downloadImage(com.hab.grpc.chatservice.DownloadImageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.DownloadImageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getDownloadImageMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void removeImage(com.hab.grpc.chatservice.RemoveImageRequest request,
        io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.RemoveImageResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRemoveImageMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class ChatBlockingStub extends io.grpc.stub.AbstractBlockingStub<ChatBlockingStub> {
    private ChatBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChatBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ChatBlockingStub(channel, callOptions);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.NewPeerResponse> newPeer(
        com.hab.grpc.chatservice.NewPeerRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getNewPeerMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.SearchingPeerResponse> searchingPeer(
        com.hab.grpc.chatservice.SearchingPeerRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getSearchingPeerMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.hab.grpc.chatservice.NewCoordinatesResponse newCoordinates(com.hab.grpc.chatservice.NewCoordinatesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getNewCoordinatesMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.NewMessageResponse> newMessage(
        com.hab.grpc.chatservice.NewMessageRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getNewMessageMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.NewCollectiveMessageResponse> newGroupMessage(
        com.hab.grpc.chatservice.NewCollectiveMessageRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getNewGroupMessageMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.TypingMessageResponse> typingMessage(
        com.hab.grpc.chatservice.TypingMessageRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getTypingMessageMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.TypingMessageResponse> typingGroupMessage(
        com.hab.grpc.chatservice.TypingMessageRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getTypingGroupMessageMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.ChatClosedResponse> chatClosed(
        com.hab.grpc.chatservice.ChatClosedRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getChatClosedMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.CollectiveChatClosedResponse> groupChatClosed(
        com.hab.grpc.chatservice.CollectiveChatClosedRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGroupChatClosedMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.hab.grpc.chatservice.PeerClosedResponse peerClosed(com.hab.grpc.chatservice.PeerClosedRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPeerClosedMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.hab.grpc.chatservice.AdminStatusResponse adminStatus(com.hab.grpc.chatservice.AdminStatusRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAdminStatusMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.GetAdminStatusResponse> getAdminStatus(
        com.hab.grpc.chatservice.GetAdminStatusRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getGetAdminStatusMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse> blockUserInGroupChat(
        com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getBlockUserInGroupChatMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.ClearCollectiveChatResponse> clearGroupChat(
        com.hab.grpc.chatservice.ClearCollectiveChatRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getClearGroupChatMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.BlockUserInPersonalChatResponse> blockUserInPersonalChat(
        com.hab.grpc.chatservice.BlockUserInPersonalChatRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getBlockUserInPersonalChatMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.ClearPersonalChatResponse> clearPersonalChat(
        com.hab.grpc.chatservice.ClearPersonalChatRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getClearPersonalChatMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.hab.grpc.chatservice.ReportUserResponse reportUser(com.hab.grpc.chatservice.ReportUserRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getReportUserMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.hab.grpc.chatservice.DownloadImageResponse> downloadImage(
        com.hab.grpc.chatservice.DownloadImageRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getDownloadImageMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.hab.grpc.chatservice.RemoveImageResponse removeImage(com.hab.grpc.chatservice.RemoveImageRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRemoveImageMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class ChatFutureStub extends io.grpc.stub.AbstractFutureStub<ChatFutureStub> {
    private ChatFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChatFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ChatFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.hab.grpc.chatservice.NewCoordinatesResponse> newCoordinates(
        com.hab.grpc.chatservice.NewCoordinatesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getNewCoordinatesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.hab.grpc.chatservice.PeerClosedResponse> peerClosed(
        com.hab.grpc.chatservice.PeerClosedRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPeerClosedMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.hab.grpc.chatservice.AdminStatusResponse> adminStatus(
        com.hab.grpc.chatservice.AdminStatusRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAdminStatusMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.hab.grpc.chatservice.ReportUserResponse> reportUser(
        com.hab.grpc.chatservice.ReportUserRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getReportUserMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.hab.grpc.chatservice.RemoveImageResponse> removeImage(
        com.hab.grpc.chatservice.RemoveImageRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRemoveImageMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_NEW_PEER = 0;
  private static final int METHODID_SEARCHING_PEER = 1;
  private static final int METHODID_NEW_COORDINATES = 2;
  private static final int METHODID_NEW_MESSAGE = 3;
  private static final int METHODID_NEW_GROUP_MESSAGE = 4;
  private static final int METHODID_TYPING_MESSAGE = 5;
  private static final int METHODID_TYPING_GROUP_MESSAGE = 6;
  private static final int METHODID_CHAT_CLOSED = 7;
  private static final int METHODID_GROUP_CHAT_CLOSED = 8;
  private static final int METHODID_PEER_CLOSED = 9;
  private static final int METHODID_ADMIN_STATUS = 10;
  private static final int METHODID_GET_ADMIN_STATUS = 11;
  private static final int METHODID_BLOCK_USER_IN_GROUP_CHAT = 12;
  private static final int METHODID_CLEAR_GROUP_CHAT = 13;
  private static final int METHODID_BLOCK_USER_IN_PERSONAL_CHAT = 14;
  private static final int METHODID_CLEAR_PERSONAL_CHAT = 15;
  private static final int METHODID_REPORT_USER = 16;
  private static final int METHODID_DOWNLOAD_IMAGE = 17;
  private static final int METHODID_REMOVE_IMAGE = 18;
  private static final int METHODID_UPLOAD_IMAGE = 19;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ChatImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ChatImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_NEW_PEER:
          serviceImpl.newPeer((com.hab.grpc.chatservice.NewPeerRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewPeerResponse>) responseObserver);
          break;
        case METHODID_SEARCHING_PEER:
          serviceImpl.searchingPeer((com.hab.grpc.chatservice.SearchingPeerRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.SearchingPeerResponse>) responseObserver);
          break;
        case METHODID_NEW_COORDINATES:
          serviceImpl.newCoordinates((com.hab.grpc.chatservice.NewCoordinatesRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewCoordinatesResponse>) responseObserver);
          break;
        case METHODID_NEW_MESSAGE:
          serviceImpl.newMessage((com.hab.grpc.chatservice.NewMessageRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewMessageResponse>) responseObserver);
          break;
        case METHODID_NEW_GROUP_MESSAGE:
          serviceImpl.newGroupMessage((com.hab.grpc.chatservice.NewCollectiveMessageRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.NewCollectiveMessageResponse>) responseObserver);
          break;
        case METHODID_TYPING_MESSAGE:
          serviceImpl.typingMessage((com.hab.grpc.chatservice.TypingMessageRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.TypingMessageResponse>) responseObserver);
          break;
        case METHODID_TYPING_GROUP_MESSAGE:
          serviceImpl.typingGroupMessage((com.hab.grpc.chatservice.TypingMessageRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.TypingMessageResponse>) responseObserver);
          break;
        case METHODID_CHAT_CLOSED:
          serviceImpl.chatClosed((com.hab.grpc.chatservice.ChatClosedRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ChatClosedResponse>) responseObserver);
          break;
        case METHODID_GROUP_CHAT_CLOSED:
          serviceImpl.groupChatClosed((com.hab.grpc.chatservice.CollectiveChatClosedRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.CollectiveChatClosedResponse>) responseObserver);
          break;
        case METHODID_PEER_CLOSED:
          serviceImpl.peerClosed((com.hab.grpc.chatservice.PeerClosedRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.PeerClosedResponse>) responseObserver);
          break;
        case METHODID_ADMIN_STATUS:
          serviceImpl.adminStatus((com.hab.grpc.chatservice.AdminStatusRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.AdminStatusResponse>) responseObserver);
          break;
        case METHODID_GET_ADMIN_STATUS:
          serviceImpl.getAdminStatus((com.hab.grpc.chatservice.GetAdminStatusRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.GetAdminStatusResponse>) responseObserver);
          break;
        case METHODID_BLOCK_USER_IN_GROUP_CHAT:
          serviceImpl.blockUserInGroupChat((com.hab.grpc.chatservice.BlockUserInCollectiveChatRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.BlockUserInCollectiveChatResponse>) responseObserver);
          break;
        case METHODID_CLEAR_GROUP_CHAT:
          serviceImpl.clearGroupChat((com.hab.grpc.chatservice.ClearCollectiveChatRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ClearCollectiveChatResponse>) responseObserver);
          break;
        case METHODID_BLOCK_USER_IN_PERSONAL_CHAT:
          serviceImpl.blockUserInPersonalChat((com.hab.grpc.chatservice.BlockUserInPersonalChatRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.BlockUserInPersonalChatResponse>) responseObserver);
          break;
        case METHODID_CLEAR_PERSONAL_CHAT:
          serviceImpl.clearPersonalChat((com.hab.grpc.chatservice.ClearPersonalChatRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ClearPersonalChatResponse>) responseObserver);
          break;
        case METHODID_REPORT_USER:
          serviceImpl.reportUser((com.hab.grpc.chatservice.ReportUserRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.ReportUserResponse>) responseObserver);
          break;
        case METHODID_DOWNLOAD_IMAGE:
          serviceImpl.downloadImage((com.hab.grpc.chatservice.DownloadImageRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.DownloadImageResponse>) responseObserver);
          break;
        case METHODID_REMOVE_IMAGE:
          serviceImpl.removeImage((com.hab.grpc.chatservice.RemoveImageRequest) request,
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.RemoveImageResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_UPLOAD_IMAGE:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.uploadImage(
              (io.grpc.stub.StreamObserver<com.hab.grpc.chatservice.UploadImageResponse>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ChatGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .addMethod(getNewPeerMethod())
              .addMethod(getSearchingPeerMethod())
              .addMethod(getNewCoordinatesMethod())
              .addMethod(getNewMessageMethod())
              .addMethod(getNewGroupMessageMethod())
              .addMethod(getTypingMessageMethod())
              .addMethod(getTypingGroupMessageMethod())
              .addMethod(getChatClosedMethod())
              .addMethod(getGroupChatClosedMethod())
              .addMethod(getPeerClosedMethod())
              .addMethod(getAdminStatusMethod())
              .addMethod(getGetAdminStatusMethod())
              .addMethod(getBlockUserInGroupChatMethod())
              .addMethod(getClearGroupChatMethod())
              .addMethod(getBlockUserInPersonalChatMethod())
              .addMethod(getClearPersonalChatMethod())
              .addMethod(getReportUserMethod())
              .addMethod(getUploadImageMethod())
              .addMethod(getDownloadImageMethod())
              .addMethod(getRemoveImageMethod())
              .build();
        }
      }
    }
    return result;
  }
}
