import com.google.protobuf.gradle.*

plugins {
    id("com.android.application")
    id("com.google.protobuf")
    id("kotlin-android")
    //id("com.google.devtools.ksp") version "1.5.31-1.0.0"
    id("kotlin-kapt")
    id("androidx.navigation.safeargs")
}

val kotlin_version = "1.6.0"
val coroutines_version = "1.5.0"
val protobuf_version = "3.17.0"
val grpc_version = "1.37.1"
val grpc_kotlin_version = "1.1.0"
val protobuf_gradle_plugin_ver = "0.8.16"
val room_version = "2.3.0"

android {
    compileSdk = 30
    buildToolsVersion = "31.0.0"

    defaultConfig {
        applicationId = "com.hab"
        minSdk = 21
        targetSdk = 30
        versionCode = 16
        versionName = "1.0.14"

        multiDexEnabled = true
        //vectorDrawables.useSupportLibrary = true
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
	lint {
        isAbortOnError = false
    }
    buildTypes {
        named("debug") {
            //debuggable true
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        named("release") {
            //debuggable true
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    packagingOptions {
        resources {
            excludes.add("META-INF/DEPENDENCIES")
            excludes.add("META-INF/LICENSE")
            excludes.add("META-INF/LICENSE.txt")
            excludes.add("META-INF/LICENSE.md")
            excludes.add("META-INF/license.txt")
            excludes.add("META-INF/NOTICE")
            excludes.add("META-INF/NOTICE.txt")
            excludes.add("META-INF/NOTICE.md")
            excludes.add("META-INF/notice.txt")
            excludes.add("META-INF/ASL2.0")
            excludes.add("META-INF/*.kotlin_module")
            excludes.add("androidsupportmultidexversion.txt")
        }
    }

    /*sourceSets {
        getByName("main") { proto { srcDir("src/main/proto") } }
    }*/
    protobuf {
        generatedFilesBaseDir = "$projectDir/src/main/generated"
        protoc {
            artifact = "com.google.protobuf:protoc:$protobuf_version"
        }
        plugins {
            // Locate a plugin with name 'grpc'. This step is optional.
            // If you don't locate it, protoc will try to use "protoc-gen-grpc" from
            // system search path.
            id("grpc") {
                artifact = "io.grpc:protoc-gen-grpc-java:$grpc_version"
                // or
                // path = 'tools/protoc-gen-grpc-java'
            }
            id("grpckt") {
                artifact = "io.grpc:protoc-gen-grpc-kotlin:$grpc_kotlin_version:jdk7@jar"
            }
        }
        generateProtoTasks {
            all().forEach { task ->
                task.builtins {
                }
                task.plugins {
                    id("java") {
                        option("lite")
                    }
                    id("grpc") { // Options added to --grpc_out
                        option("lite")
                    }
                    id("grpckt") {
                    }
                }
            }
        }
    }
}

dependencies {
    //implementation fileTree(dir: "libs", include: ["*.jar"])
    implementation ("androidx.multidex:multidex:2.0.1")
    //runtimeOnly ("com.google.devtools.ksp:symbol-processing-api:1.5.31-1.0.0")
    
    // acra lib for sending crash reports
    val acra_version = "5.7.0"
    implementation ("ch.acra:acra-http:$acra_version"){
        exclude (group = "com.android.support", module = "support-compat")
    }
    implementation ("ch.acra:acra-toast:$acra_version")

    implementation ("androidx.legacy:legacy-support-v4:1.0.0")
    implementation ("androidx.appcompat:appcompat:1.3.1")
    //implementation ("androidx.activity:activity-ktx:1.2.0")
    implementation ("androidx.fragment:fragment-ktx:1.3.6")
    implementation ("androidx.lifecycle:lifecycle-runtime-ktx:2.3.1")

    implementation ("androidx.constraintlayout:constraintlayout:2.1.1")
    implementation ("com.google.android.material:material:1.4.0")
    implementation ("androidx.viewpager2:viewpager2:1.0.0")
    implementation ("androidx.recyclerview:recyclerview:1.2.1")

    // Navigation library
    val nav_version = "2.3.5"
    implementation ("androidx.navigation:navigation-fragment-ktx:$nav_version")
    implementation ("androidx.navigation:navigation-ui-ktx:$nav_version")

    // CameraX core library
    val camerax_version = "1.0.2"
    implementation ("androidx.camera:camera-core:$camerax_version")

    // CameraX Camera2 extensions
    implementation ("androidx.camera:camera-camera2:$camerax_version")

    // CameraX Lifecycle library
    implementation ("androidx.camera:camera-lifecycle:$camerax_version")

    // CameraX View class
    implementation ("androidx.camera:camera-view:1.0.0-alpha28")

    // Glide
    implementation ("com.github.bumptech.glide:glide:4.11.0")
    kapt ("com.github.bumptech.glide:compiler:4.11.0")

    //Crop image
    implementation ("com.github.CanHub:Android-Image-Cropper:3.3.5")

    //kotlin
    //implementation ("org.jetbrains.kotlin:kotlin-stdlib:$kotlin_version")
    //implementation "org.jetbrains.kotlinx:kotlinx-coroutines-core:$coroutines_version"
    implementation ("org.jetbrains.kotlinx:kotlinx-coroutines-android:$coroutines_version")
    implementation ("androidx.core:core-ktx:1.6.0")

    // geolocation
    implementation ("com.google.android.gms:play-services-location:18.0.0")

    implementation ("com.google.protobuf:protobuf-javalite:$protobuf_version")
    implementation ("io.grpc:grpc-protobuf-lite:$grpc_version"){
        exclude (group = "com.google.protobuf", module = "protobuf-javalite")
    }
    implementation ("io.grpc:grpc-kotlin-stub:$grpc_kotlin_version") {
        exclude (group = "com.google.protobuf", module = "protobuf-java")
    }
    implementation ("io.grpc:grpc-stub:$grpc_version")
    implementation ("io.grpc:grpc-android:$grpc_version")
    implementation ("io.grpc:grpc-okhttp:$grpc_version")

    implementation ("javax.annotation:javax.annotation-api:1.3.2")

    implementation ("androidx.room:room-runtime:$room_version")
    kapt ("androidx.room:room-compiler:$room_version") // For Java use annotationProcessor instead of kapt

    val billing_version = "4.0.0"
    implementation ("com.android.billingclient:billing:$billing_version")

    implementation ("com.airbnb.android:lottie:3.5.0")

    //vk sdk for registration/login via vk
    //implementation ("com.vk:androidsdk:2.2.3")

    //fb sdk for registration/login via fb
    //implementation ("com.facebook.android:facebook-android-sdk:[5,6)")

    //admob
    //implementation ("com.google.android.gms:play-services-ads:20.4.0")

    //email sending
    implementation ("com.sun.mail:jakarta.mail:2.0.1")

    testImplementation ("junit:junit:4.13.2")
    androidTestImplementation ("androidx.test.ext:junit:1.1.3")
    androidTestImplementation ("androidx.test.espresso:espresso-core:3.4.0")
}
