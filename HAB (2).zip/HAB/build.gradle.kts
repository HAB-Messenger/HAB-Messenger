// Top-level build file where you can add configuration options common to all sub-projects/modules.

buildscript {
    val kotlin_version = "1.6.0"
    //val coroutines_version = "1.5.0"
    //val protobuf_version = "3.17.0"
    //val grpc_version = "1.37.1"
    //val grpc_kotlin_version = "1.1.0"
    val protobuf_gradle_plugin_ver = "0.8.16"
    //val room_version = "2.3.0"
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath ("com.android.tools.build:gradle:7.0.3")
        classpath ("org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version")
        classpath ("com.google.protobuf:protobuf-gradle-plugin:$protobuf_gradle_plugin_ver")
        classpath ("androidx.navigation:navigation-safe-args-gradle-plugin:2.3.5")

        // NOTE: Do not place your application dependencies here; they belong
        // in the individual module build.gradle files
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
        maven {
            setUrl("https://jitpack.io")
        }
    }
}

tasks.register("clean", Delete::class) {
    delete (rootProject.buildDir)
}
